# Third-party materials

The MIT license covers original project software and documentation. CC BY 4.0 covers original annotation contributions. Manufacturer datasheets, extracted source excerpts, trademarks, provider material and third-party libraries retain their respective rights; the project licenses do not relicense them.

Manufacturer PDFs and rendered page/crop images are not bundled. Recorded download addresses for all 65 datasheets are provided in `data/sources.csv`. Source-text excerpts necessary to inspect prompts and reproduce evidence checks remain in the fixed input and analysis records, with their document/page context.

Dependencies are installed separately under their own licenses. No Python environment or compiled Apple Vision binary is bundled.

The CC BY 4.0 legal text is retained from the original reproduction package. Dataset annotation values and experiment outputs are preserved; distribution metadata has been made portable and JSON whitespace compacted.
