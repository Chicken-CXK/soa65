import os
import unittest
from unittest.mock import patch
from soa.api_execution import read_api_credential


class ReleaseCredentials(unittest.TestCase):
    def test_configured_environment_variable_is_used(self):
        with patch.dict(os.environ, {"SOA_TEST_API_KEY": " example-only "}, clear=True):
            self.assertEqual(read_api_credential({"credential_env": "SOA_TEST_API_KEY"}), "example-only")

    def test_missing_credential_is_not_an_empty_request(self):
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaisesRegex(RuntimeError, "DASHSCOPE_API_KEY"):
                read_api_credential({})
