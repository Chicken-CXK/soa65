import json
import unittest
import pdfplumber

from soa.config import Project
from soa.rules.consistency import check, facts, printed_durations
from soa.scoring import scoped_projection, score_analysis
from soa.vision.frontend import caption_part_scope, applicable_panels, discover, target_package
from soa.vision.source_text import rows, referenced_notes


class PanelScopes(unittest.TestCase):
    def bundle(self):
        curves = [
            {
                "curve_id": f"C{i}",
                "voltage_V": 20,
                "current_A": 10,
                "current_low_A": 9,
                "current_high_A": 11,
                "source_panel_id": f"P{i}",
                "source_page": 1,
                "source_panel_bbox": [i * 100, 0, i * 100 + 90, 90],
            }
            for i in [1, 2]
        ]
        fronts = []
        packs = []
        bindings = []
        for i, t in [(1, 25), (2, 80)]:
            geometry = {
                "page": 1,
                "plot_bbox": curves[i - 1]["source_panel_bbox"],
                "curves": [curves[i - 1]],
            }
            fronts.append(geometry | {"panel_id": f"P{i}"})
            packs.append(
                {
                    "panel_id": f"P{i}",
                    "geometry": geometry,
                    "image_region": geometry["plot_bbox"],
                    "blocks": [
                        {
                            "id": f"P{i}_text",
                            "page": 1,
                            "origin": "native",
                            "scope": "selected",
                            "bbox": [i * 100 + 1, 60, i * 100 + 80, 70],
                            "text": f"TC={t}°C single pulse 1ms",
                        }
                    ],
                }
            )
            bindings.append(
                {
                    "curve_id": f"C{i}",
                    "duration_s": 0.001,
                    "pulse_mode": "single",
                    "temperature_symbol": "TC",
                    "temperature_C": t,
                }
            )
        return (
            {"curves": curves, "panel_frontends": fronts},
            {"panel_packs": packs},
            {"bindings": bindings},
        )

    def test_projection_and_evidence_keep_distinct_temperatures(self):
        front, pack, binding = self.bundle()
        bad = json.loads(json.dumps(binding))
        for b in bad["bindings"]:
            b["temperature_C"] = 0
        projected, _ = scoped_projection(bad, pack, front)
        self.assertEqual([b["temperature_C"] for b in projected["bindings"]], [25, 80])
        checked, _ = check(front, projected, binding, pack, "combined")
        self.assertEqual(len(checked["bindings"]), 2)

    def test_one_panel_failure_does_not_reject_other(self):
        front, pack, binding = self.bundle()
        pack["panel_packs"][1]["blocks"] = []
        checked, _ = check(front, binding, binding, pack, "evidence")
        self.assertEqual([b["curve_id"] for b in checked["bindings"]], ["C1"])

    def test_unknown_id_survives_partition_validation(self):
        front, pack, binding = self.bundle()
        structured = {
            "bindings": binding["bindings"] + [binding["bindings"][0] | {"curve_id": "C99"}]
        }
        checked, audit = check(front, binding, structured, pack, "candidate")
        self.assertEqual(checked["bindings"], [])
        self.assertEqual(audit["reasons"][0]["reason"], "unaccounted_candidate")

    def test_empty_extraction_and_policy_rejection_remain_distinct(self):
        front, pack, binding = self.bundle()
        case = {
            "id": "fixture",
            "voltage_V": 20,
            "current_A": 5,
            "duration_s": 0.001,
            "initial_state": "equilibrium",
            "pulse_mode": "single",
            "temperature_symbol": "TC",
            "temperature_C": 25,
        }
        decisions, _, _ = score_analysis(
            [case], front, binding, front, {"bindings": []}, {"bindings": []}, pack, True, {}, False
        )
        self.assertTrue(all(d["prediction"] == "NO_OUTPUT" for d in decisions))
        empty_pack = {"panel_packs": [p | {"blocks": []} for p in pack["panel_packs"]]}
        decisions, _, _ = score_analysis(
            [case], front, binding, front, binding, binding, empty_pack, True, {}, False
        )
        self.assertEqual(
            next(d["prediction"] for d in decisions if d["policy"] == "evidence"), "INSUFFICIENT"
        )

    def test_zero_duty_is_not_nonzero_decimal(self):
        for text, expected in [("D=0", True), ("D\x02=\x020.0", True), ("D=0.01", False)]:
            pack = {
                "blocks": [
                    {
                        "id": "x",
                        "origin": "native",
                        "scope": "selected",
                        "page": 1,
                        "bbox": [0, 0, 10, 10],
                        "text": text,
                    }
                ]
            }
            self.assertEqual(bool(facts(pack)[2]), expected)


@unittest.skipUnless(
    (Project.from_file().dataset / "sources/pdf/AOT240L.pdf").is_file(),
    "Optional source-PDF tests: obtain AOT240L.pdf using data/sources.csv",
)
class SourceDecoding(unittest.TestCase):
    def test_symbol_mu_and_referenced_note(self):
        pdf = Project.from_file().dataset / "sources/pdf/AOT240L.pdf"
        with pdfplumber.open(pdf) as doc:
            blocks = [
                b | {"id": str(i), "origin": "native", "scope": "selected", "page": 4}
                for i, b in enumerate(rows(doc.pages[3]))
                if 308 < b["bbox"][1] < 360 and 240 < b["bbox"][0] < 290
            ]
        self.assertEqual(printed_durations({"blocks": blocks}), {0.00001, 0.0001, 0.001, 0.01})
        notes = referenced_notes(pdf, "Safe Operating Area (Note F)", 4)
        self.assertTrue(facts({"blocks": notes})[2])
        self.assertEqual(facts({"blocks": notes})[1], {})

    def test_wrapped_part_scope_excludes_other_device(self):
        with pdfplumber.open(Project.from_file().dataset / "sources/pdf/AOT240L.pdf") as pdf:
            panels = discover(pdf)
            for panel in panels:
                panel["caption"] = caption_part_scope(
                    pdf.pages[panel["page"] - 1], panel["caption"]
                )
            for part, page in [("AOT240L", 4), ("AOTF240L", 5)]:
                selected = applicable_panels(panels, target_package(pdf, part)["package"], part)
                self.assertEqual([panel["page"] for panel in selected], [page])
