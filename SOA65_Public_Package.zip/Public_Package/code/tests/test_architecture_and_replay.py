from pathlib import Path
import ast
import unittest

from soa.config import Project
from soa.storage import load


class ArchitectureAndReplay(unittest.TestCase):
    def test_core_imports_have_no_historical_paths_or_mutable_run_root(self):
        project = Project.from_file()
        for file in (project.root / "soa").rglob("*.py"):
            text = file.read_text()
            tree = ast.parse(text)
            self.assertNotIn("sys.path", text, str(file))
            self.assertNotIn("/Users/", text, str(file))
            for node in tree.body:
                if isinstance(node, ast.Assign):
                    self.assertFalse(
                        any(
                            isinstance(t, ast.Name) and t.id in {"R", "D", "O", "ROOT", "PROJECT"}
                            for t in node.targets
                        ),
                        str(file),
                    )

    def test_all_main_assets_are_explicit_and_portable(self):
        project = Project.from_file()
        tasks = load(project.root / "config/plan.json")
        self.assertEqual(len(tasks), 884)
        for task in tasks:
            for field in ["input_file", "analysis_file"]:
                self.assertFalse(Path(task[field]).is_absolute())
                self.assertTrue(project.resolve(task[field]).exists())
            packet = load(project.resolve(task["input_file"]))
            for path in [packet["prompt_file"]]:
                self.assertFalse(Path(path).is_absolute())
                self.assertTrue(project.resolve(path).exists())



class PreparationConfiguration(unittest.TestCase):
    def test_new_run_uses_one_model_config_and_refuses_overwrite(self):
        from dataclasses import replace
        import tempfile
        from soa.preparation import prepare_run
        from soa.storage import save

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            project = replace(
                Project.from_file(),
                root=root,
                api=None,
                models={"qwen": {"model": "fixture-model", "reasoning_effort": "high"}},
            )
            save(
                root / "config/plan.json",
                [
                    {
                        "sequence": 1,
                        "profile": "qwen",
                        "arm": "original",
                        "doc_id": "fixture",
                        "call_id": "fixture",
                        "analysis_file": "analysis.json",
                    }
                ],
            )
            run = root / "runs/new"
            prepare_run(project, run)
            task = load(run / "manifest.json")[0]
            self.assertEqual(task["requested_model"], "fixture-model")
            self.assertEqual(task["reasoning_effort"], "high")
            with self.assertRaises(FileExistsError):
                prepare_run(project, run)
