import csv
import tempfile
import unittest
from pathlib import Path

from soa.config import Project
from soa.reporting.export import export_run, enrich_decisions, latex_escape, write_csv
from soa.reporting.tables import ablations, efficiency, repeat_stability, summary_tables
from soa.statistics import aggregate, metric_counts


def record(name, predictions):
    ds = [{"gold": "SUPPORTED", "prediction": p} for p in predictions]
    matched = sum(p == "SUPPORTED" for p in predictions)
    return {
        "arm": "controlled",
        "cohort": "controlled",
        "profile": "qwen",
        "mode": "vision",
        "policy": "baseline",
        "pipeline": "model controlled binding",
        "doc_id": name,
        "analysis_id": name,
        "family": name,
        "repeat_id": 1,
        "binding_fraction": [matched, len(ds)],
        "binding_agreement": matched / len(ds),
        **metric_counts(ds),
    }


class Reporting(unittest.TestCase):
    def test_micro_denominators_and_family_macro_are_distinct(self):
        rs = [record("a", ["SCREEN_FAIL", "SUPPORTED"]), record("b", ["SUPPORTED"] * 8)]
        with tempfile.TemporaryDirectory() as directory:
            summaries = aggregate(rs, Path(directory))
        tables = summary_tables(summaries, rs)
        row = tables["summary"][0]
        self.assertEqual((row["correct"], row["n"]), (9, 10))
        self.assertEqual(row["micro_label_accuracy"], 0.9)
        self.assertEqual(row["family_macro_label_accuracy"], 0.75)
        self.assertEqual(row["micro_binding_agreement"], 0.9)
        self.assertIsNone(row["micro_false_release_over_non_supported"])
        self.assertEqual(sum(r["count"] for r in tables["confusion"]), 10)
        supported = next(r for r in tables["per_class"] if r["label"] == "SUPPORTED")
        self.assertEqual(supported["recall"], 0.9)
        self.assertEqual(supported["precision"], 1)

    def test_repeats_use_sample_sd_and_keep_undefined_singletons(self):
        a = record("a", ["SUPPORTED"])
        b = record("a", ["SCREEN_FAIL"]) | {"repeat_id": 2}
        table = repeat_stability([a, b])
        accuracy = next(r for r in table if r["metric"] == "label_accuracy")
        self.assertEqual(accuracy["repeats"], 2)
        self.assertEqual(accuracy["mean"], 0.5)
        self.assertAlmostEqual(accuracy["sample_sd"], 2**-0.5)
        self.assertIsNone(repeat_stability([a])[0]["sample_sd"])

    def test_ablation_keeps_negative_effect_and_zero_reference_undefined(self):
        cfg = ["controlled", "controlled", "qwen", "vision", "baseline", "model controlled binding"]
        values = {
            "label_accuracy": 0.8,
            "binding_agreement": 0.5,
            "correct_decision_coverage": 0.8,
            "false_release_fraction": 0.0,
            "false_release_over_non_supported": 0.1,
        }
        a = {"configuration": cfg, "family_macro": values}
        b = {
            "configuration": cfg[:4] + ["combined", cfg[5]],
            "family_macro": values
            | {
                "label_accuracy": 0.7,
                "false_release_fraction": 0.1,
                "false_release_over_non_supported": 0.05,
            },
        }
        rows = ablations([a, b])
        accuracy = next(r for r in rows if r["metric"] == "label_accuracy")
        self.assertAlmostEqual(accuracy["delta_pp"], -10)
        self.assertAlmostEqual(accuracy["relative_improvement"], -0.125)
        self.assertIsNone(
            next(r for r in rows if r["metric"] == "false_release_fraction")["relative_improvement"]
        )
        self.assertAlmostEqual(
            next(r for r in rows if r["metric"] == "false_release_over_non_supported")[
                "relative_improvement"
            ],
            0.5,
        )

    def test_usage_missing_is_not_zero_and_not_multiplied_by_policies(self):
        call = {
            "arm": "automatic",
            "cohort": "new",
            "profile": "kimi",
            "requested_model": "kimi",
            "reasoning_effort": "low",
            "mode": "vision",
            "doc_id": "a",
            "elapsed_s": 10.0,
            "exit_code": 0,
            "input_tokens": 100,
            "cached_input_tokens": 40,
            "output_tokens": 20,
            "reasoning_output_tokens": 10,
        }
        other = call | {
            "input_tokens": None,
            "cached_input_tokens": None,
            "output_tokens": None,
            "reasoning_output_tokens": None,
            "elapsed_s": None,
            "exit_code": None,
        }
        result = efficiency([call, other])[0]
        self.assertEqual(result["calls"], 2)
        self.assertEqual(result["input_tokens_known_calls"], 1)
        self.assertEqual(result["input_tokens_observed_sum"], 100)
        self.assertEqual(result["timing_known_calls"], 1)
        self.assertEqual(result["exit_code_unknown"], 1)

    def test_case_join_keeps_same_case_ids_in_different_voltage_analyses(self):
        tasks = []
        analyses = {}
        decisions = []
        for i in [1, 2]:
            file = f"{i}.json"
            tasks.append(
                {"arm": "automatic", "cohort": "new", "analysis_id": str(i), "analysis_file": file}
            )
            analyses[file] = {
                "cases": [{"id": "same", "voltage_V": i * 10}],
                "reference_geometry": {"curves": [], "page": i, "plot_bbox": [0, 0, 10, 10]},
                "source": {"pdf_name": "a.pdf", "target_part": "a"},
            }
            decisions.append(
                {
                    "arm": "automatic",
                    "cohort": "new",
                    "analysis_id": str(i),
                    "case_id": "same",
                    "gold": "SUPPORTED",
                    "prediction": "SCREEN_FAIL",
                }
            )
        rows = list(enrich_decisions(decisions, tasks, analyses))
        self.assertEqual([r["voltage_V"] for r in rows], [10, 20])
        self.assertEqual([r["source_page"] for r in rows], [1, 2])

    def test_csv_roundtrip_and_empty_error_header(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "x.csv"
            write_csv(path, [{"id": "中文,comma", "metric": None, "zero": 0}])
            with path.open(encoding="utf-8-sig", newline="") as stream:
                row = next(csv.DictReader(stream))
            self.assertEqual(row, {"id": "中文,comma", "metric": "", "zero": "0"})
            write_csv(path, [], ["id", "reason"])
            self.assertEqual(path.read_text(encoding="utf-8-sig").strip(), "id,reason")
        self.assertEqual(latex_escape("a_b & 10%"), r"a\_b \& 10\%")

    def test_incomplete_run_cannot_export_publication_tables(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(ValueError, "Score the complete run"):
                export_run(Project.from_file(), Path(directory))
            self.assertFalse((Path(directory) / "paper").exists())


class PairedReporting(unittest.TestCase):
    def test_sensitivity_keeps_saved_pair_direction(self):
        from soa.reporting.tables import paired_tables, sensitivity_table

        cfg = [
            "automatic",
            "new",
            "qwen",
            "vision",
            "baseline",
            "model + local-condition projection",
        ]
        pair = paired_tables(
            [{"configuration": cfg, "family": "f", "kimi_minus_qwen": {"label_accuracy": 0.1}}],
            "family",
        )
        saved = [
            {
                "configuration": cfg,
                "statistics": {
                    "label_accuracy": {
                        "mean": 0.1,
                        "source_composition_range_95": [-0.2, 0.3],
                        "families": 3,
                    }
                },
                "seed": 42,
                "replicates": 2000,
            }
        ]
        result = sensitivity_table(saved, pair)[0]
        self.assertEqual((result["left_model"], result["right_model"]), ("qwen", "kimi"))
        self.assertEqual(
            (result["source_composition_low"], result["source_composition_high"]), (-0.2, 0.3)
        )
        self.assertEqual(result["bootstrap_replicates"], 2000)
        self.assertNotIn("confidence_interval", result)
