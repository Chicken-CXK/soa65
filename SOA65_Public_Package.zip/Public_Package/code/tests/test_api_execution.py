import base64
from dataclasses import replace
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from PIL import Image

from soa.api_budget import Budget
from soa.api_execution import (
    build_payload,
    cost_from_usage,
    execute_api_task,
    normalized_usage,
    plan_api_run,
    run_api_tasks,
)
from soa.config import Project
from soa.execution import collect
from soa.preparation import prepare_run
from soa.storage import load, save


class APIRun(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        original = Project.from_file("config/experiment_api_final.json")
        self.project = replace(original, root=self.root)
        self.api = original.api | {"budget_file": "budget.json", "budget_cap_cny": 10}
        self.run = self.root / "run"
        (self.root / "prompt.txt").write_text("Read the original image; return JSON.")
        Image.new("RGB", (24, 24), "white").save(self.root / "image.png")
        save(
            self.root / "input.json",
            {
                "prompt_file": "prompt.txt",
                "images": [{"path": "image.png"}],
                "candidate_ids": ["C01"],
            },
        )
        self.task = {
            "sequence": 1,
            "call_id": "fixture/qwen/1",
            "requested_model": "qwen3.8-27b",
            "profile": "qwen",
            "reasoning_effort": "low",
            "mode": "vision",
            "input_file": "input.json",
            "model_settings": original.models["qwen"],
        }
        self.binding = {
            "bindings": [
                {
                    "curve_id": "C01",
                    "duration_s": 0.001,
                    "pulse_mode": "single",
                    "temperature_symbol": "TC",
                    "temperature_C": 25,
                }
            ]
        }

    def tearDown(self):
        self.temp.cleanup()

    def response(self, finish="stop", content=None, status=200):
        response = {
            "model": self.task["requested_model"],
            "choices": [
                {
                    "finish_reason": finish,
                    "message": {
                        "content": json.dumps(self.binding) if content is None else content,
                        "reasoning_content": "fixture",
                    },
                }
            ],
            "usage": {
                "prompt_tokens": 100,
                "completion_tokens": 50,
                "prompt_tokens_details": {"cached_tokens": 20},
                "completion_tokens_details": {"reasoning_tokens": 30},
            },
        }
        return (
            {"http_status": status, "elapsed_s": 0.01, "request_id": "fixture", "error": None},
            response,
            json.dumps(response).encode(),
        )

    def manifest(self, tasks=None):
        save(self.run / "manifest.json", tasks or [self.task])
        save(self.run / "run.json", {"api": self.api})

    def test_request_preserves_image_bytes_and_model_contract(self):
        payload, images = build_payload(self.project, self.task)
        encoded = payload["messages"][0]["content"][1]["image_url"]["url"].split(",", 1)[1]
        self.assertEqual(base64.b64decode(encoded), (self.root / "image.png").read_bytes())
        self.assertEqual(images[0]["dimensions"], [24, 24])
        self.assertTrue(payload["enable_thinking"])
        self.assertEqual(payload["reasoning_effort"], "low")
        self.assertEqual(payload["max_tokens"], 8192)
        self.assertNotIn("thinking_budget", payload)
        self.assertNotIn("max_completion_tokens", payload)
        kimi = Project.from_file("config/experiment_api_final.json").models["kimi"]
        payload, _ = build_payload(self.project, self.task | {"model_settings": kimi})
        self.assertEqual(payload["max_completion_tokens"], 16384)
        self.assertNotIn("max_tokens", payload)
        self.assertNotIn("temperature", payload)

    def test_raw_evidence_collection_and_no_double_counting_usage(self):
        self.manifest()
        execute_api_task(
            self.project,
            self.run,
            self.task,
            self.api,
            "not-a-real-key",
            10,
            send=lambda *args: self.response(),
        )
        collect(self.project, self.run)
        output = self.run / "outputs/0001"
        result = load(output / "result.json")
        self.assertEqual(result["single_attempt"]["status"], "parsed")
        self.assertEqual(result["HTTP_attempts"], 1)
        self.assertEqual(result["agent_attempts"], 0)
        self.assertEqual(result["token_usage"]["output_tokens"], 50)
        self.assertAlmostEqual(load(output / "execution.json")["cost_estimate_cny"], 0.0009)
        self.assertTrue((output / "response.raw").exists())
        self.assertNotIn("not-a-real-key", (output / "payload.json").read_text())

    def test_truncation_preserved_and_recollection_cannot_turn_it_into_success(self):
        self.manifest()
        execute_api_task(
            self.project,
            self.run,
            self.task,
            self.api,
            "fixture",
            10,
            send=lambda *args: self.response(finish="length"),
        )
        collect(self.project, self.run)
        collect(self.project, self.run)
        output = self.run / "outputs/0001"
        self.assertEqual(load(output / "result.json")["failed_stage"], "api_truncated")
        self.assertFalse((output / "binding.json").exists())
        self.assertTrue((output / "last_message.txt").exists())

    def test_missing_usage_is_unknown_not_free(self):
        self.assertIsNone(normalized_usage(None))
        self.assertIsNone(cost_from_usage({"input_tokens": 10}, self.task["model_settings"]))

    def test_scheduler_stops_on_429_then_resumes_only_undispatched_tasks(self):
        tasks = [self.task | {"sequence": i, "call_id": f"fixture/{i}"} for i in [1, 2, 3]]
        self.manifest(tasks)
        plan_api_run(self.project, self.run)
        credential = type("Credential", (), {"returncode": 0, "stdout": "fixture"})()
        sent = []

        def execute(*args):
            sent.append(args[2]["call_id"])
            return execute_api_task(
                *args, send=lambda *unused: self.response(status=429 if len(sent) == 1 else 200)
            )

        with (
            patch("soa.api_execution.read_api_credential", return_value=credential.stdout.strip()),
            patch("soa.api_execution.execute_api_task", side_effect=execute),
        ):
            first = run_api_tasks(self.project, self.run, workers=1)
            self.assertEqual(first["submitted"], 1)
            self.assertEqual(first["stop_reason"], "api_requires_attention_429")
            second = run_api_tasks(self.project, self.run, workers=1)
        self.assertEqual(second["submitted"], 3)
        self.assertEqual(sent, ["fixture/1", "fixture/2", "fixture/3"])

    def test_preparation_preserves_profiles_and_freezes_settings(self):
        save(
            self.root / "config/plan.json",
            [
                {
                    "sequence": 1,
                    "profile": "qwen",
                    "call_id": "x/qwen/1",
                    "analysis_file": "a.json",
                    "arm": "original",
                    "doc_id": "a",
                }
            ],
        )
        prepare_run(self.project, self.run)
        task = load(self.run / "manifest.json")[0]
        self.assertEqual(task["profile"], "qwen")
        self.assertEqual(task["call_id"], "run/x/qwen/1")
        self.assertEqual(task["model_settings"]["model"], "qwen3.8-27b")
        self.assertEqual(load(self.run / "run.json")["model_pair"], ["qwen", "kimi"])


class SpendingBudget(unittest.TestCase):
    def test_reservation_release_unknown_usage_and_cap(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "budget.json"
            budget = Budget(path, 3)
            try:
                self.assertTrue(budget.reserve("a", 2, Path(directory) / "a"))
                self.assertFalse(budget.reserve("b", 2, Path(directory) / "b"))
                budget.settle("a", {"cost_estimate_cny": 0.2})
                self.assertTrue(budget.reserve("b", 2, Path(directory) / "b"))
                budget.settle("b", {"cost_estimate_cny": None})
                self.assertAlmostEqual(budget.charged, 2.2)
                with self.assertRaises(ValueError):
                    budget.reserve("a", 0.1, Path(directory) / "a")
            finally:
                budget.close()
            again = Budget(path, 3)
            self.assertAlmostEqual(again.charged, 2.2)
            again.close()

    def test_interrupted_collection_reconciles_persisted_execution(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "budget.json"
            out = Path(directory) / "call"
            budget = Budget(path, 3)
            budget.reserve("a", 2, out)
            budget.close()
            save(out / "execution.json", {"cost_estimate_cny": 0.1})
            budget = Budget(path, 3)
            budget.reconcile_completed()
            self.assertAlmostEqual(budget.charged, 0.1)
            budget.close()
