import copy
import json
from dataclasses import replace
from pathlib import Path
import tempfile
import unittest

from soa.config import Project
from soa.contracts import parse_binding
from soa.execution import collect, record_terminal
from soa.scoring import evaluate_model, score_run
from soa.storage import load, save


def relation(**changes):
    return {
        "curve_id": "C01",
        "duration_s": 0.001,
        "pulse_mode": "single",
        "temperature_symbol": "TC",
        "temperature_C": 25,
    } | changes


class OutputContract(unittest.TestCase):
    def test_shared_stroke_durations_are_allowed(self):
        result = parse_binding(
            json.dumps({"bindings": [relation(), relation(duration_s=0.01)]}), ["C01"]
        )
        self.assertEqual(result["status"], "parsed")
        self.assertEqual(result["semantic_anomalies"], [])

    def test_unknown_and_duplicate_are_reported_not_repaired(self):
        raw = {"bindings": [relation(), relation(), relation(curve_id="C99")]}
        result = parse_binding(json.dumps(raw), ["C01"])
        self.assertIn("duplicate_relation", result["semantic_anomalies"])
        self.assertIn("unknown_curve_id:C99", result["semantic_anomalies"])
        self.assertEqual(result["structured"], raw)

    def test_bad_numbers_and_malformed_json_stay_failed(self):
        for text in [
            '{"bindings":[}',
            json.dumps({"bindings": [relation(duration_s=float("nan"))]}),
        ]:
            self.assertEqual(parse_binding(text, ["C01"])["status"], "schema_or_json_error")
        self.assertEqual(parse_binding('{"bindings":[]}', [])["status"], "valid_empty")

    def test_fenced_json_keeps_payload(self):
        raw = {"bindings": [relation()]}
        result = parse_binding("```json\n" + json.dumps(raw) + "\n```", ["C01"])
        self.assertEqual(result["structured"], raw)

    def test_incomplete_fence_is_a_parse_failure(self):
        for raw in ["```", "``````", "```json```"]:
            self.assertEqual(parse_binding(raw, ["C01"])["status"], "schema_or_json_error")

    def test_invalid_schema_scores_no_output_in_all_arms(self):
        project = Project.from_file()
        tasks = load(project.root / "config/plan.json")
        for arm in ["original", "controlled", "automatic"]:
            task = next(t for t in tasks if t["arm"] == arm)
            analysis = load(project.resolve(task["analysis_file"]))
            for payload in [{"bindings": "bad"}, {"bindings": [None]}, {"bindings": [{}]}, []]:
                parsed = parse_binding(json.dumps(payload), [])
                result = {"single_attempt": parsed}
                with tempfile.TemporaryDirectory() as directory:
                    decisions, records, _, _ = evaluate_model(
                        task, analysis, result, Path(directory)
                    )
                self.assertTrue(decisions)
                self.assertTrue(all(d["prediction"] == "NO_OUTPUT" for d in decisions))
                self.assertTrue(all(r["binding_fraction"][0] == 0 for r in records))
                self.assertEqual(result["single_attempt"]["submitted_json"], payload)


class ExplicitRunContext(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.project = replace(Project.from_file(), root=self.root, default_run=self.root / "one")
        self.task = {
            "sequence": 1,
            "call_id": "fixture",
            "requested_model": "fixture",
            "input_file": "input.json",
        }
        save(self.root / "input.json", {"candidate_ids": ["C01"]})

    def tearDown(self):
        self.temp.cleanup()

    def make_run(self, name):
        run = self.root / name
        save(run / "manifest.json", [copy.deepcopy(self.task)])
        save(run / "outputs/0001/dispatch.json", {"agent_id": name, "backend": "DashScope API"})
        return run

    def test_terminal_is_no_output_without_fabricating_binding(self):
        for state in ["interrupted", "failed", "completed_without_binding"]:
            run = self.make_run(state)
            record_terminal(run, self.task, state, "observed fixture outcome")
            collect(self.project, run)
            result = load(run / "outputs/0001/result.json")
            self.assertEqual(result["single_attempt"]["status"], "no_output")
            self.assertEqual(result["failed_stage"], "api_" + state)
            self.assertFalse((run / "outputs/0001/binding.json").exists())

    def test_two_runs_and_recollection_preserve_metadata(self):
        one, two = self.make_run("one"), self.make_run("two")
        for run, tokens in [(one, 12), (two, 99)]:
            save(run / "outputs/0001/execution.json", {"usage": {"input_tokens": tokens}})
            save(run / "outputs/0001/binding.json", {"bindings": [relation()]})
            collect(self.project, run)
        collect(self.project, one)
        self.assertEqual(load(one / "outputs/0001/result.json")["token_usage"]["input_tokens"], 12)
        self.assertEqual(load(two / "outputs/0001/result.json")["token_usage"]["input_tokens"], 99)
        self.assertEqual(load(two / "outputs/0001/result.json")["agent_id"], "two")

    def test_missing_result_prevents_complete_score(self):
        run = self.make_run("one")
        with self.assertRaises(ValueError):
            score_run(self.project, run)
        self.assertFalse((run / "completed.json").exists())
