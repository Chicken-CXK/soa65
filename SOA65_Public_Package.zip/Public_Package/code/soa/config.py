"""Project paths are resolved once; pipeline stages receive this explicit context."""

from dataclasses import dataclass
from pathlib import Path
from .storage import load


@dataclass(frozen=True)
class Project:
    root: Path
    dataset: Path
    ocr_command: Path
    default_run: Path
    models: dict
    model_pair: tuple[str, str]
    api: dict | None = None

    @classmethod
    def from_file(cls, path="config/experiment.json"):
        path = Path(path).resolve()
        spec = load(path)
        root = (path.parent / spec.get("project_root", "..")).resolve()

        def resolve(value):
            return (root / value).resolve()

        return cls(
            root,
            resolve(spec["dataset"]),
            resolve(spec["ocr_command"]),
            resolve(spec["default_run"]),
            spec["models"],
            tuple(spec["model_pair"]),
            spec.get("api"),
        )

    def resolve(self, path):
        return (self.root / path).resolve()

    def relative(self, path):
        return str(Path(path).resolve().relative_to(self.root))
