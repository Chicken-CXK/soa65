"""Single-attempt DashScope calls with raw evidence and a shared CNY budget."""

import base64
from collections import deque
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from datetime import datetime
import http.client
import json
from pathlib import Path
import signal
import os
import threading
import time
import urllib.error
import urllib.request
from PIL import Image

from .api_budget import Budget
from .execution import MODEL_INSTRUCTION, collect, input_packet, output_dir, record_terminal
from .storage import load, save


def read_api_credential(api):
    """Read the reproducer's credential without persisting it."""
    name = api.get("credential_env", "DASHSCOPE_API_KEY")
    credential = os.environ.get(name, "").strip()
    if not credential:
        raise RuntimeError(f"Set the {name} environment variable before paid API execution")
    return credential


def timestamp():
    return datetime.now().astimezone().isoformat()


def request_material(project, task):
    packet = input_packet(project, task)
    prompt = MODEL_INSTRUCTION + project.resolve(packet["prompt_file"]).read_text()
    images = packet["images"] if task["mode"] == "vision" else []
    return prompt, images


def request_reserve(prompt, images, settings, api):
    # Planning allowance, not measured tokenizer output. No cache discount assumed.
    input_tokens = len(prompt.encode("utf-8")) + 1024 + api["input_reserve_per_image"] * len(images)
    amount = (
        input_tokens * settings["input_cny_per_m"]
        + settings["output_reserve_tokens"] * settings["output_cny_per_m"]
    ) / 1e6
    return {
        "input_token_allowance": input_tokens,
        "output_token_allowance": settings["output_reserve_tokens"],
        "reserve_cny": amount,
    }


def build_payload(project, task):
    prompt, images = request_material(project, task)
    settings = task["model_settings"]
    parts = [{"type": "text", "text": prompt}]
    records = []
    for image in images:
        path = project.resolve(image["path"])
        data = path.read_bytes()
        with Image.open(path) as im:
            mime = {"PNG": "image/png", "JPEG": "image/jpeg"}[im.format]
            size = list(im.size)
        parts.append(
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:{mime};base64," + base64.b64encode(data).decode("ascii")
                },
            }
        )
        records.append(
            image | {"path": str(path), "bytes": len(data), "dimensions": size, "mime": mime}
        )
    payload = {
        "model": settings["model"],
        "messages": [{"role": "user", "content": parts}],
        "enable_thinking": settings["enable_thinking"],
        "reasoning_effort": settings["reasoning_effort"],
    }
    if settings["model"] == "qwen3.8-27b":
        payload["max_tokens"] = settings["max_tokens"]
    elif settings["model"] == "kimi-k3":
        payload["max_completion_tokens"] = settings["max_completion_tokens"]
    else:
        raise ValueError("Unsupported API model; no fallback")
    return payload, records


def send_http(payload, endpoint, credential, timeout):
    request = urllib.request.Request(
        endpoint,
        data=json.dumps(payload, ensure_ascii=False, allow_nan=False).encode(),
        headers={"Authorization": "Bearer " + credential, "Content-Type": "application/json"},
    )
    started = time.monotonic()
    status, headers, error, raw = None, {}, None, b""
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            status = response.status
            headers = dict(response.headers)
            raw = response.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        headers = dict(exc.headers)
        raw = exc.read()
    except (OSError, http.client.HTTPException) as exc:
        error = type(exc).__name__ + ": " + str(exc)
    try:
        data = json.loads(raw)
        if not isinstance(data, dict):
            data = None
    except ValueError:
        data = None
    meta = {
        "http_status": status,
        "elapsed_s": time.monotonic() - started,
        "error": error,
        "request_id": next(
            (
                v
                for k, v in headers.items()
                if k.lower() in ("x-request-id", "request-id", "x-dashscope-request-id")
            ),
            None,
        ),
    }
    return meta, data, raw


def normalized_usage(raw):
    if not isinstance(raw, dict):
        return None
    return {
        "input_tokens": raw.get("prompt_tokens"),
        "output_tokens": raw.get("completion_tokens"),
        "cached_input_tokens": (raw.get("prompt_tokens_details") or {}).get("cached_tokens"),
        "reasoning_output_tokens": (raw.get("completion_tokens_details") or {}).get(
            "reasoning_tokens"
        ),
    }


def cost_from_usage(usage, settings, user_price=False):
    if not usage or any(
        not isinstance(usage.get(k), (int, float)) or usage[k] < 0
        for k in ("input_tokens", "output_tokens")
    ):
        return None
    price = (
        settings.get("user_input_cny_per_m", settings["input_cny_per_m"])
        if user_price
        else settings["input_cny_per_m"]
    )
    return (
        usage["input_tokens"] * price + usage["output_tokens"] * settings["output_cny_per_m"]
    ) / 1e6


def execute_api_task(project, run, task, api, credential, timeout, send=send_http):
    output = output_dir(run, task)
    output.mkdir(parents=True, exist_ok=True)
    if (output / "dispatch.json").exists():
        raise ValueError("Already dispatched; no API retry")
    payload, images = build_payload(project, task)
    settings = task["model_settings"]
    (output / "submitted_prompt.txt").write_text(payload["messages"][0]["content"][0]["text"])
    save(output / "payload.json", payload)
    save(
        output / "dispatch.json",
        task
        | {
            "agent_id": None,
            "backend": "DashScope API",
            "endpoint": api["endpoint"],
            "dispatched_at": timestamp(),
            "images": images,
            "external_API_calls": 1,
            "HTTP_attempts": 1,
            "subprocess_attempts": 0,
            "implicit_retries": 0,
        },
    )
    meta, response, raw = send(payload, api["endpoint"], credential, timeout)
    (output / "response.raw").write_bytes(raw)
    if response is not None:
        save(output / "response.json", response)
    choices = (response or {}).get("choices") or []
    choice = choices[0] if choices else {}
    message = choice.get("message") or {}
    content = message.get("content")
    finish = choice.get("finish_reason")
    tools = message.get("tool_calls") or []
    usage = normalized_usage((response or {}).get("usage"))
    failure = None
    if meta["http_status"] != 200:
        failure = "api_http_or_transport_error"
    elif response is None:
        failure = "api_invalid_response"
    elif finish in ("length", "max_tokens"):
        failure = "api_truncated"
    elif tools:
        failure = "api_tool_call_instead_of_binding"
    elif not isinstance(content, str) or not content.strip():
        failure = "api_reasoning_only" if message.get("reasoning_content") else "api_empty_final"
    if isinstance(content, str):
        (output / "last_message.txt").write_text(content)
        if failure is None:
            (output / "binding.json").write_text(content)
    if message.get("reasoning_content") is not None:
        save(output / "reasoning.json", {"reasoning_content": message["reasoning_content"]})
    execution = meta | {
        "exit_code": 0 if meta["http_status"] == 200 else 1,
        "usage": usage,
        "provider_usage": (response or {}).get("usage"),
        "returned_model": (response or {}).get("model"),
        "finish_reason": finish,
        "tool_events": ["tool_call"] * len(tools),
        "subprocess_attempts": 0,
        "HTTP_attempts": 1,
        "failed_stage": failure,
        "cost_estimate_cny": cost_from_usage(usage, settings),
        "user_price_estimate_cny": cost_from_usage(usage, settings, True),
        "cost_basis": "public rates without cache discounts; estimated, not settled invoice",
        "completed_at": timestamp(),
    }
    save(output / "execution.json", execution)
    if failure:
        record_terminal(run, task, "failed", failure)
    return {
        "sequence": task["sequence"],
        "call_id": task["call_id"],
        "status": "terminal" if failure else "submitted",
        "http_status": meta["http_status"],
        "finish_reason": finish,
        "elapsed_s": meta["elapsed_s"],
        "cost_estimate_cny": execution["cost_estimate_cny"],
    }


def plan_api_run(project, run):
    run = Path(run)
    api = load(run / "run.json")["api"]
    tasks = load(run / "manifest.json")
    rows = []
    checked = set()
    for task in tasks:
        prompt, images = request_material(project, task)
        for image in images:
            path = project.resolve(image["path"])
            if path not in checked:
                with Image.open(path) as im:
                    if im.format not in ("PNG", "JPEG"):
                        raise ValueError("Unsupported input image")
                    im.verify()
                checked.add(path)
        rows.append(
            {
                "sequence": task["sequence"],
                "call_id": task["call_id"],
                "profile": task["profile"],
                **request_reserve(prompt, images, task["model_settings"], api),
            }
        )
    save(run / "api_plan.json", rows)
    summary = {
        "planned": len(tasks),
        "images_validated": len(checked),
        "budget_cap_cny": api["budget_cap_cny"],
        "sum_of_all_request_reserves_cny": sum(r["reserve_cny"] for r in rows),
        "meaning": "Individual requests reserve headroom then settle usage; this sum is not an expected bill",
        "new_model_calls": 0,
    }
    save(run / "api_plan_summary.json", summary)
    return summary


def run_api_tasks(project, run, workers=4, limit=None, timeout=600):
    if workers < 1 or timeout <= 0 or (limit is not None and limit < 1):
        raise ValueError("workers, timeout and limit must be positive")
    run = Path(run)
    api = load(run / "run.json")["api"]
    tasks = load(run / "manifest.json")
    if not (run / "api_plan.json").exists():
        plan_api_run(project, run)
    plans = {r["call_id"]: r for r in load(run / "api_plan.json")}
    pending = deque(t for t in tasks if not (output_dir(run, t) / "dispatch.json").exists())
    if limit is not None:
        pending = deque(list(pending)[:limit])
    budget = Budget(project.resolve(api["budget_file"]), api["budget_cap_cny"])
    stopped = threading.Event()
    old_signals = {}
    stop_reason = None
    progress = []
    invocation_path = run / "execution_invocations.json"
    invocations = load(invocation_path) if invocation_path.exists() else []
    invocation = {
        "started_at": timestamp(),
        "workers": workers,
        "timeout_s": timeout,
        "limit": limit,
        "pending_tasks": len(pending),
    }
    invocations.append(invocation)
    try:
        budget.reconcile_completed()
        credential = read_api_credential(api)
        save(invocation_path, invocations)
        if threading.current_thread() is threading.main_thread():
            for sig in (signal.SIGINT, signal.SIGTERM):
                old_signals[sig] = signal.signal(sig, lambda *_: stopped.set())
        with ThreadPoolExecutor(max_workers=workers) as pool:
            active = {}
            while pending or active:
                while pending and len(active) < workers and not stopped.is_set():
                    task = pending[0]
                    if not budget.reserve(
                        task["call_id"],
                        plans[task["call_id"]]["reserve_cny"],
                        output_dir(run, task),
                    ):
                        break
                    pending.popleft()
                    future = pool.submit(
                        execute_api_task, project, run, task, api, credential, timeout
                    )
                    active[future] = task
                if not active:
                    if pending and not stopped.is_set():
                        stop_reason = "budget_headroom_exhausted"
                    break
                done, _ = wait(active, timeout=1, return_when=FIRST_COMPLETED)
                for future in done:
                    task = active.pop(future)
                    result = future.result()
                    execution = load(output_dir(run, task) / "execution.json")
                    budget.settle(task["call_id"], execution)
                    if result["http_status"] != 200:
                        stop_reason = "api_requires_attention_" + str(result["http_status"])
                        stopped.set()
                    if budget.charged > budget.state["cap_cny"]:
                        stop_reason = "observed_charge_exceeded_planning_allowance"
                        stopped.set()
                    result["budget_charged_or_reserved_cny"] = budget.charged
                    progress.append(result)
                    save(run / "progress.json", progress)
                    print(json.dumps(result), flush=True)
        collection = collect(project, run)
        status = {
            "status": "all_outcomes_collected"
            if collection["submitted"] == len(tasks)
            else "partial",
            **collection,
            "stop_reason": stop_reason or ("interrupted" if stopped.is_set() else None),
            "charged_or_reserved_cny": budget.charged,
            "budget_file": str(budget.path),
            "finished_at": timestamp(),
        }
        save(run / "api_status.json", status)
        invocation.update(
            finished_at=status["finished_at"],
            status=status["status"],
            stop_reason=status["stop_reason"],
            newly_completed=len(progress),
        )
        save(invocation_path, invocations)
        return status
    finally:
        for sig, old in old_signals.items():
            signal.signal(sig, old)
        budget.close()
