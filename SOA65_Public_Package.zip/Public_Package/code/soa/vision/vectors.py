"""Original vector intersection routines; no manual calibration lookup."""

import numpy as np


def color_value(obj):
    c = obj.get("stroking_color") if obj.get("stroke", True) else obj.get("non_stroking_color")
    if isinstance(c, (int, float)):
        return [c, c, c]
    if c is None:
        return [0, 0, 0]
    if len(c) == 4:
        return [(1 - c[i]) * (1 - c[3]) for i in range(3)]
    return list(c)[:3]


def segments(obj):
    pts = obj.get("pts", [])
    # For vector paths, separate move-to subpaths rather than joining them.
    path = obj.get("path")
    if path:
        current = None
        for item in path:
            op = item[0]
            if op == "m":
                current = item[1]
            elif op == "l":
                if current is not None:
                    yield current, item[1]
                current = item[1]
            elif op == "c":
                if current is not None:
                    start = np.array(current)
                    b, c, end = map(np.array, item[1:])
                    prev = start
                    for t in np.linspace(0, 1, 33)[1:]:
                        cur = (
                            (1 - t) ** 3 * start
                            + 3 * (1 - t) ** 2 * t * b
                            + 3 * (1 - t) * t * t * c
                            + t**3 * end
                        )
                        yield tuple(prev), tuple(cur)
                        prev = cur
                    current = tuple(end)
        return
    yield from zip(pts, pts[1:])


def intersections(page, bbox, x):
    raw = []
    for kind in ("curve", "line"):
        objects = page.curves if kind == "curve" else page.lines
        for idx, obj in enumerate(objects):
            if (
                obj["x1"] < bbox[0]
                or obj["x0"] > bbox[2]
                or obj["bottom"] < bbox[1]
                or obj["top"] > bbox[3]
            ):
                continue
            rgb = color_value(obj)
            if min(rgb) > 0.75:  # White masks are not visible curve ink.
                continue
            if obj["width"] < 0.5 or obj["height"] < 0.1:
                continue
            for a, b in segments(obj):
                if a[0] > b[0]:
                    a, b = b, a
                dx, dy = b[0] - a[0], b[1] - a[1]
                if dx <= 0 or dy <= 0 or not (a[0] <= x <= b[0]):
                    continue
                y = a[1] + (x - a[0]) * dy / dx
                if not (bbox[1] + 1 < y < bbox[3] - 1):
                    continue
                raw.append(
                    dict(
                        y=y,
                        rgb=rgb,
                        source=f"{kind}:{idx}",
                        segment=[list(a), list(b)],
                        line_width=obj.get("linewidth", 0),
                    )
                )
    groups = []
    for hit in sorted(raw, key=lambda z: z["y"]):
        if groups and hit["y"] - groups[-1][-1]["y"] <= 0.65:
            groups[-1].append(hit)
        else:
            groups.append([hit])
    result = [
        dict(
            y=float(np.mean([h["y"] for h in g])),
            rgb=g[0]["rgb"],
            sources=sorted(set(h["source"] for h in g)),
            segment=g[0]["segment"],
            line_width=max(h["line_width"] for h in g),
        )
        for g in groups
    ]
    merged = []
    for hit in result:
        if merged and hit["sources"] == merged[-1]["sources"] and hit["y"] - merged[-1]["y"] < 2:
            # Two edges of the same filled stroke are one curve, unlike nearby
            # distinct DC/100-ms source objects, which must remain separate.
            merged[-1]["y"] = (hit["y"] + merged[-1]["y"]) / 2
        else:
            merged.append(hit)
    return merged
