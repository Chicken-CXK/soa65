"""Native tick parsing and grid-based logarithmic axis calibration."""

import math, re, itertools
from collections import defaultdict
import numpy as np
from .vectors import segments


def boxes(page):
    vertical = defaultdict(list)
    horizontal = defaultdict(list)
    candidates = []
    for obj in page.lines + page.curves:
        for a, b in segments(obj):
            x0, x1 = sorted([a[0], b[0]])
            y0, y1 = sorted([a[1], b[1]])
            if x1 - x0 < 0.8 and y1 - y0 >= 60:
                vertical[(round(y0 / 2), round(y1 / 2))].append((x0, y0, y1))
            if y1 - y0 < 0.8 and x1 - x0 >= 80:
                horizontal[(round(x0 / 2), round(x1 / 2))].append((y0, x0, x1))
    for vals in vertical.values():
        xs = sorted(set(round(v[0], 1) for v in vals))
        if len(xs) >= 3 and xs[-1] - xs[0] >= 80:
            candidates.append([xs[0], min(v[1] for v in vals), xs[-1], max(v[2] for v in vals)])
    for vals in horizontal.values():
        ys = sorted(set(round(v[0], 1) for v in vals))
        if len(ys) >= 3 and ys[-1] - ys[0] >= 60:
            candidates.append([min(v[1] for v in vals), ys[0], max(v[2] for v in vals), ys[-1]])
    for r in page.rects:
        if 80 <= r["width"] <= page.width * 0.85 and 60 <= r["height"] <= page.height * 0.6:
            candidates.append([r["x0"], r["top"], r["x1"], r["bottom"]])
    unique = {}
    for b in candidates:
        unique[tuple(round(v / 2) for v in b)] = b
    return list(unique.values())


def tick_tokens(page):
    tokens = []
    for w in page.extract_words(return_chars=True):
        if not re.fullmatch(r"[\d.+−–-]+", w["text"]):
            continue
        cs = sorted(w["chars"], key=lambda c: c["x0"])
        size = max(c["size"] for c in cs)
        major = [c for c in cs if c["size"] >= size * 0.88]
        base = "".join(c["text"] for c in major).replace("−", "-").replace("–", "-")
        text = base
        right = max(c["x1"] for c in major)
        top = min(c["top"] for c in major)
        sup = []
        cursor = right
        for c in cs:
            if c["x0"] >= right - 0.3 and c["size"] < size * 0.88 and c["top"] < top - 0.1:
                if c["x0"] - cursor > 1.3:
                    break
                sup.append(c)
                cursor = c["x1"]
        if base == "10" and sup:
            suffix = "".join(c["text"] for c in sup).replace("−", "-").replace("–", "-")
            if re.fullmatch(r"-?\d{1,2}", suffix):
                value = 10 ** int(suffix)
                text = "10^" + suffix
            else:
                continue
        else:
            try:
                value = float(base)
            except ValueError:
                continue
        if not 1e-8 <= value <= 1e8:
            continue
        tokens.append(
            dict(
                text=text,
                value=value,
                size=size,
                x0=min(c["x0"] for c in major),
                x1=right,
                top=top,
                bottom=max(c["bottom"] for c in major),
            )
        )
    return tokens


def axis_grid_positions(page, bbox):
    """Read full-span grid strokes in source coordinates, including PDF image strips."""
    x0, y0, x1, y1 = bbox
    found = {"x": [], "y": []}
    for obj in page.lines + page.curves + page.rects:
        for a, b in segments(obj):
            if (
                abs(a[0] - b[0]) < 0.3
                and abs(min(a[1], b[1]) - y0) < 2
                and abs(max(a[1], b[1]) - y1) < 2
            ):
                found["x"].append((a[0] + b[0]) / 2)
            if (
                abs(a[1] - b[1]) < 0.3
                and abs(min(a[0], b[0]) - x0) < 2
                and abs(max(a[0], b[0]) - x1) < 2
            ):
                found["y"].append((a[1] + b[1]) / 2)
    for obj in page.images:
        if obj["width"] <= 1 and abs(obj["top"] - y0) < 2 and abs(obj["bottom"] - y1) < 2:
            found["x"].append((obj["x0"] + obj["x1"]) / 2)
        if obj["height"] <= 1 and abs(obj["x0"] - x0) < 2 and abs(obj["x1"] - x1) < 2:
            found["y"].append((obj["top"] + obj["bottom"]) / 2)
    return {
        axis: merge_grid_positions(
            [v for v in values if (x0 - 1 <= v <= x1 + 1 if axis == "x" else y0 - 1 <= v <= y1 + 1)]
        )
        for axis, values in found.items()
    }


def merge_grid_positions(values):
    groups = []
    for value in sorted(values):
        if groups and value - groups[-1][-1] < 0.4:
            groups[-1].append(value)
        else:
            groups.append([value])
    return [float(np.mean(group)) for group in groups]


def align_ticks_to_grid(ticks, axis, positions):
    """Associate labels with lines; dense log-grid spacing distinguishes decades.

    A label's glyph center can be closer to the 9 minor line than the 10 line.
    At a decade the adjacent gap resets from log(10/9) to log(2/1).
    """
    if len(positions) < 3:
        return ticks
    gaps = np.diff(positions)
    major = [
        positions[i]
        for i in range(1, len(positions) - 1)
        if (gaps[i] > 2 * gaps[i - 1] if axis == "x" else gaps[i - 1] > 2 * gaps[i])
    ]
    decades = [positions[0], *major, positions[-1]] if major else positions
    aligned = []
    for token in ticks:
        center = (
            (token["x0"] + token["x1"]) / 2 if axis == "x" else (token["top"] + token["bottom"]) / 2
        )
        values = token.get("values", [token["value"]])
        is_decade = any(abs(math.log10(v) - round(math.log10(v))) < 1e-6 for v in values)
        candidates = decades if is_decade else positions
        coord = min(candidates, key=lambda p: abs(p - center))
        if abs(coord - center) <= max(2, token["size"] * 0.65):
            aligned.append(
                token
                | dict(axis_position_pt=coord, label_center_pt=center, position_basis="source_grid")
            )
    return aligned if len(aligned) >= 3 else ticks


def tick_position(token, axis):
    return token.get(
        "axis_position_pt",
        (token["x0"] + token["x1"]) / 2 if axis == "x" else (token["top"] + token["bottom"]) / 2,
    )


def fit_axis(ticks, axis):
    if len(ticks) < 3:
        return None
    values = [(t, tick_position(t, axis), math.log10(t["value"])) for t in ticks]
    best = None
    for a, b in itertools.combinations(values, 2):
        if abs(a[1] - b[1]) < 20 or abs(a[2] - b[2]) < 1:
            continue
        slope = (b[2] - a[2]) / (b[1] - a[1])
        if (slope > 0) != (axis == "x"):
            continue
        intercept = a[2] - slope * a[1]
        keep = [v for v in values if abs(slope * v[1] + intercept - v[2]) <= 0.045]
        if len(keep) < 3 or len(set(v[2] for v in keep)) < 3:
            continue
        ss, ii = np.polyfit([v[1] for v in keep], [v[2] for v in keep], 1)
        resid = max(abs(ss * v[1] + ii - v[2]) for v in keep)
        rank = (len(keep), max(v[2] for v in keep) - min(v[2] for v in keep), -resid)
        if best is None or rank > best[0]:
            best = (
                rank,
                dict(
                    slope=float(ss),
                    intercept=float(ii),
                    max_log_residual=float(resid),
                    ticks=[v[0] for v in keep],
                ),
            )
    return best[1] if best else None


def calibrate(page, bbox, tokens):
    x0, y0, x1, y1 = bbox
    xt = [
        t
        for t in tokens
        if x0 - 9 <= (t["x0"] + t["x1"]) / 2 <= x1 + 9 and y1 - 1 <= t["top"] <= y1 + 17
    ]
    yt = [
        t
        for t in tokens
        if x0 - 32 <= t["x0"]
        and x0 - 1 >= t["x1"]
        and y0 - 8 <= (t["top"] + t["bottom"]) / 2 <= y1 + 8
    ]
    # Small 2/5 minor ticks in the old Vishay page must not displace decades.
    if yt:
        max_size = max(t["size"] for t in yt)
        yt = [t for t in yt if t["size"] >= max_size * 0.88]
    if xt:
        max_size = max(t["size"] for t in xt)
        xt = [t for t in xt if t["size"] >= max_size * 0.88]
    grid = axis_grid_positions(page, bbox)
    xf, yf = (
        fit_axis(align_ticks_to_grid(xt, "x", grid["x"]), "x"),
        fit_axis(align_ticks_to_grid(yt, "y", grid["y"]), "y"),
    )
    return (xf, yf) if xf and yf else None
