"""Source caption detection."""

import re


def captions(page):
    words = page.extract_words()
    rows = []
    for w in words:
        row = next((r for r in rows if abs(r[0]["top"] - w["top"]) < 3), None)
        if row is None:
            rows.append([w])
        else:
            row.append(w)
    result = []
    blocks = []
    for row in rows:
        row.sort(key=lambda w: w["x0"])
        # Separate columns at actual word gaps before considering the caption.
        segments = [[]]
        for w in row:
            if segments[-1] and w["x0"] - segments[-1][-1]["x1"] > 25:
                segments.append([])
            segments[-1].append(w)
        for ws in segments:
            text = " ".join(w["text"].replace("\x02", " ") for w in ws)
            blocks.append(
                dict(
                    text=text,
                    bbox=[
                        min(w["x0"] for w in ws),
                        min(w["top"] for w in ws),
                        max(w["x1"] for w in ws),
                        max(w["bottom"] for w in ws),
                    ],
                )
            )
            if not re.search(
                r"(?:safe\s+operat(?:ing|ion)\s+area|maximum\s+forward\s+biased)", text, re.I
            ):
                continue
            if not (
                re.match(r"\s*(?:fig(?:ure)?|diagram)[.\s]*\d", text, re.I)
                or re.match(r"\s*(?:maximum\s+)?safe\s+operat", text, re.I)
            ):
                continue
            result.append(
                dict(
                    text=text,
                    bbox=[
                        min(w["x0"] for w in ws),
                        min(w["top"] for w in ws),
                        max(w["x1"] for w in ws),
                        max(w["bottom"] for w in ws),
                    ],
                )
            )
    if not result:
        # Figure 11 in FDMS003N08C wraps its SOA caption over multiple rows.
        for first in blocks:
            if not re.match(r"\s*(?:fig(?:ure)?|diagram)[.\s]*\d", first["text"], re.I):
                continue
            selected = [first]
            box = list(first["bbox"])
            for _ in range(2):
                following = [
                    b
                    for b in blocks
                    if 0 < b["bbox"][1] - box[3] < 15
                    and min(b["bbox"][2], box[2]) - max(b["bbox"][0], box[0])
                    > 0.4 * min(b["bbox"][2] - b["bbox"][0], box[2] - box[0])
                ]
                if not following:
                    break
                nxt = min(following, key=lambda b: b["bbox"][1])
                selected.append(nxt)
                box = [
                    min(box[0], nxt["bbox"][0]),
                    box[1],
                    max(box[2], nxt["bbox"][2]),
                    nxt["bbox"][3],
                ]
                text = " ".join(b["text"] for b in selected)
                if re.search(
                    r"(?:safe\s+operat(?:ing|ion)\s+area|maximum\s+forward\s+biased)", text, re.I
                ):
                    result.append(dict(text=text, bbox=box))
                    break
    return sorted(result, key=lambda c: (c["bbox"][1], c["bbox"][0]))
