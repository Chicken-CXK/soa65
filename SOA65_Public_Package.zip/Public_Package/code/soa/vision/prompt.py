"""Frozen automatic-arm instruction; candidate inventory is explicitly unclean."""

INSTRUCTION = """Extract manufacturer SOA conditions for offline document verification.
The supplied automatic geometry contains UNCLASSIFIED descending vector-stroke
intersections at three voltage probes. It may include DC, fragments, duplicates,
or unrelated strokes; it can omit real curves. It is NOT a cleaned pulsed inventory.
For EVERY candidate curve_id identify curve_kind: pulsed, dc, non_boundary, or
unresolved. For pulsed candidates bind duration_s (seconds), pulse_mode (single
only if stated or explicit zero duty cycle), temperature_symbol (Tmb, TC, TA,
Tj remain distinct), and temperature_C. Null is allowed when unresolved.
Coordinates are PDF points from the top-left. Use the target forward ID-VDS SOA
and its local or inherited section conditions. Do not borrow neighboring thermal,
avalanche or diode conditions. Maximum junction rating is not initial/reference
temperature. Preserve explicit section defaults if the graph has no own condition.
hard_current_cap_A is only a cap unambiguously applying to all supplied pulsed
curves. If caption and pulse-current table conflict in scope, set
scope_conflict_above_A and leave hard_current_cap_A null. Otherwise null is allowed.
Return one JSON object with bindings (array of curve_id, curve_kind, duration_s,
pulse_mode, temperature_symbol, temperature_C), hard_current_cap_A,
scope_conflict_above_A, inventory_notes and short notes. Do not add, move or
digitize new points. Mark non-pulsed candidates with null duration and pulse mode.
This is document extraction, not a claim that a physical device will be safe.
"""

import json
from ..contracts import SCHEMA


def automatic_prompt(front, pack, source, analysis_id):
    panels = []
    images = []
    for i, p in enumerate(pack["panel_packs"], 1):
        local = next(x for x in front["panel_frontends"] if x["source_panel_id"] == p["panel_id"])
        neutral = {
            "document_id": analysis_id,
            "panel_id": p["panel_id"],
            "page": p["geometry"]["page"],
            "plot_bbox": p["geometry"]["plot_bbox"],
            "page_size": p["page_size"],
            "image_region": p["image_region"],
            "caption": local["selected_panel"]["caption"],
            "curves": [
                {
                    k: c.get(k)
                    for k in [
                        "curve_id",
                        "voltage_V",
                        "current_A",
                        "x_pt",
                        "y_pt",
                        "rgb",
                        "source_panel_id",
                        "source_page",
                        "source_panel_bbox",
                        "source_segment",
                        "sample_offsets_pt",
                    ]
                }
                for c in p["geometry"]["curves"]
            ],
        }
        panels.append(
            {
                "geometry": neutral,
                "source_blocks": [b for b in p["blocks"] if b["scope"] != "page_other"],
            }
        )
        images.append(
            {
                "path": p["image_file"],
                "index": i,
                "page_1based": p["geometry"]["page"],
                "crop_pdf_points": p["image_region"],
                "panel_id": p["panel_id"],
            }
        )
    prompt = INSTRUCTION.replace(
        "at three voltage probes.", "at the operator's query voltage."
    ).replace("descending vector-stroke", "descending stroke")
    prompt += "\nEvery supplied panel is a separate source scope. Process ALL supplied panels; do not transfer temperature, pulse mode, legend, or evidence between panels. Candidate IDs are globally unique and match the magenta markers in that panel image. Magenta marks are program-generated locations, not manufacturer labels. Classify DC/grid/non-boundary candidates explicitly. One source stroke may represent several durations; the same curve_id with different durations is allowed when source-supported. Only compare pulse-current order within the same panel, voltage and reference temperature. A hard_current_cap_A may be global only if source text explicitly applies it to all supplied pulsed boundaries; otherwise leave it null. Preserve uncertainties as null.\n"
    prompt += "\nTARGET PART AND PACKAGE EVIDENCE:\n" + json.dumps(
        {"target_part": source["target_part"], "package": front["package"]}, ensure_ascii=False
    )
    prompt += "\nSOURCE PANELS IN IMAGE ORDER (PDF coordinates, top-left origin):\n" + json.dumps(
        panels, ensure_ascii=False
    )
    prompt += "\nCanonical output values: pulse_mode must be single, repeated, DC, or null. D=0 is the single-pulse limit and must be encoded as single. Use temperature symbols TC, TA, Tmb, Tj, or null; preserve the source's numeric value.\n"
    prompt += "\nBefore binding, trace each candidate's original stroke and bends to its own label using the image and source_segment coordinates. Never zip sorted pulse labels with sorted Cxx candidates. A shortest-pulse boundary may remain horizontal at this query voltage and have no descending Cxx; a DC boundary may be one of the supplied Cxx. A missing shortest pulse does not shift all remaining labels. Use unresolved/null when the source association cannot be traced.\n"
    prompt += "\nReturn only the requested JSON. Local schema:\n" + json.dumps(SCHEMA)
    return prompt, images
