"""Raw PDF, target part and query voltage to source-scoped curve candidates."""

import itertools, json, math, re, subprocess, threading
from collections import defaultdict
from pathlib import Path
import cv2
import numpy as np
import pdfplumber
import pypdfium2 as pdfium
from PIL import ImageDraw, ImageFont

PDFIUM_LOCK = threading.Lock()
from .axes import (
    boxes,
    calibrate,
    tick_tokens,
    axis_grid_positions,
    align_ticks_to_grid,
    tick_position,
    merge_grid_positions,
)
from .vectors import intersections, segments
from .captions import captions
from .source_text import rows, inside, referenced_notes


def packages(text):
    text = text.upper().replace("²", "2")
    pattern = r"(?<![A-Z0-9])(?:D2PAK|DPAK|TO[- ]?(?:220FP|220F|220AB|220|247|252|263)|(?:POWERPAK\s*)?SO[- ]?8|LFPAK\d+|CCPAK\d+[A-Z]*)(?![A-Z0-9])"
    return sorted({re.sub(r"[-\s]", "", x) for x in re.findall(pattern, text)})


def target_package(pdf, target):
    evidence = []
    present = False
    for pn, page in enumerate(pdf.pages, 1):
        for line in (page.dedupe_chars(tolerance=1).extract_text() or "").splitlines():
            if target.upper() not in line.upper():
                continue
            present = True
            found = packages(line)
            if len(found) == 1:
                evidence.append(
                    dict(
                        page=pn,
                        text=line,
                        package=found[0],
                        basis="part_and_package_same_native_line",
                    )
                )
    unique = {e["package"] for e in evidence}
    if len(unique) == 1:
        return dict(status="resolved_native", package=next(iter(unique)), evidence=evidence)
    if len(unique) > 1:
        return dict(status="conflicting_native_packages", package=None, evidence=evidence)
    first = pdf.pages[0].dedupe_chars(tolerance=1).extract_text() or ""
    found = packages(first)
    if present and len(found) == 1:
        return dict(
            status="single_first_page_package",
            package=found[0],
            evidence=[dict(page=1, text=first, basis="single_package_on_first_page")],
        )
    return dict(
        status="package_unresolved" if present else "target_part_not_found",
        package=None,
        evidence=[],
    )


def split_grid_boxes(page):
    vertical = defaultdict(list)
    for obj in page.lines + page.curves:
        for a, b in segments(obj):
            if abs(a[0] - b[0]) < 0.8 and abs(a[1] - b[1]) >= 60:
                lo, hi = sorted([a[1], b[1]])
                vertical[(round(lo / 2), round(hi / 2))].append((a[0], lo, hi))
    found = []
    for values in vertical.values():
        groups = []
        for x in sorted(set(round(v[0], 1) for v in values)):
            if not groups or x - groups[-1][-1] > 45:
                groups.append([x])
            else:
                groups[-1].append(x)
        if len(groups) < 2:
            continue
        for xs in groups:
            if len(xs) >= 3 and xs[-1] - xs[0] >= 80:
                found.append([xs[0], min(v[1] for v in values), xs[-1], max(v[2] for v in values)])
    return found


def closed_grid_boxes(page):
    """Use horizontal/vertical endpoint agreement to separate adjacent grids."""
    vertical = defaultdict(list)
    horizontal = []
    for obj in page.lines + page.curves:
        for a, b in segments(obj):
            if abs(a[0] - b[0]) < 0.8 and abs(a[1] - b[1]) >= 60:
                lo, hi = sorted([a[1], b[1]])
                vertical[(round(lo), round(hi))].append(a[0])
            if abs(a[1] - b[1]) < 0.8 and abs(a[0] - b[0]) >= 80:
                lo, hi = sorted([a[0], b[0]])
                horizontal.append((lo, hi, a[1]))
    found = []
    for (y0, y1), xs in vertical.items():
        for x0, x1, y in horizontal:
            if min(abs(y - y0), abs(y - y1)) > 2:
                continue
            if min(abs(x - x0) for x in xs) > 1 or min(abs(x - x1) for x in xs) > 1:
                continue
            b = [x0, float(y0), x1, float(y1)]
            if not any(max(abs(a - c) for a, c in zip(b, old)) < 2 for old in found):
                found.append(b)
    return found


def axis_semantics(page, bbox):
    region = [
        max(0, bbox[0] - 20),
        bbox[3],
        min(page.width, bbox[2] + 20),
        min(page.height, bbox[3] + 40),
    ]
    text = page.crop(region).extract_text() or ""
    compact = re.sub(r"[^a-z]", "", text.lower())
    if "vds" in compact or ("drain" in compact and "voltage" in compact):
        kind = "voltage"
    elif any(
        x in compact
        for x in [
            "duration",
            "time",
            "pulsewidth",
            "thermalimpedance",
            "temperature",
            "frequency",
            "gatecharge",
        ]
    ):
        kind = "other_quantity"
    else:
        kind = "unresolved"
    return dict(kind=kind, text=text)


def image_strip_grids(page):
    """Group narrow raster grid strips found in the source PDF, not label metadata."""
    vs = [i for i in page.images if i["width"] <= 1 and i["height"] >= 60]
    hs = [i for i in page.images if i["height"] <= 1 and i["width"] >= 80]
    result = []
    for h in hs:
        vv = [
            v
            for v in vs
            if h["x0"] - 4 <= v["x0"] <= h["x1"] + 1 and v["top"] - 1 <= h["top"] <= v["bottom"] + 1
        ]
        if len(vv) < 3:
            continue
        x0 = min(v["x0"] for v in vv)
        x1 = max(v["x0"] for v in vv)
        hh = [
            i
            for i in hs
            if abs(i["x0"] - x0) < 4
            and abs(i["x1"] - x1) < 4
            and min(v["top"] for v in vv) - 1 <= i["top"] <= max(v["bottom"] for v in vv) + 1
        ]
        if len(hh) < 3:
            continue
        box = [x0, min(i["top"] for i in hh), x1, max(i["top"] for i in hh)]
        if not any(max(abs(a - b) for a, b in zip(box, old)) < 2 for old in result):
            result.append(box)
    return result


def discover(pdf):
    found = []
    for pn, raw in enumerate(pdf.pages, 1):
        page = raw.dedupe_chars(tolerance=1)
        cs = captions(page)
        if not cs:
            continue
        candidates = [
            dict(bbox=b, kind="native_vector")
            for b in boxes(page) + split_grid_boxes(page) + closed_grid_boxes(page)
        ]
        candidates.extend(dict(bbox=b, kind="raster_strip_grid") for b in image_strip_grids(page))
        candidates.extend(
            dict(bbox=[i["x0"], i["top"], i["x1"], i["bottom"]], kind="embedded_raster")
            for i in page.images
            if i["width"] >= 80 and i["height"] >= 60
        )
        for ci, caption in enumerate(cs, 1):
            cap = caption["bbox"]
            cx = (cap[0] + cap[2]) / 2
            eligible = []
            for c in candidates:
                b = c["bbox"]
                if b[1] < cap[1] < b[3] or not b[0] - 25 <= cx <= b[2] + 25:
                    continue
                gap = min(abs(cap[3] - b[1]), abs(cap[1] - b[3]))
                if gap > 85:
                    continue
                semantics = (
                    axis_semantics(page, b)
                    if c["kind"] == "native_vector"
                    else dict(kind="raster_unread", text="")
                )
                if semantics["kind"] == "other_quantity":
                    continue
                log_axes = (
                    bool(calibrate(page, b, tick_tokens(page)))
                    if c["kind"] == "native_vector"
                    else False
                )
                eligible.append(
                    c | dict(caption_gap_pt=gap, axis_semantics=semantics, native_log_axes=log_axes)
                )
            if not eligible:
                continue
            chosen = min(
                eligible,
                key=lambda c: (
                    c["axis_semantics"]["kind"] != "voltage",
                    c["kind"] != "raster_strip_grid",
                    not c["native_log_axes"],
                    round(c["caption_gap_pt"] / 2),
                    (c["bbox"][2] - c["bbox"][0]) * (c["bbox"][3] - c["bbox"][1]),
                ),
            )
            found.append(
                dict(
                    panel_id=f"P{pn:02}_F{ci:02}",
                    page=pn,
                    caption=caption,
                    caption_packages=packages(caption["text"]),
                    **chosen,
                )
            )
    return found


def choose(panels, package):
    explicit = [p for p in panels if package and package in p["caption_packages"]]
    generic = [p for p in panels if not p["caption_packages"]]
    pool = explicit or generic
    return pool[0] if pool else None


def render(pdf_path, pn, out):
    with PDFIUM_LOCK:
        doc = pdfium.PdfDocument(str(pdf_path))
        page = doc[pn - 1]
        image = page.render(scale=300 / 72).to_pil().copy()
        image.save(out)
        page.close()
        doc.close()
    return image


def raster_frame(image, bbox, page_size):
    sx = image.width / page_size[0]
    sy = image.height / page_size[1]
    rect = (round(bbox[0] * sx), round(bbox[1] * sy), round(bbox[2] * sx), round(bbox[3] * sy))
    crop = np.array(image.crop(rect).convert("L"))
    h, w = crop.shape
    binary = cv2.threshold(crop, 170, 255, cv2.THRESH_BINARY_INV)[1]
    horizontal = cv2.morphologyEx(binary, cv2.MORPH_OPEN, np.ones((1, max(25, w // 3)), np.uint8))
    vertical = cv2.morphologyEx(binary, cv2.MORPH_OPEN, np.ones((max(25, h // 3), 1), np.uint8))
    count, _, stats, _ = cv2.connectedComponentsWithStats(cv2.bitwise_or(horizontal, vertical))
    candidates = []
    for x, y, bw, bh, area in stats[1:]:
        if bw >= w * 0.4 and bh >= h * 0.4:
            candidates.append((int(bw * bh), [int(x), int(y), int(x + bw - 1), int(y + bh - 1)]))
    if not candidates:
        return None
    b = max(candidates)[1]
    return [
        (rect[0] + b[0]) / sx,
        (rect[1] + b[1]) / sy,
        (rect[0] + b[2]) / sx,
        (rect[1] + b[3]) / sy,
    ]


def ocr_tokens(lines, region):
    result = []
    w = region[2] - region[0]
    h = region[3] - region[1]
    for index, line in enumerate(lines):
        text = line["text"].strip().replace("−", "-").replace("–", "-")
        compact = re.sub(r"\s+", "", text)
        # A corner stroke can join the final exponent (observed 10-1L).
        if re.fullmatch(r"10\^?-\dL", compact):
            compact = compact[:-1]
        if re.fullmatch(r"10\^?-\d", compact):
            values = [10 ** int(compact.replace("^", "")[2:])]
        elif compact in ["10°", "10⁰"]:
            values = [1.0]
        elif re.fullmatch(r"\d+(?:\.\d+)?", compact):
            values = [float(compact)]
            if re.fullmatch(r"10[0-6]", compact):
                values.append(float(10 ** int(compact[-1])))
        else:
            continue
        values = [v for v in values if 1e-8 <= v <= 1e8]
        if not values:
            continue
        result.append(
            dict(
                text=text,
                values=values,
                value=values[0],
                id=index,
                x0=region[0] + line["x0"] * w,
                x1=region[0] + line["x1"] * w,
                top=region[1] + line["top"] * h,
                bottom=region[1] + line["bottom"] * h,
                size=(line["bottom"] - line["top"]) * h,
            )
        )
    return result


def fit_ocr_axis(ticks, axis):
    if len(ticks) < 3:
        return None

    def pos(t):
        return tick_position(t, axis)

    hypotheses = [(t, pos(t), math.log10(v), v) for t in ticks for v in t["values"]]
    best = None
    for a, b in itertools.combinations(hypotheses, 2):
        if abs(a[1] - b[1]) < 20 or abs(a[2] - b[2]) < 1:
            continue
        slope = (b[2] - a[2]) / (b[1] - a[1])
        intercept = a[2] - slope * a[1]
        if (slope > 0) != (axis == "x"):
            continue
        keep = []
        for token in ticks:
            options = [v for v in hypotheses if v[0]["id"] == token["id"]]
            value = min(options, key=lambda v: abs(slope * v[1] + intercept - v[2]))
            if abs(slope * value[1] + intercept - value[2]) <= 0.045:
                keep.append(value)
        if len(keep) < 3 or len({v[2] for v in keep}) < 3:
            continue
        ss, ii = np.polyfit([v[1] for v in keep], [v[2] for v in keep], 1)
        resid = max(abs(ss * v[1] + ii - v[2]) for v in keep)
        # Resolve OCR 102 vs 10^2 by geometric agreement, not larger numeric span.
        rank = (len(keep), -resid, max(v[2] for v in keep) - min(v[2] for v in keep))
        if best is None or rank > best[0]:
            best = (
                rank,
                dict(
                    slope=float(ss),
                    intercept=float(ii),
                    max_log_residual=float(resid),
                    ticks=[v[0] | dict(resolved_value=v[3]) for v in keep],
                ),
            )
    return best[1] if best else None


def raster_grid_positions(image, bbox, page_size):
    """Locate long raster grid strokes in page coordinates for OCR calibration."""
    sx = image.width / page_size[0]
    sy = image.height / page_size[1]
    rect = (
        round(bbox[0] * sx),
        round(bbox[1] * sy),
        round(bbox[2] * sx) + 1,
        round(bbox[3] * sy) + 1,
    )
    gray = np.array(image.crop(rect).convert("L"))
    h, w = gray.shape
    binary = cv2.threshold(gray, 170, 255, cv2.THRESH_BINARY_INV)[1]
    result = {}
    for axis, kernel, dimension, scale, origin in [
        ("x", (max(25, int(h * 0.8)), 1), 0, sx, rect[0]),
        ("y", (1, max(25, int(w * 0.8))), 1, sy, rect[1]),
    ]:
        strokes = cv2.morphologyEx(binary, cv2.MORPH_OPEN, np.ones(kernel, np.uint8))
        counts = np.count_nonzero(strokes, axis=dimension)
        threshold = (h if axis == "x" else w) * 0.8
        result[axis] = merge_grid_positions(
            [(origin + i) / scale for i in np.flatnonzero(counts >= threshold)]
        )
    return result


def calibrate_ocr(bbox, tokens, grid=None):
    x0, y0, x1, y1 = bbox
    xt = [
        t
        for t in tokens
        if x0 - 9 <= (t["x0"] + t["x1"]) / 2 <= x1 + 9 and y1 - 1 <= t["top"] <= y1 + 17
    ]
    yt = [
        t
        for t in tokens
        if x0 - 32 <= t["x0"]
        and t["x1"] <= x0 + 2
        and (t["x0"] + t["x1"]) / 2 <= x0 - 3
        and y0 - 8 <= (t["top"] + t["bottom"]) / 2 <= y1 + 8
    ]
    if grid:
        xt = align_ticks_to_grid(xt, "x", grid["x"])
        yt = align_ticks_to_grid(yt, "y", grid["y"])
    xf, yf = fit_ocr_axis(xt, "x"), fit_ocr_axis(yt, "y")
    if grid and not (xf and yf):
        # Real raster grids can omit a usable line; retain the original OCR fit.
        return calibrate_ocr(bbox, tokens, grid=None)
    return (xf, yf) if xf and yf else None


def native_intersections(page, bbox, x):
    hits = []
    for offset in [0, -0.5, 0.5, -1, 1, -2, 2]:
        for hit in intersections(page, bbox, x + offset):
            a, b = hit["segment"]
            dx = b[0] - a[0]
            if dx == 0:
                continue
            y = a[1] + (x - a[0]) * (b[1] - a[1]) / dx
            if not bbox[1] + 1 < y < bbox[3] - 1:
                continue
            hits.append(hit | dict(y=y, sample_offset_pt=offset))
    groups = []
    for hit in sorted(hits, key=lambda h: h["y"]):
        match = next(
            (
                g
                for g in groups
                if abs(hit["y"] - g[0]["y"])
                <= (2 if set(hit["sources"]) & set(g[0]["sources"]) else 0.65)
                and hit["rgb"] == g[0]["rgb"]
            ),
            None,
        )
        if match is None:
            groups.append([hit])
        else:
            match.append(hit)
    result = []
    for group in groups:
        best = min(group, key=lambda h: abs(h["sample_offset_pt"]))
        result.append(best | dict(sample_offsets_pt=sorted({h["sample_offset_pt"] for h in group})))
    return sorted(result, key=lambda h: h["y"])


def raster_intersections(image, bbox, page_size, x_query, ocr=None, region=None):
    sx = image.width / page_size[0]
    sy = image.height / page_size[1]
    rect = (round(bbox[0] * sx), round(bbox[1] * sy), round(bbox[2] * sx), round(bbox[3] * sy))
    gray = np.array(image.crop(rect).convert("L"))
    h, w = gray.shape
    binary = cv2.threshold(gray, 170, 255, cv2.THRESH_BINARY_INV)[1]
    horizontal = cv2.morphologyEx(binary, cv2.MORPH_OPEN, np.ones((1, max(20, w // 4)), np.uint8))
    vertical = cv2.morphologyEx(binary, cv2.MORPH_OPEN, np.ones((max(20, h // 4), 1), np.uint8))
    ink = cv2.bitwise_and(binary, cv2.bitwise_not(cv2.bitwise_or(horizontal, vertical)))
    # Remove recognized short text blocks before fitting local line segments.
    # Large/rotated OCR boxes are not masks: they can cover real curve paths.
    if ocr and region:
        rw = region[2] - region[0]
        rh = region[3] - region[1]
        for token in ocr:
            b = [
                region[0] + token["x0"] * rw,
                region[1] + token["top"] * rh,
                region[0] + token["x1"] * rw,
                region[1] + token["bottom"] * rh,
            ]
            if b[3] - b[1] > 14 or b[2] - b[0] > (bbox[2] - bbox[0]) * 0.45:
                continue
            left = max(0, round(b[0] * sx - rect[0]) - 1)
            right = min(w, round(b[2] * sx - rect[0]) + 1)
            top = max(0, round(b[1] * sy - rect[1]) - 1)
            bottom = min(h, round(b[3] * sy - rect[1]) + 1)
            if left < right and top < bottom:
                ink[top:bottom, left:right] = 0
    x = x_query * sx - rect[0]
    radius = max(25, round(w * 0.12))
    lo = max(0, round(x - radius))
    hi = min(w, round(x + radius))
    band = ink[:, lo:hi]
    segments = cv2.HoughLinesP(band, 1, np.pi / 720, threshold=10, minLineLength=15, maxLineGap=12)
    hits = []
    for line in [] if segments is None else segments.reshape(-1, 4):
        x0, y0, x1, y1 = map(float, line)
        x0 += lo
        x1 += lo
        if x0 > x1:
            x0, y0, x1, y1 = x1, y1, x0, y0
        dx = x1 - x0
        dy = y1 - y0
        if dx < 3 or dy < 3 or not x0 - 5 <= x <= x1 + 5:
            continue
        y = y0 + (x - x0) * dy / dx
        if not 2 < y < h - 2:
            continue
        hits.append(
            dict(
                y=(rect[1] + y) / sy,
                rgb=[0, 0, 0],
                source="raster_local_hough",
                segment=[
                    [(rect[0] + x0) / sx, (rect[1] + y0) / sy],
                    [(rect[0] + x1) / sx, (rect[1] + y1) / sy],
                ],
                line_width=1,
            )
        )
    groups = []
    for hit in sorted(hits, key=lambda a: a["y"]):
        if groups and hit["y"] - groups[-1][-1]["y"] <= 1:
            groups[-1].append(hit)
        else:
            groups.append([hit])
    return [
        g[len(g) // 2]
        | dict(y=float(np.median([v["y"] for v in g])), sources=["raster_local_hough"])
        for g in groups
    ]


def build(pdf_path, target, voltage, out, *, ocr_command, panel_override=None, curve_id_offset=0):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    pdf_path = Path(pdf_path)
    with pdfplumber.open(pdf_path) as pdf:
        package = target_package(pdf, target)
        panels = discover(pdf)
        selected = panel_override or choose(panels, package["package"])
        result = dict(
            document_id=pdf_path.stem,
            target_part=target,
            voltage_V=voltage,
            package=package,
            panels=panels,
            selected_panel=selected,
            status="selection_failed",
        )
        if package["status"] == "target_part_not_found" or selected is None:
            (out / "frontend.json").write_text(json.dumps(result, indent=2) + "\n")
            return result
        pn = selected["page"]
        page = pdf.pages[pn - 1].dedupe_chars(tolerance=1)
        size = [float(page.width), float(page.height)]
        image = render(pdf_path, pn, out / "page.png")
        bbox = selected["bbox"]
        if selected["kind"] == "embedded_raster":
            bbox = raster_frame(image, bbox, size)
            if bbox is None:
                result["status"] = "raster_frame_not_found"
                (out / "frontend.json").write_text(json.dumps(result, indent=2) + "\n")
                return result
        region = [
            max(0, bbox[0] - 45),
            max(0, min(bbox[1] - 25, selected["caption"]["bbox"][1] - 5)),
            min(size[0], bbox[2] + 45),
            min(size[1], max(bbox[3] + 45, selected["caption"]["bbox"][3] + 20)),
        ]
        sx = image.width / size[0]
        sy = image.height / size[1]
        crop = image.crop(
            tuple(round(v * (sx if i % 2 == 0 else sy)) for i, v in enumerate(region))
        )
        crop.save(out / "selected.png")
        ocr = json.loads(
            subprocess.run(
                [str(ocr_command), str(out / "selected.png")],
                check=True,
                capture_output=True,
                text=True,
            ).stdout
        )
        (out / "ocr.json").write_text(json.dumps(ocr, indent=2) + "\n")
        fitted = (
            calibrate(page, bbox, tick_tokens(page))
            if selected["kind"] == "native_vector"
            else None
        )
        basis = "native_ticks"
        if not fitted:
            grid = axis_grid_positions(page, bbox)
            if any(len(grid[axis]) < 3 for axis in ["x", "y"]):
                raster_grid = raster_grid_positions(image, bbox, size)
                grid = {
                    axis: grid[axis] if len(grid[axis]) >= 3 else raster_grid[axis]
                    for axis in ["x", "y"]
                }
            fitted = calibrate_ocr(bbox, ocr_tokens(ocr, region), grid)
            basis = "ocr_ticks"
        result.update(
            plot_bbox=bbox,
            image_region=region,
            page=pn,
            page_size=size,
            calibration_basis=basis,
            status="axis_calibration_failed",
        )
        blocks = []
        for i, b in enumerate(rows(page)):
            blocks.append(
                b
                | dict(
                    id=f"N{i:03}",
                    page=pn,
                    origin="native",
                    scope="selected" if inside(b["bbox"], region) else "page_other",
                )
            )
        for i, b in enumerate(ocr):
            blocks.append(
                dict(
                    id=f"O{i:03}",
                    page=pn,
                    origin="ocr",
                    scope="selected",
                    text=b["text"],
                    bbox=[
                        region[0] + b["x0"] * (region[2] - region[0]),
                        region[1] + b["top"] * (region[3] - region[1]),
                        region[0] + b["x1"] * (region[2] - region[0]),
                        region[1] + b["bottom"] * (region[3] - region[1]),
                    ],
                )
            )
        context = []
        for pi in range(pn):
            for b in rows(pdf.pages[pi]):
                if pi == pn - 1 and b["bbox"][1] >= region[1]:
                    continue
                if re.search(
                    r"(?:\bT\s*[_ ]?\s*(?:C|A|J|MB)\b|temperature|unless|single.?pulse|duty)",
                    b["text"],
                    re.I,
                ):
                    context.append(
                        b | dict(page=pi + 1, origin="native", scope="preceding_context")
                    )
        blocks.extend(b | dict(id=f"D{i:03}") for i, b in enumerate(context[-24:]))
        if fitted:
            xf, yf = fitted
            x = (math.log10(voltage) - xf["intercept"]) / xf["slope"]
            result.update(x_axis=xf, y_axis=yf, query_x_pt=x, status="query_voltage_outside_plot")
            if bbox[0] <= x <= bbox[2]:
                hits = (
                    native_intersections(page, bbox, x)
                    if selected["kind"] == "native_vector"
                    else raster_intersections(image, bbox, size, x, ocr, region)
                )
                curves = []
                for i, h in enumerate(hits, 1):
                    logi = yf["slope"] * h["y"] + yf["intercept"]
                    e = abs(yf["slope"]) * 2
                    curves.append(
                        dict(
                            curve_id=f"C{i + curve_id_offset:02}",
                            voltage_V=voltage,
                            current_A=10**logi,
                            current_low_A=10 ** (logi - e),
                            current_high_A=10 ** (logi + e),
                            x_pt=x,
                            y_pt=h["y"],
                            rgb=h["rgb"],
                            source_objects=h["sources"],
                            source_segment=h["segment"],
                            sample_offsets_pt=h.get("sample_offsets_pt", []),
                        )
                    )
                result.update(
                    status="candidates_emitted" if curves else "no_curve_candidates", curves=curves
                )
                mark = crop.copy()
                draw = ImageDraw.Draw(mark)
                xx = (x - region[0]) * sx
                draw.line((xx, 0, xx, mark.height), fill=(210, 0, 170), width=2)
                font = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 16)
                for c in curves:
                    yy = (c["y_pt"] - region[1]) * sy
                    draw.ellipse((xx - 5, yy - 5, xx + 5, yy + 5), outline=(210, 0, 170), width=2)
                    draw.text(
                        (xx + 8, yy - 10),
                        c["curve_id"],
                        font=font,
                        fill=(160, 0, 130),
                        stroke_width=1,
                        stroke_fill="white",
                    )
                mark.save(out / "marked.png")
        neutral = {k: result[k] for k in ["document_id", "page", "plot_bbox"]}
        neutral["curves"] = result.get("curves", [])
        (out / "source_pack.json").write_text(
            json.dumps(
                dict(
                    geometry=neutral,
                    page_size=size,
                    image_region=region,
                    blocks=blocks,
                    provenance="raw PDF plus target part and query voltage; no reference geometry or bindings",
                ),
                indent=2,
                ensure_ascii=False,
            )
            + "\n"
        )
        (out / "frontend.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
        return result


def caption_part_scope(page, caption):
    """Recover wrapped 'for <part>' caption scope without changing plot anchors."""
    box = list(caption["bbox"])
    lines = [caption["text"]]
    for _ in range(2):
        following = [
            b
            for b in rows(page)
            if 0 < b["bbox"][1] - box[3] < 15
            and not re.match(r"\s*(?:Fig(?:ure)?|Diagram)[.\s]*\d", b["text"], re.I)
            and min(b["bbox"][2], box[2]) - max(b["bbox"][0], box[0])
            > 0.4 * min(b["bbox"][2] - b["bbox"][0], box[2] - box[0])
        ]
        if not following:
            break
        nxt = min(following, key=lambda b: b["bbox"][1])
        lines.append(nxt["text"])
        box[3] = nxt["bbox"][3]
    text = " ".join(lines)
    suffix = re.split(r"\bfor\b", text, flags=re.I)
    parts = []
    if len(suffix) > 1:
        package_names = set(packages(text))
        parts = [
            x
            for x in re.findall(r"\b[A-Z][A-Z0-9-]*\d[A-Z0-9-]*\b", suffix[-1])
            if re.sub(r"[-\s]", "", x) not in package_names
        ]
    return caption | {"text": text, "target_parts": parts}


def applicable_panels(panels, package, target=None):
    """Keep every applicable SOA panel; caption package scope still takes precedence."""
    panels = [
        p
        for p in panels
        if not p.get("caption", {}).get("target_parts") or target in p["caption"]["target_parts"]
    ]
    explicit = [p for p in panels if package and package in p["caption_packages"]]
    pool = explicit or [p for p in panels if not p["caption_packages"]]
    unique = []
    for panel in sorted(pool, key=lambda p: (p["page"], p["bbox"][1], p["bbox"][0])):
        a = panel["bbox"]
        duplicate = False
        for old in unique:
            b = old["bbox"]
            inter = max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(
                0, min(a[3], b[3]) - max(a[1], b[1])
            )
            union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
            if panel["page"] == old["page"] and union and inter / union > 0.8:
                duplicate = True
                break
        if not duplicate:
            unique.append(panel)
    return unique


def build_all(pdf_path, target, voltage, out, *, ocr_command):
    """Source-only discovery of all temperature/package-compatible panels.

    Individual panels keep local coordinates, text and crop metadata. Candidate
    IDs are globally unique and are drawn onto the actual corresponding crops.
    """
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    with pdfplumber.open(pdf_path) as pdf:
        package = target_package(pdf, target)
        discovered = discover(pdf)
        for panel in discovered:
            panel["caption"] = caption_part_scope(pdf.pages[panel["page"] - 1], panel["caption"])
    selected = (
        applicable_panels(discovered, package["package"], target)
        if package["status"] != "target_part_not_found"
        else []
    )
    fronts, packs, curves, sources = [], [], [], []
    for index, panel in enumerate(selected, 1):
        pid = f"P{index:02}"
        folder = out / "panels" / pid
        f = build(
            pdf_path,
            target,
            voltage,
            folder,
            ocr_command=ocr_command,
            panel_override=panel,
            curve_id_offset=len(curves),
        )
        f["source_panel_id"] = pid
        f["panel_id"] = pid
        for c in f.get("curves", []):
            c.update(source_panel_id=pid, source_page=f["page"], source_panel_bbox=f["plot_bbox"])
        fronts.append(f)
        source = {
            "panel_id": pid,
            "page": panel["page"],
            "plot_bbox": f.get("plot_bbox", panel["bbox"]),
            "status": f["status"],
            "caption": panel["caption"],
        }
        sources.append(source)
        if (folder / "source_pack.json").exists():
            pack = json.loads((folder / "source_pack.json").read_text())
            pack["blocks"].extend(
                referenced_notes(pdf_path, panel["caption"]["text"], panel["page"])
            )
            pack["panel_id"] = pid
            pack["geometry"]["curves"] = f.get("curves", [])
            for block in pack["blocks"]:
                block["id"] = pid + "_" + block["id"]
                block["panel_id"] = pid
            pack["image_file"] = (
                str((folder / "marked.png").resolve())
                if f.get("curves")
                else str((folder / "selected.png").resolve())
            )
            packs.append(pack)
            (folder / "source_pack.json").write_text(
                json.dumps(pack, ensure_ascii=False, indent=2) + "\n"
            )
        (folder / "frontend.json").write_text(json.dumps(f, ensure_ascii=False, indent=2) + "\n")
        curves.extend(f.get("curves", []))
    result = (
        dict(fronts[0])
        if fronts
        else {
            "document_id": Path(pdf_path).stem,
            "target_part": target,
            "voltage_V": voltage,
            "package": package,
        }
    )
    result.update(
        status="candidates_emitted"
        if curves
        else "no_curve_candidates"
        if selected
        else "selection_failed",
        curves=curves,
        panels=discovered,
        source_panels=sources,
        panel_frontends=fronts,
        frontend_version="multi-panel-v2",
    )
    rootpack = {
        "geometry": {
            "document_id": result["document_id"],
            "page": result.get("page"),
            "plot_bbox": result.get("plot_bbox"),
            "source_panels": sources,
            "curves": curves,
        },
        "panel_packs": packs,
        "blocks": [b for pack in packs for b in pack["blocks"]],
        "provenance": "all applicable SOA panels discovered from source PDF, target part and query voltage; no reference annotations",
    }
    (out / "frontend.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    (out / "source_pack.json").write_text(json.dumps(rootpack, ensure_ascii=False, indent=2) + "\n")
    return result
