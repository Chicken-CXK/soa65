"""Font-aware PDF text and explicitly referenced source notes."""

import re
import pdfplumber


def rows(page):
    groups = []
    for w in page.dedupe_chars(tolerance=1).extract_words(return_chars=True):
        # SymbolMT encodes Greek mu as the Latin character m; Arial m is milliseconds.
        w["text"] = "".join(
            "µ" if c["text"] == "m" and "symbol" in c.get("fontname", "").lower() else c["text"]
            for c in w["chars"]
        )
        group = next((g for g in groups if abs(g[0]["top"] - w["top"]) < 3), None)
        if group is None:
            groups.append([w])
        else:
            group.append(w)
    result = []
    for group in groups:
        group.sort(key=lambda w: w["x0"])
        parts = [[]]
        for w in group:
            if parts[-1] and w["x0"] - parts[-1][-1]["x1"] > 25:
                parts.append([])
            parts[-1].append(w)
        for ws in parts:
            result.append(
                dict(
                    text=" ".join(w["text"] for w in ws),
                    bbox=[
                        min(w["x0"] for w in ws),
                        min(w["top"] for w in ws),
                        max(w["x1"] for w in ws),
                        max(w["bottom"] for w in ws),
                    ],
                )
            )
    return sorted(result, key=lambda x: (x["bbox"][1], x["bbox"][0]))


def inside(box, region):
    x = (box[0] + box[2]) / 2
    y = (box[1] + box[3]) / 2
    return region[0] <= x <= region[2] and region[1] <= y <= region[3]


def referenced_notes(pdf_path, caption_text, page_number):
    """Only notes explicitly named by this caption may supply remote conditions."""
    letters = set(re.findall(r"\bNote\s+([A-Z])\b", caption_text, re.I))
    if not letters:
        return []
    result = []
    with pdfplumber.open(pdf_path) as pdf:
        for pn, page in enumerate(pdf.pages[:page_number], 1):
            blocks = rows(page)
            for i, block in enumerate(blocks):
                m = re.match(r"^([A-Z])\.\s+", block["text"])
                if not m or m.group(1) not in letters:
                    continue
                selected = [block]
                last = block
                for nxt in blocks[i + 1 : i + 5]:
                    if re.match(r"^[A-Z]\.\s+", nxt["text"]):
                        break
                    if not -2 <= nxt["bbox"][1] - last["bbox"][3] < 16:
                        break
                    if abs(nxt["bbox"][0] - block["bbox"][0]) > 25:
                        break
                    selected.append(nxt)
                    last = nxt
                    if nxt["text"].rstrip().endswith("."):
                        break
                result.append(
                    {
                        "id": f"NOTE_{pn}_{m.group(1)}",
                        "page": pn,
                        "origin": "native",
                        "scope": "referenced_note",
                        "note_reference": m.group(1),
                        "text": " ".join(x["text"] for x in selected),
                        "bbox": [
                            block["bbox"][0],
                            block["bbox"][1],
                            max(x["bbox"][2] for x in selected),
                            last["bbox"][3],
                        ],
                    }
                )
    return result
