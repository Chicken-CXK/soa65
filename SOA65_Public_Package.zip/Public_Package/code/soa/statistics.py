"""One implementation for metrics, cohort aggregation and paired model summaries."""

from collections import defaultdict
from .storage import save

LABELS = ["SUPPORTED", "SCREEN_FAIL", "INSUFFICIENT", "NO_OUTPUT"]


def average(values):
    values = [x for x in values if x is not None]
    return sum(values) / len(values) if values else None


def metrics(rows):
    n = len(rows)
    correct = sum(r["gold"] == r["prediction"] for r in rows)
    decisive = [r for r in rows if r["gold"] != "INSUFFICIENT"]
    released = [r for r in rows if r["prediction"] == "SUPPORTED"]
    false = sum(r["gold"] != "SUPPORTED" for r in released)
    unsupported = sum(r["gold"] != "SUPPORTED" for r in rows)
    return dict(
        n=n,
        correct=correct,
        label_accuracy=correct / n if n else None,
        eligible_decisions=len(decisive),
        correct_decision_coverage=(
            sum(r["gold"] == r["prediction"] for r in decisive) / len(decisive)
        )
        if decisive
        else None,
        actual_releases=len(released),
        false_releases=false,
        false_release_fraction=false / len(released) if released else None,
        non_supported_cases=unsupported,
        false_release_over_non_supported=false / unsupported if unsupported else None,
        no_output=sum(r["prediction"] == "NO_OUTPUT" for r in rows),
        abstentions=sum(r["prediction"] == "INSUFFICIENT" for r in rows),
        confusion={
            g: {p: sum(r["gold"] == g and r["prediction"] == p for r in rows) for p in LABELS}
            for g in LABELS[:-1]
        },
    )


def metric_counts(ds):
    m = metrics(ds)
    return m | {
        "label_agreement_fraction": [m["correct"], m["n"]],
        "FR_R_fraction": [m["false_releases"], m["actual_releases"]],
        "FR_N_fraction": [m["false_releases"], m["non_supported_cases"]],
        "CDC_fraction": [
            sum(d["gold"] == d["prediction"] and d["gold"] != "INSUFFICIENT" for d in ds),
            m["eligible_decisions"],
        ],
        "NO_OUTPUT_fraction": [m["no_output"], m["n"]],
    }


def aggregate(records, out):
    # repeats first within analysis, probes within source document, documents within family.
    groups = defaultdict(list)
    for r in records:
        groups[(r["arm"], r["cohort"], r["profile"], r["mode"], r["policy"], r["pipeline"])].append(
            r
        )
    summaries = []
    for key, rs in groups.items():
        bydoc = defaultdict(list)
        for r in rs:
            bydoc[r["doc_id"]].append(r)
        docs = []
        for doc, xs in bydoc.items():
            probes = defaultdict(list)
            for x in xs:
                probes[x["analysis_id"]].append(x)
            means = []
            for probe, ys in probes.items():
                means.append(
                    {
                        k: average([y[k] for y in ys])
                        for k in [
                            "label_accuracy",
                            "correct_decision_coverage",
                            "binding_agreement",
                            "false_release_fraction",
                            "false_release_over_non_supported",
                        ]
                    }
                )
            docs.append(
                {
                    "doc_id": doc,
                    "family": xs[0]["family"],
                    **{k: average([x[k] for x in means]) for k in means[0]},
                }
            )
        fam = defaultdict(list)
        for d in docs:
            fam[d["family"]].append(d)
        fammeans = {
            f: {
                k: average([x[k] for x in xs])
                for k in [
                    "label_accuracy",
                    "correct_decision_coverage",
                    "binding_agreement",
                    "false_release_fraction",
                    "false_release_over_non_supported",
                ]
            }
            for f, xs in fam.items()
        }
        summaries.append(
            {
                "configuration": key,
                "documents": len(docs),
                "repeats_are_not_independent_sources": True,
                "counts_over_all_prespecified_repeats": {
                    k: sum(r[k] for r in rs)
                    for k in [
                        "n",
                        "correct",
                        "false_releases",
                        "actual_releases",
                        "non_supported_cases",
                        "eligible_decisions",
                        "no_output",
                    ]
                },
                "document_results": docs,
                "family_results": fammeans,
                "family_macro": {
                    k: average([v[k] for v in fammeans.values()])
                    for k in next(iter(fammeans.values()))
                },
            }
        )
    save(out / "summary.json", summaries)
    return summaries


def paired_results(summaries, results, pair=("qwen", "kimi")):
    left, right = pair
    difference_key = right + "_minus_" + left
    paired = []
    for a in summaries:
        if a["configuration"][2] != left:
            continue
        b = next(
            (
                b
                for b in summaries
                if b["configuration"][:2] == a["configuration"][:2]
                and b["configuration"][2] == right
                and b["configuration"][3:] == a["configuration"][3:]
            ),
            None,
        )
        if b is None:
            continue
        for x in a["document_results"]:
            y = next(z for z in b["document_results"] if z["doc_id"] == x["doc_id"])
            paired.append(
                {
                    "configuration": a["configuration"],
                    "doc_id": x["doc_id"],
                    "family": x["family"],
                    difference_key: {
                        k: y[k] - x[k] if x[k] is not None and y[k] is not None else None
                        for k in [
                            "label_accuracy",
                            "correct_decision_coverage",
                            "binding_agreement",
                        ]
                    },
                }
            )
    save(results / "paired_documents.json", paired)
    fam = defaultdict(list)
    for p in paired:
        fam[(tuple(p["configuration"]), p["family"])].append(p)
    families = [
        {
            "configuration": cfg,
            "family": family,
            difference_key: {
                k: average([p[difference_key][k] for p in ps])
                for k in ["label_accuracy", "correct_decision_coverage", "binding_agreement"]
            },
        }
        for (cfg, family), ps in fam.items()
    ]
    save(results / "paired_families.json", families)
    # Clustered source-composition sensitivity; repeats/queries are not independent units.
    import random

    rng = random.Random(20260908)
    bycfg = defaultdict(list)
    for row in families:
        bycfg[tuple(row["configuration"])].append(row)
    ranges = []
    for cfg, fs in bycfg.items():
        stats = {}
        for metric in ["label_accuracy", "correct_decision_coverage", "binding_agreement"]:
            vs = [f[difference_key][metric] for f in fs if f[difference_key][metric] is not None]
            bs = (
                sorted(sum(rng.choice(vs) for _ in vs) / len(vs) for _ in range(2000)) if vs else []
            )
            stats[metric] = {
                "mean": average(vs),
                "source_composition_range_95": [bs[49], bs[1949]] if bs else None,
                "families": len(vs),
            }
        ranges.append(
            {"configuration": cfg, "statistics": stats, "seed": 20260908, "replicates": 2000}
        )
    save(results / "source_sensitivity.json", ranges)
