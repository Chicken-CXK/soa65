"""Source-only layout rules for frontends that contain several SOA panels.

The historical extractor treated every curve in a plot as a pulse boundary.
That makes a plot with five printed pulse widths and a printed DC boundary
look inconsistent, and consequently produces no bindings at all.  This
module keeps the panel-local source evidence separate and classifies only the
extra candidate that is supported by the local DC label and its position in
the printed legend.  An unsupported extra candidate remains ``unresolved``.

The module intentionally consumes only ``front`` and ``pack``.  In
particular, it does not inspect reference annotations or result files.
"""

from __future__ import annotations

import math
import re
from typing import Any

from .consistency import facts, printed_durations, temp_type


_DURATION_RE = re.compile(
    r"(?<![\d.])\d(?:\s*\d)*(?:\.\s*\d(?:\s*\d)*)?\s*"
    r"(?:n\s*s|u\s*s|m\s*s|s)\b",
    re.IGNORECASE,
)
_DC_RE = re.compile(r"(?<![A-Z0-9])DC(?![A-Z0-9])", re.IGNORECASE)
_D_ZERO_RE = re.compile(r"(?:\bD|duty\s*cycle)\s*[=:]\s*0(?:\.0+)?(?![\d.])", re.IGNORECASE)


def _text(value: Any) -> str:
    """Make native PDF control separators harmless for local text checks."""

    return str(value or "").replace("\x02", " ").replace("\u0003", " ").replace("\u0004", " ")


def _selected_blocks(pack: dict) -> list[dict]:
    return [block for block in pack.get("blocks", []) if block.get("scope") == "selected"]


def _panel_frontends(front: dict) -> dict[str, dict]:
    """Index panel frontends by either supported panel id field."""

    entries = front.get("panel_frontends", [])
    if isinstance(entries, dict):
        entries = [
            value | {"panel_id": key}
            if isinstance(value, dict)
            and not value.get("panel_id")
            and not value.get("source_panel_id")
            else value
            for key, value in entries.items()
        ]
    result: dict[str, dict] = {}
    for entry in entries or []:
        if not isinstance(entry, dict):
            continue
        panel_id = entry.get("source_panel_id") or entry.get("panel_id")
        if panel_id is not None:
            result[str(panel_id)] = entry
    return result


def _panel_packs(pack: dict) -> list[dict]:
    panels = pack.get("panel_packs")
    if isinstance(panels, list) and panels:
        return [panel for panel in panels if isinstance(panel, dict)]
    return [pack]


def _curves(front: dict, panel_pack: dict, panel_front: dict | None) -> list[dict]:
    """Return the panel's curves while preserving global Cxx identifiers."""

    local = panel_pack.get("geometry", {}).get("curves", [])
    if isinstance(local, list) and local:
        curves = local
    elif isinstance(panel_front, dict) and panel_front.get("curves"):
        curves = panel_front["curves"]
    else:
        panel_id = panel_pack.get("panel_id")
        curves = [
            curve
            for curve in front.get("curves", [])
            if panel_id is None or curve.get("source_panel_id") == panel_id
        ]

    # A source pack should already be unique.  Deduplicating here prevents a
    # malformed repeated Cxx from producing a second relation while retaining
    # the first source record for auditability.
    seen: set[str] = set()
    result = []
    for curve in curves:
        if not isinstance(curve, dict) or curve.get("curve_id") is None:
            continue
        curve_id = str(curve["curve_id"])
        if curve_id in seen:
            continue
        seen.add(curve_id)
        result.append(curve)
    return result


def _curve_sort_key(curve: dict) -> tuple:
    current = curve.get("current_A")
    y = curve.get("y_pt")
    # SOA intersections are ordered top-to-bottom by decreasing current.  The
    # y coordinate is a source-only fallback when current was not calibrated.
    current_key = (
        -float(current) if isinstance(current, (int, float)) and math.isfinite(current) else 0.0
    )
    y_key = float(y) if isinstance(y, (int, float)) and math.isfinite(y) else float("inf")
    return current_key, y_key, str(curve.get("curve_id"))


def _condition(pack: dict) -> tuple[str | None, float | None, str | None, dict]:
    """Extract temperature and pulse facts from this panel's source text."""

    _, temperatures, pulse_evidence = facts(pack)
    normalized: dict[tuple[str, float], list[str]] = {}
    for (symbol, value), evidence in temperatures.items():
        try:
            normalized[(str(temp_type(symbol)), float(value))] = list(evidence)
        except (TypeError, ValueError):
            continue

    blocks = _selected_blocks(pack)
    source_text = " ".join(_text(block.get("text")) for block in blocks)
    d_zero = bool(_D_ZERO_RE.search(source_text))
    single_pulse = (
        bool(pulse_evidence)
        or bool(re.search(r"single\s*pulse", source_text, re.IGNORECASE))
        or d_zero
    )

    # One temperature fact is the ordinary panel contract.  If source text
    # leaves multiple temperatures, preserve the ambiguity instead of making
    # a panel-wide guess.
    boundary = {key: value for key, value in normalized.items() if key[0] != "Tj"}
    applicable = boundary or normalized
    if len(applicable) == 1:
        (symbol, value), evidence = next(iter(applicable.items()))
        temperature_symbol: str | None = symbol
        temperature_C: float | None = value
    else:
        temperature_symbol = None
        temperature_C = None
        evidence = []

    return (
        temperature_symbol,
        temperature_C,
        "single" if single_pulse else None,
        {
            "temperatures": [
                {"temperature_symbol": symbol, "temperature_C": value, "evidence": ids}
                for (symbol, value), ids in sorted(normalized.items())
            ],
            "temperature_evidence": evidence,
            "single_pulse_evidence": list(pulse_evidence),
            "duty_cycle_zero": d_zero,
        },
    )


def _center_y(block: dict) -> float | None:
    bbox = block.get("bbox")
    if not isinstance(bbox, (list, tuple)) or len(bbox) < 4:
        return None
    try:
        return (float(bbox[1]) + float(bbox[3])) / 2.0
    except (TypeError, ValueError):
        return None


def _dc_support(pack: dict, durations: set[float], curves: list[dict]) -> tuple[bool, dict]:
    """Assess whether exactly one extra curve is locally supported as DC."""

    blocks = _selected_blocks(pack)
    dc_blocks = [block for block in blocks if _DC_RE.search(_text(block.get("text")))]
    duration_blocks = [block for block in blocks if _DURATION_RE.search(_text(block.get("text")))]
    dc_ys = [y for block in dc_blocks if (y := _center_y(block)) is not None]
    duration_ys = [y for block in duration_blocks if (y := _center_y(block)) is not None]

    # The inventory may omit shortest horizontal pulses. A DC token alone is not
    # enough: axis text and unrelated surrounding text can contain ``DC``.
    count_supported = 1 < len(curves) <= len(durations) + 1 and len(durations) > 0
    if not dc_blocks or not count_supported:
        return False, {
            "supported": False,
            "reason": "missing_local_dc_or_inventory_support",
            "block_ids": [block.get("id") for block in dc_blocks],
            "position": {"dc_y": dc_ys, "duration_y": duration_ys},
        }

    # Labels in the supplied SOA panels are laid out in boundary order.  The
    # DC label is below the printed pulse labels; requiring that ordering keeps
    # an incidental DC token from classifying an arbitrary candidate.
    position_supported = bool(dc_ys and duration_ys and min(dc_ys) >= max(duration_ys) - 3.0)
    supported = position_supported
    return supported, {
        "supported": supported,
        "reason": "local_dc_label_inventory_and_position"
        if supported
        else "local_dc_position_ambiguous",
        "block_ids": [block.get("id") for block in dc_blocks],
        "position": {"dc_y": dc_ys, "duration_y": duration_ys},
    }


def _extract_panel(
    front: dict, panel_pack: dict, panel_front: dict | None
) -> tuple[list[dict], dict]:
    panel_id = (
        panel_pack.get("panel_id")
        or (panel_front or {}).get("source_panel_id")
        or (panel_front or {}).get("panel_id")
    )
    curves = sorted(_curves(front, panel_pack, panel_front), key=_curve_sort_key)
    durations = sorted(printed_durations(panel_pack))
    temperature_symbol, temperature_C, pulse_mode, condition_audit = _condition(panel_pack)
    dc_supported, dc_audit = _dc_support(panel_pack, set(durations), curves)

    curve_count = len(curves)
    duration_count = len(durations)
    if curve_count and duration_count:
        assigned_durations = (
            durations[-curve_count:]
            if curve_count < duration_count
            else durations[: min(curve_count, duration_count)]
        )
    else:
        assigned_durations = []

    # A supported extra DC is the final, lowest-current candidate.  For an
    # ambiguous extra, the extra stroke could occur anywhere in the inventory.
    # Do not invent an alignment; only that panel stays unresolved.
    pulsed_count = (
        0 if curve_count > duration_count and not dc_supported else min(curve_count, duration_count)
    )
    dc_index = curve_count - 1 if dc_supported else None
    if dc_supported:
        pulsed_count = min(curve_count - 1, duration_count)
        assigned_durations = durations[-pulsed_count:] if pulsed_count else []

    bindings: list[dict] = []
    for index, curve in enumerate(curves):
        kind = "unresolved"
        duration = None
        item_pulse_mode = None
        if dc_index == index:
            kind = "dc"
        elif index < pulsed_count:
            kind = "pulsed"
            duration = assigned_durations[index]
            item_pulse_mode = pulse_mode
        bindings.append(
            {
                "curve_id": curve["curve_id"],
                "curve_kind": kind,
                "duration_s": duration,
                "pulse_mode": item_pulse_mode,
                "temperature_symbol": temperature_symbol,
                "temperature_C": temperature_C,
            }
        )

    unresolved = sum(item["curve_kind"] == "unresolved" for item in bindings)
    audit = {
        "panel_id": panel_id,
        "document_id": panel_pack.get("geometry", {}).get("document_id")
        or front.get("document_id"),
        "printed_durations_s": durations,
        "curve_count": curve_count,
        "pulsed_count": sum(item["curve_kind"] == "pulsed" for item in bindings),
        "dc_count": sum(item["curve_kind"] == "dc" for item in bindings),
        "unresolved_count": unresolved,
        "assigned_duration_count": sum(item["duration_s"] is not None for item in bindings),
        "condition": condition_audit,
        "dc_evidence": dc_audit,
        "warnings": [],
    }
    if curve_count != duration_count and not dc_supported:
        audit["warnings"].append("candidate_inventory_exceeds_duration_inventory")
    if dc_supported:
        audit["classification"] = "one_extra_candidate_supported_as_dc"
    elif unresolved:
        audit["classification"] = "extra_candidate_left_unresolved"
    else:
        audit["classification"] = "all_candidates_pulsed"
    audit["accepted_relations"] = sum(item["curve_kind"] == "pulsed" for item in bindings)
    return bindings, audit


def extract(front: dict, pack: dict) -> tuple[list[dict], dict]:
    """Extract source-supported bindings from all local panels.

    Returns ``(bindings, audit)``.  ``bindings`` contains one record for each
    emitted candidate, including ``dc`` and ``unresolved`` records so callers
    can audit why a candidate was excluded from duration matching.  Only
    records with ``curve_kind == "pulsed"`` carry a duration.
    """

    front = front or {}
    pack = pack or {}
    panel_fronts = _panel_frontends(front)
    bindings: list[dict] = []
    panels: list[dict] = []
    for index, panel_pack in enumerate(_panel_packs(pack)):
        panel_id = panel_pack.get("panel_id")
        panel_front = panel_fronts.get(str(panel_id)) if panel_id is not None else None
        panel_bindings, panel_audit = _extract_panel(front, panel_pack, panel_front)
        bindings.extend(panel_bindings)
        panels.append(panel_audit)

    audit = {
        "version": "multipanel-rules-v2",
        "document_id": front.get("document_id") or pack.get("geometry", {}).get("document_id"),
        "panels": panels,
        "panel_count": len(panels),
        "accepted_relations": sum(panel["accepted_relations"] for panel in panels),
        "unresolved_relations": sum(panel["unresolved_count"] for panel in panels),
        "dc_relations": sum(panel["dc_count"] for panel in panels),
    }
    return bindings, audit


__all__ = ["extract"]
