"""Close uniquely supported plot-level conditions before checking relation evidence.

Only local text supplies repairs. Curve-duration associations remain predictions.
A successful check is textual support or retained visual claim, not human gold.
"""

import copy, re
from .evidence import compile_output, value_supported, raw_bindings


def compact(text):
    return re.sub(r"\s+", "", text.replace("_", "").replace("μ", "u").replace("µ", "u"))


def facts(pack):
    # One decoder for local native/OCR symbols, CID separators and D=0 pulses.
    from .consistency import facts as source_facts

    return source_facts(pack)


def project(data, pack, check_evidence=True):
    result = copy.deepcopy(data)
    local, temps, pulse = facts(pack)
    edits = []
    # A case/ambient/mounting-base plot condition outranks a junction ceiling.
    boundary = [x for x in temps if x[0] != "Tj"]
    for b in result.get("bindings", []):
        evidence = b.setdefault("evidence", {})
        if len(boundary) == 1:
            symbol, value = boundary[0]
            before = (
                b.get("temperature_symbol"),
                b.get("temperature_C"),
                b.get("temperature_role"),
            )
            b.update(
                temperature_symbol=symbol, temperature_C=value, temperature_role="initial_reference"
            )
            evidence["temperature"] = {"ids": temps[boundary[0]]}
            if before != (symbol, value, "initial_reference"):
                edits.append(
                    dict(
                        curve_id=b.get("curve_id"),
                        field="temperature",
                        before=before,
                        after=[symbol, value, "initial_reference"],
                        evidence_ids=temps[boundary[0]],
                    )
                )
        if pulse:
            if b.get("pulse_mode") != "single":
                edits.append(
                    dict(
                        curve_id=b.get("curve_id"),
                        field="pulse_mode",
                        before=b.get("pulse_mode"),
                        after="single",
                        evidence_ids=pulse,
                    )
                )
            b["pulse_mode"] = "single"
            evidence["pulse"] = {"ids": pulse}
        # Repair a missing literal citation, never an association or numeric value.
        value = b.get("duration_s")
        support = [x["id"] for x in local if value_supported("duration", value, x["text"])]
        if support:
            evidence["duration"] = {"ids": support}
    checked, audit = compile_output(result, pack)
    return (checked if check_evidence else raw_bindings(result)), dict(
        edits=edits,
        checks=audit,
        local_temperature_candidates=[
            dict(symbol=k[0], value=k[1], ids=v) for k, v in temps.items()
        ],
        local_single_pulse_evidence=pulse,
        limitation="Repairs use local native/OCR text; image claims and curve associations remain model-dependent.",
    )
