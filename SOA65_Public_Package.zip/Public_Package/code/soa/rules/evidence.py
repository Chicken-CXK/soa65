"""Executable evidence checks, not independent verification of image semantics."""

import math, re
from decimal import Decimal

FIELDS = ["curve_id", "duration_s", "pulse_mode", "temperature_symbol", "temperature_C"]


def durations(text):
    text = text.replace("μ", "u").replace("µ", "u")
    values = []
    for number, unit in re.findall(
        r"(?<![\d.])(\d(?:\s*\d)*(?:\.\s*\d(?:\s*\d)*)?)\s*(n\s*s|u\s*s|m\s*s|s)\b", text, re.I
    ):
        number = re.sub(r"\s+", "", number)
        unit = re.sub(r"\s+", "", unit).lower()
        values.append(
            float(
                Decimal(number)
                * Decimal({"ns": "1e-9", "us": "1e-6", "ms": "1e-3", "s": "1"}[unit])
            )
        )
    return values


def value_supported(field, value, text):
    if field == "duration":
        return isinstance(value, (int, float)) and any(
            math.isclose(value, x, rel_tol=1e-7, abs_tol=1e-12) for x in durations(text)
        )
    text = re.sub(r"\s+", "", text)
    if field == "temperature":
        values = [
            float(x)
            for x in re.findall(r"(-?\d+(?:\.\d+)?)\s*(?:°\s*C|deg(?:rees)?\s*C|C\b)", text, re.I)
        ]
        return value in values
    return bool(
        re.search(r"single\s*[- ]?pulse|(?:duty|D)\s*(?:cycle)?\s*[=:]\s*0(?:\D|$)", text, re.I)
    )


def compile_output(data, pack):
    blocks = {b["id"]: b for b in pack["blocks"]}
    ids = {c["curve_id"] for c in pack["geometry"]["curves"]}
    selected = pack["image_region"]
    accepted = []
    audit = []
    for b in data.get("bindings", []):
        reasons = []
        checks = []
        if b.get("curve_id") not in ids:
            reasons.append("unknown_curve_id")
        if b.get("temperature_role") != "initial_reference":
            reasons.append("temperature_role_not_reference")
        for field, value in [
            ("duration", b.get("duration_s")),
            ("temperature", b.get("temperature_C")),
            ("pulse", b.get("pulse_mode")),
        ]:
            proof = b.get("evidence", {}).get(field, {})
            cited = [blocks[x] for x in proof.get("ids", []) if x in blocks]
            unknown = set(proof.get("ids", [])) - set(blocks)
            if unknown:
                reasons.append(field + "_unknown_evidence_id")
            admissible = [
                x
                for x in cited
                if x["scope"] == "selected"
                or (field == "temperature" and x["scope"] == "preceding_context")
            ]
            text_ok = bool(admissible) and value_supported(
                field, value, " ".join(x["text"] for x in admissible)
            )
            visual = proof.get("visual", {}) or {}
            box = visual.get("bbox")
            quote = visual.get("quote", "")
            visual_ok = (
                isinstance(box, list)
                and len(box) == 4
                and all(isinstance(x, (int, float)) for x in box)
                and selected[0] <= box[0] < box[2] <= selected[2]
                and selected[1] <= box[1] < box[3] <= selected[3]
                and value_supported(field, value, quote)
            )
            if not (text_ok or visual_ok):
                reasons.append(field + "_no_local_support")
            checks.append(
                dict(
                    field=field,
                    text_supported=text_ok,
                    visual_claim_only=bool(visual_ok and not text_ok),
                )
            )
        audit.append(
            dict(
                curve_id=b.get("curve_id"),
                duration_s=b.get("duration_s"),
                reasons=reasons,
                checks=checks,
            )
        )
        if not reasons:
            accepted.append({k: b.get(k) for k in FIELDS})
    result = {k: data.get(k) for k in ["hard_current_cap_A", "scope_conflict_above_A", "notes"]}
    result["bindings"] = accepted
    result["run_status"] = "parse_error" if data.get("parse_error") else "parsed"
    if data.get("parse_error"):
        result["parse_error"] = data["parse_error"]
    return result, audit


def raw_bindings(data):
    result = {k: data.get(k) for k in ["hard_current_cap_A", "scope_conflict_above_A", "notes"]}
    result["bindings"] = [{k: b.get(k) for k in FIELDS} for b in data.get("bindings", [])]
    result["run_status"] = "parse_error" if data.get("parse_error") else "parsed"
    if data.get("parse_error"):
        result["parse_error"] = data["parse_error"]
    return result
