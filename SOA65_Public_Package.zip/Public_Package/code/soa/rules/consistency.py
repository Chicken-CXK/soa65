"""Minimal, read-only parser correction used by the fixed-65 audit.

This module mirrors ``rerun65-20260908/software/consistency.py`` while
changing only source-text decoding that is exercised by saved inputs:

* native PDF ``(cid:3)s`` / ``(cid:4)s`` microsecond glyphs;
* a numeric token split from its native microsecond unit, using existing OCR
  only to fill sub-millisecond durations;
* vertically adjacent temperature subscripts, the ``℃`` degree glyph, and
  the literal ``Sinlge pulse`` typo present in one manufacturer PDF.

It never reads reference labels and is not imported by the historical run.
"""

from __future__ import annotations

import copy
import json
import math
import re
from collections import Counter, defaultdict


POLICIES = {
    "baseline": (),
    "candidate": ("candidate",),
    "order": ("order",),
    "evidence": ("evidence",),
    "candidate_order": ("candidate", "order"),
    "combined": ("candidate", "order", "evidence"),
}


def duration_tokens(text: str) -> set[float]:
    """Decode the duration spellings that occur in the saved source packs."""
    text = text.replace("µ", "u").replace("μ", "u")
    text = re.sub(r"\(cid:(?:3|4)\)", "u", text, flags=re.I)
    scale = {"ns": 1e-9, "us": 1e-6, "ms": 1e-3, "s": 1}
    return {
        round(float(re.sub(r"\s+", "", number)) * scale[re.sub(r"\s+", "", unit).lower()], 12)
        for number, unit in re.findall(
            r"(?<![\d.])(\d(?:\s*\d)*(?:\.\s*\d(?:\s*\d)*)?)\s*(n\s*s|u\s*s|m\s*s|s)\b",
            text,
            re.I,
        )
    }


def printed_durations(pack: dict) -> set[float]:
    """Keep native precedence, but fill native CID micro-glyph holes from OCR."""
    local = [b for b in pack.get("blocks", []) if b.get("scope") == "selected"]
    native = {
        value
        for block in local
        if block.get("origin") == "native"
        for value in duration_tokens(block.get("text", ""))
    }
    ocr = {
        value
        for block in local
        if block.get("origin") == "ocr"
        for value in duration_tokens(block.get("text", ""))
    }
    unresolved_micro = any(
        block.get("origin") == "native"
        and re.search(r"\(cid:(?:3|4)\)\s*s", block.get("text", ""), re.I)
        for block in local
    )
    if unresolved_micro:
        # The saved OCR occasionally reads ``1 ms`` as ``11 ms``.  CID 3/4 is
        # the missing micro glyph, so only use OCR to fill sub-ms values.
        native |= {value for value in ocr if value < 1e-3}
    return native if len(native) >= 2 else native | ocr


def temp_type(value):
    return {
        "tc": "TC",
        "ta": "TA",
        "tj": "Tj",
        "tmb": "Tmb",
    }.get(str(value).replace("_", "").replace(" ", "").casefold(), value)


def _compact(text: str) -> str:
    # The bundled rule reader already handles these exact italic-Tmb OCR forms
    # from the fixed Nexperia PDFs. Apply the same source-glyph normalization.
    text = re.sub(r"\b(?:Imo|Tmo|Tmb)\s*=", "Tmb=", text, flags=re.I)
    return re.sub(
        r"\s+",
        "",
        text.replace("\x02", "")
        .replace("_", "")
        .replace("μ", "u")
        .replace("µ", "u")
        .replace("℃", "°C")
        .replace("Sinlge", "Single")
        .replace("sinlge", "single"),
    )


def _subscript(text: str):
    normalized = re.sub(r"[^a-z]", "", _compact(text).casefold())
    if normalized.startswith("jmax"):
        return "j(max)"
    return normalized if normalized in {"a", "c", "j", "mb"} else None


def _vertical_overlap(a: dict, b: dict) -> float:
    return max(0.0, min(a["bbox"][3], b["bbox"][3]) - max(a["bbox"][1], b["bbox"][1]))


def facts(pack: dict):
    """Extract local temperature and single-pulse facts from saved blocks."""
    local = [b for b in pack.get("blocks", []) if b.get("scope") == "selected"]
    temperatures: dict[tuple[str, float], list[str]] = {}
    pulse: list[str] = []
    for block in local:
        text = _compact(block.get("text", ""))
        if block.get("origin") == "ocr":
            # Existing rule normalization, confirmed on the selected source caption.
            text = re.sub(r"\b(?:Imo|Tmo)(?==-?\d+(?:\.\d+)?°?C)", "Tmb", text)
        evidence_ids = [block["id"]]
        t_count = len(re.findall(r"T(?=[=:])", text))
        if t_count:
            original_nearby = [
                other
                for other in local
                if other.get("origin") == block.get("origin")
                and _subscript(other.get("text", ""))
                and abs(other["bbox"][1] - block["bbox"][1]) < 8
                and 0 <= other["bbox"][0] - block["bbox"][0] < 16
            ]
            chosen = []
            if t_count == 1 and len(original_nearby) == 1:
                chosen = original_nearby
            else:
                overlapping = [
                    other
                    for other in local
                    if other.get("origin") == block.get("origin")
                    and _subscript(other.get("text", ""))
                    and _vertical_overlap(block, other) > 0
                    and block["bbox"][0] <= other["bbox"][0] <= block["bbox"][2]
                ]
                overlapping.sort(key=lambda other: other["bbox"][0])
                if len(overlapping) == t_count:
                    chosen = overlapping
                elif t_count == 1 and overlapping:
                    ranked = sorted(
                        overlapping, key=lambda other: _vertical_overlap(block, other), reverse=True
                    )
                    if len(ranked) == 1 or _vertical_overlap(block, ranked[0]) > _vertical_overlap(
                        block, ranked[1]
                    ):
                        chosen = [ranked[0]]
            if len(chosen) == t_count:
                symbols = iter(_subscript(other.get("text", "")) for other in chosen)
                text = re.sub(r"T(?=[=:])", lambda _: "T" + next(symbols), text)
                evidence_ids.extend(other["id"] for other in chosen)
        if re.search(r"T(?:mb|c|a|j)[=:]-?\d+(?:\.\d+)?$", text, re.I):
            nearby_degree = [
                other
                for other in local
                if other.get("origin") == block.get("origin")
                and _compact(other.get("text", "")).lower() in {"°c", "oc"}
                and abs(other["bbox"][1] - block["bbox"][1]) < 8
                and -2 <= other["bbox"][0] - block["bbox"][2] < 20
            ]
            if nearby_degree:
                text += "°C"
                evidence_ids.append(nearby_degree[0]["id"])
        for symbol, value in re.findall(
            r"T(mb|c|a|j)\s*[=:]\s*(-?\d+(?:\.\d+)?)\s*(?:°?C)", text, re.I
        ):
            key = ({"mb": "Tmb", "c": "TC", "a": "TA", "j": "Tj"}[symbol.lower()], float(value))
            temperatures.setdefault(key, []).extend(evidence_ids)
        if "singlepulse" in text.lower() or re.search(
            r"(?:dutycycle|D)[=:]0(?:\.0+)?(?![\d.])", text, re.I
        ):
            pulse.append(block["id"])
    for first, second in zip(local, local[1:]):
        joined = _compact(first.get("text", "") + " " + second.get("text", "")).lower()
        if (
            "singlepulse" in joined
            and 0 <= second["bbox"][1] - first["bbox"][3] < 15
            and abs(first["bbox"][0] - second["bbox"][0]) < 25
        ):
            pulse.extend([first["id"], second["id"]])
    for note in pack.get("blocks", []):
        if (
            note.get("scope") == "referenced_note"
            and "singlepulse" in _compact(note.get("text", "")).lower()
        ):
            pulse.append(note["id"])
    return local, temperatures, list(dict.fromkeys(pulse))


def _check_single(
    front: dict, binding: dict, structured: dict, pack: dict, policy: str = "combined"
):
    """Run the original policy with only the saved-text parser corrections."""
    checks = POLICIES[policy]
    result = copy.deepcopy(binding)
    curves = {c["curve_id"]: c for c in front.get("curves", [])}
    blocks = pack.get("blocks", [])
    local = [b for b in blocks if b.get("scope") == "selected"]
    printed = printed_durations(pack)

    # Curves from separate voltage probes share a legend but do not share an
    # ordering relation: current is only comparable at one probe voltage.
    def group_for(item):
        curve = curves.get(item.get("curve_id"), {})
        return (
            curve.get("voltage_V", item.get("voltage_V")),
            temp_type(item.get("temperature_symbol")),
            item.get("temperature_C"),
            item.get("pulse_mode"),
        )

    groups = defaultdict(list)
    for item in binding.get("bindings", []):
        groups[group_for(item)].append(item)
    rejected = set()
    reasons = []

    def reject(group, reason):
        rejected.add(group)
        reasons.append({"group": list(group), "reason": reason})

    if "candidate" in checks:
        assignments = structured.get("bindings", [])
        classified = {item.get("curve_id") for item in assignments}
        unknown = classified - set(curves)
        missing = set(curves) - classified
        pulsed = {item.get("curve_id") for item in binding.get("bindings", [])}
        unresolved = {
            item.get("curve_id") for item in assignments if item.get("curve_kind") == "unresolved"
        }
        unmatched = [
            cid
            for cid in unresolved
            if cid in curves
            and not any(
                curves[cid]["current_low_A"] <= curves[p]["current_high_A"]
                and curves[p]["current_low_A"] <= curves[cid]["current_high_A"]
                for p in pulsed
                if p in curves
            )
        ]
        if unknown or missing or unmatched:
            for group in groups:
                reject(group, "unaccounted_candidate")
        for group, items in groups.items():
            durations = [
                round(item["duration_s"], 12)
                for item in items
                if isinstance(item.get("duration_s"), (int, float))
            ]
            if (
                printed
                and durations
                and (
                    set(durations) - printed
                    or any(value >= min(durations) and value not in durations for value in printed)
                )
            ):
                reject(group, "pulse_inventory_conflict")
    if "order" in checks:
        for group, items in groups.items():
            typed = [
                item
                for item in items
                if item.get("curve_id") in curves
                and isinstance(item.get("duration_s"), (int, float))
            ]
            if any(
                first["duration_s"] < second["duration_s"]
                and curves[first["curve_id"]]["current_high_A"]
                < curves[second["curve_id"]]["current_low_A"]
                for first in typed
                for second in typed
            ):
                reject(group, "pulse_current_order_conflict")
    if "evidence" in checks:
        _, temperatures, pulse = facts(pack)
        evidence_text = _compact(" ".join(block.get("text", "") for block in local))
        pulse_ok = bool(pulse) or bool(
            re.search(r"(?:duty|D)\s*(?:cycle)?\s*[=:]\s*0(?:\.0+)?(?![\d.])", evidence_text, re.I)
        )
        defaults = [
            block
            for block in blocks
            if block.get("scope") == "preceding_context"
            and re.search(r"unless|otherwise", block.get("text", ""), re.I)
        ]
        if defaults:
            latest = max(defaults, key=lambda block: (block["page"], block["bbox"][1]))
            text = _compact(latest.get("text", ""))
            for symbol, value in re.findall(r"T(mb|c|a|j)[=:](-?\d+(?:\.\d+)?)(?:°?C)", text, re.I):
                temperatures.setdefault((temp_type("T" + symbol), float(value)), []).append(
                    latest["id"]
                )
        for group, items in groups.items():
            if (group[1], group[2]) not in temperatures:
                reject(group, "temperature_without_source_text")
            if group[3] != "single" or not pulse_ok:
                reject(group, "pulse_mode_without_source_text")
            if any(
                not isinstance(item.get("duration_s"), (int, float))
                or not any(
                    math.isclose(item["duration_s"], value, rel_tol=1e-8) for value in printed
                )
                for item in items
            ):
                reject(group, "duration_without_source_text")
    result["bindings"] = [
        item for item in result.get("bindings", []) if group_for(item) not in rejected
    ]
    return result, {
        "policy": policy,
        "printed_durations_s": sorted(printed),
        "rejected_groups": [list(group) for group in rejected],
        "reasons": reasons,
        "accepted_relations": len(result["bindings"]),
    }


def _panel_frontends(front: dict) -> dict:
    entries = front.get("panel_frontends", [])
    if isinstance(entries, dict):
        entries = [
            value | {"panel_id": key}
            if isinstance(value, dict) and "panel_id" not in value
            else value
            for key, value in entries.items()
        ]
    result = {}
    for entry in entries:
        if isinstance(entry, dict):
            panel_id = entry.get("panel_id", entry.get("source_panel_id"))
            if panel_id is not None:
                result[panel_id] = entry
    return result


def _panel_curve_ids(panel_pack: dict, front: dict, panel_front: dict | None) -> set:
    """Resolve global curve IDs for exactly one source panel."""
    ids = {
        curve.get("curve_id")
        for curve in (panel_front or {}).get("curves", [])
        if curve.get("curve_id") is not None
    }
    ids |= {
        curve.get("curve_id")
        for curve in panel_pack.get("geometry", {}).get("curves", [])
        if curve.get("curve_id") is not None
    }
    if ids:
        return ids
    panel_id = panel_pack.get("panel_id")
    geometry = panel_pack.get("geometry", {})
    page = geometry.get("page")
    bbox = geometry.get("plot_bbox")
    return {
        curve.get("curve_id")
        for curve in front.get("curves", [])
        if curve.get("curve_id") is not None
        and (
            panel_id is not None
            and curve.get("source_panel_id") == panel_id
            or panel_id is None
            and curve.get("source_page", front.get("page")) == page
            and curve.get("source_panel_bbox") == bbox
        )
    }


def _local_front(front: dict, panel_front: dict | None, curve_ids: set) -> dict:
    """Use the panel frontend when supplied, while retaining global IDs."""
    local = copy.deepcopy(panel_front or front)
    global_curves = {curve.get("curve_id"): curve for curve in front.get("curves", [])}
    local["curves"] = [
        copy.deepcopy(global_curves[curve_id])
        for curve_id in curve_ids
        if curve_id in global_curves
    ]
    return local


def check(front: dict, binding: dict, structured: dict, pack: dict, policy: str = "combined"):
    """Apply consistency policy independently to each source panel.

    Historical frontends have one ``source_pack`` and retain the original
    single-panel behaviour. Multi-panel frontends carry local packs and global
    curve IDs; a failed check in one pack must only remove that pack's bindings.
    """
    panel_packs = pack.get("panel_packs")
    if not panel_packs:
        return _check_single(front, binding, structured, pack, policy)

    global_ids = {c["curve_id"] for c in front.get("curves", [])}
    unknown = {b.get("curve_id") for b in structured.get("bindings", [])} - global_ids
    if unknown and "candidate" in POLICIES[policy]:
        result = copy.deepcopy(binding)
        result["bindings"] = []
        return result, {
            "policy": policy,
            "accepted_relations": 0,
            "panels": [],
            "reasons": [{"reason": "unaccounted_candidate", "unknown_curve_ids": sorted(unknown)}],
        }
    panels = _panel_frontends(front)
    original = binding.get("bindings", [])
    audits = []
    accepted = {}
    for index, panel_pack in enumerate(panel_packs):
        panel_id = panel_pack.get("panel_id", index)
        panel_front = panels.get(panel_id)
        curve_ids = _panel_curve_ids(panel_pack, front, panel_front)
        local_binding = {
            **copy.deepcopy(binding),
            "bindings": [item for item in original if item.get("curve_id") in curve_ids],
        }
        local_structured = {
            **copy.deepcopy(structured),
            "bindings": [
                item for item in structured.get("bindings", []) if item.get("curve_id") in curve_ids
            ],
        }
        corrected, audit = _check_single(
            _local_front(front, panel_front, curve_ids),
            local_binding,
            local_structured,
            panel_pack,
            policy,
        )
        accepted[panel_id] = Counter(
            json.dumps(item, sort_keys=True, separators=(",", ":"))
            for item in corrected.get("bindings", [])
        )
        audit = copy.deepcopy(audit)
        audit["panel_id"] = panel_id
        audits.append(audit)

    # Each global Cxx belongs to one panel. Bindings with an absent/unknown Cxx
    # are left untouched here; the parser stage reports those independently.
    result = copy.deepcopy(binding)
    by_curve = {}
    for index, panel_pack in enumerate(panel_packs):
        panel_id = panel_pack.get("panel_id", index)
        panel_front = panels.get(panel_id)
        for curve_id in _panel_curve_ids(panel_pack, front, panel_front):
            by_curve[curve_id] = panel_id
    kept = []
    for item in original:
        panel_id = by_curve.get(item.get("curve_id"))
        if panel_id is None:
            kept.append(copy.deepcopy(item))
            continue
        signature = json.dumps(item, sort_keys=True, separators=(",", ":"))
        if accepted[panel_id][signature]:
            accepted[panel_id][signature] -= 1
            kept.append(copy.deepcopy(item))
    result["bindings"] = kept
    return result, {
        "policy": policy,
        "panels": audits,
        "printed_durations_s": sorted(
            {value for audit in audits for value in audit["printed_durations_s"]}
        ),
        "rejected_groups": [group for audit in audits for group in audit["rejected_groups"]],
        "reasons": [
            reason | {"panel_id": audit["panel_id"]}
            for audit in audits
            for reason in audit["reasons"]
        ],
        "accepted_relations": len(result["bindings"]),
    }
