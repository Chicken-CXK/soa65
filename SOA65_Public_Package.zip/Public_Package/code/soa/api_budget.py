"""One persisted spending ledger for the qualification and final API runs."""

import fcntl
from pathlib import Path
from .storage import load, save


class Budget:
    def __init__(self, path, cap):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = self.path.with_suffix(".lock").open("a")
        try:
            fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.state = load(self.path) if self.path.exists() else {"cap_cny": cap, "calls": {}}
            if self.state["cap_cny"] != cap:
                raise ValueError("Existing ledger has a different authorized cap")
            self.persist()
        except Exception:
            self.close()
            raise

    def close(self):
        self.lock.close()

    @property
    def charged(self):
        return sum(r["charged_or_reserved_cny"] for r in self.state["calls"].values())

    def persist(self):
        self.state["charged_or_reserved_cny"] = self.charged
        self.state["remaining_cny"] = self.state["cap_cny"] - self.charged
        temporary = self.path.with_suffix(".tmp")
        save(temporary, self.state)
        temporary.replace(self.path)

    def reserve(self, call_id, amount, output):
        if call_id in self.state["calls"]:
            raise ValueError("This logical call already has a budget record; do not retry")
        if self.charged + amount > self.state["cap_cny"]:
            return False
        self.state["calls"][call_id] = {
            "reserved_cny": amount,
            "charged_or_reserved_cny": amount,
            "status": "reserved",
            "output": str(output),
        }
        self.persist()
        return True

    def settle(self, call_id, execution):
        row = self.state["calls"][call_id]
        amount = execution.get("cost_estimate_cny")
        row.update(
            status="estimated" if amount is not None else "reserved_unknown_usage",
            charged_or_reserved_cny=amount if amount is not None else row["reserved_cny"],
            cost_estimate_cny=amount,
            user_price_estimate_cny=execution.get("user_price_estimate_cny"),
            http_status=execution.get("http_status"),
        )
        self.persist()

    def reconcile_completed(self):
        for call_id, row in self.state["calls"].items():
            path = Path(row["output"]) / "execution.json"
            if row["status"] == "reserved" and path.exists():
                self.settle(call_id, load(path))
