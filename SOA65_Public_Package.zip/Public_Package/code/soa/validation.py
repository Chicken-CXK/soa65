"""Offline reader-package replay from saved answers and annotation snapshots."""

import csv
import gzip
import json
import shutil
import tempfile
from pathlib import Path
from itertools import zip_longest

from .storage import load, save
from .scoring import score_run
from .contracts import parse_binding
from .reporting import export_run


def audit_groups_in_stable_order(value):
    """The archived rejected_groups field is emitted from a set."""
    if isinstance(value, list):
        return [audit_groups_in_stable_order(item) for item in value]
    if isinstance(value, dict):
        return {
            key: sorted(item, key=lambda row: json.dumps(row, sort_keys=True))
            if key == "rejected_groups"
            else audit_groups_in_stable_order(item)
            for key, item in value.items()
        }
    return value


def compare_csv(expected, actual):
    opener = gzip.open if expected.suffix == ".gz" else open
    with opener(expected, "rt", encoding="utf-8-sig", newline="") as left:
        with actual.open(encoding="utf-8-sig", newline="") as right:
            lhs, rhs = csv.DictReader(left), csv.DictReader(right)
            if lhs.fieldnames != rhs.fieldnames:
                return "columns differ"
            for index, (a, b) in enumerate(zip_longest(lhs, rhs), 2):
                if a is None or b is None:
                    return f"row count differs at row {index}"
                if "audit" in a:
                    for row in (a, b):
                        row["audit"] = audit_groups_in_stable_order(json.loads(row["audit"]))
                if a != b:
                    return f"row {index} differs"
    return None


def verify_release(project):
    source = project.default_run
    tasks = load(source / "manifest.json")
    workspace = project.root / "runs"
    workspace.mkdir(exist_ok=True)
    target = Path(tempfile.mkdtemp(prefix="reproduce_", dir=workspace))
    for name in ("manifest.json", "run.json"):
        shutil.copy2(source / name, target / name)
    shutil.copytree(source / "outputs", target / "outputs")
    report = {
        "passed": False,
        "selected_answers": len(tasks),
        "documents": len({task["doc_id"] for task in tasks}),
        "new_model_calls": 0,
        "parsed_answers_equal": 0,
        "csv_files_equal": 0,
        "differences": [],
        "reproduced_run": str(target.relative_to(project.root)),
        "comparison": "CSV fields and rows; only audit.rejected_groups order is ignored",
    }
    report_file = project.root / "validation/release_reproduction.json"
    for task in tasks:
        folder = target / "outputs" / f"{task['sequence']:04}"
        packet = load(project.resolve(task["input_file"]))
        parsed = parse_binding((folder / "last_message.txt").read_text(), packet["candidate_ids"])
        if parsed != load(folder / "result.json")["single_attempt"]:
            report["differences"].append(f"answer parsing: {task['sequence']}")
        else:
            report["parsed_answers_equal"] += 1
    if report["differences"]:
        save(report_file, report)
        raise AssertionError("Answer parsing differs; see " + str(report_file))
    report["scoring"] = score_run(project, target)
    export_run(project, target, plots=False)
    for prefix in ("", "controlled_primary31"):
        for expected in sorted((source / "paper" / prefix).iterdir()):
            if not (expected.name.endswith(".csv") or expected.name.endswith(".csv.gz")):
                continue
            actual = target / "paper" / prefix / expected.name.removesuffix(".gz")
            difference = compare_csv(expected, actual)
            if difference:
                report["differences"].append(f"{prefix}/{expected.name}: {difference}")
            else:
                report["csv_files_equal"] += 1
    report["passed"] = not report["differences"]
    save(report_file, report)
    if not report["passed"]:
        raise AssertionError("Frozen result comparison differs; see " + str(report_file))
    return report
