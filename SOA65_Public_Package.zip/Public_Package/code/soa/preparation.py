"""Prepare a named run from the explicit plan, optionally rebuilding source-only frontends."""

from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import copy
from .storage import load, save
from .vision.frontend import build_all
from .vision.prompt import automatic_prompt
from .rules.baseline import extract
from .scoring import scoped_projection


def rebuild_analysis(project, analysis_path, run):
    analysis = load(project.resolve(analysis_path))
    source = analysis["source"]
    key = Path(analysis_path).stem
    output = run / "assets" / key
    frontend_dir = output / "frontend"
    pdf = project.dataset / "sources/pdf" / source["pdf_name"]
    front = build_all(
        pdf,
        source["target_part"],
        source["voltage_V"],
        frontend_dir,
        ocr_command=project.ocr_command,
    )
    pack = load(frontend_dir / "source_pack.json")
    prompt, images = automatic_prompt(front, pack, source, analysis["analysis_id"])
    (output / "prompt.txt").write_text(prompt)
    for image in images:
        image["path"] = project.relative(image["path"])
    input_path = output / "input.json"
    save(
        input_path,
        {
            "dataset": "M01-SOA-65-20260908",
            "analysis_id": analysis["analysis_id"],
            "doc_id": analysis["analysis_id"],
            "mode": "vision",
            "prompt_file": project.relative(output / "prompt.txt"),
            "images": images,
            "candidate_ids": [curve["curve_id"] for curve in front.get("curves", [])],
            "reference_supplied": False,
            "voltage_V": source["voltage_V"],
            "frontend_status": front["status"],
        },
    )
    bindings, rule_audit = extract(front, pack)
    structured = {
        "bindings": bindings,
        "hard_current_cap_A": None,
        "scope_conflict_above_A": None,
        "method": "multi-panel-rules-v2",
    }
    pulsed = structured | {
        "bindings": [item for item in bindings if item["curve_kind"] == "pulsed"]
    }
    corrected, projection = scoped_projection(pulsed, pack, front)
    analysis["frontend"], analysis["source_pack"] = front, pack
    analysis["rules"] = {
        "status": {"status": "bindings_emitted" if corrected["bindings"] else "no_output"},
        "binding": corrected,
        "structured": structured,
    }
    analysis_output = output / "analysis.json"
    save(analysis_output, analysis)
    save(output / "rules_audit.json", rule_audit)
    save(output / "rules_projection.json", projection)
    return {
        "analysis_file": project.relative(analysis_output),
        "input_file": project.relative(input_path),
    }


def prepare_run(project, run, rebuild=False, workers=4, documents=None):
    """A new manifest never borrows old model outputs; shared source inputs may be reused."""
    run = Path(run)
    if (run / "manifest.json").exists():
        raise FileExistsError("Run manifest exists; use a new run name or execute the existing run")
    tasks = copy.deepcopy(load(project.root / "config/plan.json"))
    if documents:
        tasks = [task for task in tasks if task["doc_id"] in documents]
    if not tasks:
        raise ValueError("No tasks selected")
    run.mkdir(parents=True, exist_ok=True)
    assets = {}
    if rebuild:
        analyses = {task["analysis_file"] for task in tasks if task["arm"] == "automatic"}
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(rebuild_analysis, project, path, run): path for path in analyses}
            for future in as_completed(futures):
                assets[futures[future]] = future.result()
    for sequence, task in enumerate(tasks, 1):
        model = project.models[task["profile"]]
        task["requested_model"] = model["model"]
        task["reasoning_effort"] = model["reasoning_effort"]
        if project.api:
            task["model_settings"] = copy.deepcopy(model)
        task["source_sequence"] = task["sequence"]
        task["sequence"] = sequence
        task["call_id"] = run.name + "/" + task["call_id"]
        if task["analysis_file"] in assets:
            task.update(assets[task["analysis_file"]])
    save(run / "manifest.json", tasks)
    save(
        run / "run.json",
        {
            "kind": "new_experiment",
            "planned_tasks": len(tasks),
            "source_frontends_rebuilt": len(assets),
            "model_outputs_reused": False,
            "models": project.models,
            "model_pair": list(project.model_pair),
            "api": project.api,
        },
    )
    return {"planned_tasks": len(tasks), "source_frontends_rebuilt": len(assets)}
