"""Deterministic document-supported SOA decisions on shared calibrated slices."""

import math


def temperature_symbol(value):
    if value is None:
        return None
    return {"tc": "TC", "ta": "TA", "tj": "Tj", "tmb": "Tmb"}.get(
        str(value).replace("_", "").replace(" ", "").casefold(), value
    )


def verify(case, geometry, binding, ignore_conditions=False, ignore_temperature=False):
    def result(label, reason, curve=None, margin=None):
        return {"label": label, "reason": reason, "curve_id": curve, "margin_interval": margin}

    if not ignore_conditions and case["initial_state"] != "equilibrium":
        return result("INSUFFICIENT", "initial_state_unknown")
    if not ignore_conditions and case["pulse_mode"] != "single":
        return result("INSUFFICIENT", "repeated_thermal_evaluation_not_implemented")
    by_id = {c["curve_id"]: c for c in geometry["curves"]}
    applicable = []
    for b in binding.get("bindings", []):
        curve = by_id.get(b.get("curve_id"))
        if curve is None:
            continue
        if not ignore_conditions:
            if b.get("pulse_mode") != "single":
                continue
            if not isinstance(b.get("duration_s"), (int, float)) or not math.isclose(
                b["duration_s"], case["duration_s"], rel_tol=1e-8
            ):
                continue
            if not ignore_temperature and temperature_symbol(
                b.get("temperature_symbol")
            ) != temperature_symbol(case["temperature_symbol"]):
                continue
            if not ignore_temperature and b.get("temperature_C") != case["temperature_C"]:
                continue
        if not math.isclose(curve["voltage_V"], case["voltage_V"], rel_tol=1e-8):
            continue
        applicable.append(curve)
    if not applicable:
        return result("INSUFFICIENT", "no_applicable_document_curve")
    # Duplicated incompatible semantic bindings are not resolved by silently
    # picking the most permissive curve. The ablation intentionally does so.
    if len(applicable) > 1 and not ignore_conditions and not ignore_temperature:
        return result("INSUFFICIENT", "ambiguous_curve_binding")
    c = max(applicable, key=lambda x: x["current_A"])
    lo, hi = c["current_low_A"], c["current_high_A"]
    current = case["current_A"]
    cap = binding.get("hard_current_cap_A") if not ignore_conditions else None
    if cap is not None:
        lo, hi = min(lo, cap), min(hi, cap)
    if current > hi:
        return result(
            "SCREEN_FAIL",
            "above_document_curve",
            c["curve_id"],
            [lo / current - 1, hi / current - 1],
        )
    if current >= lo:
        return result("INSUFFICIENT", "boundary_ambiguous", c["curve_id"])
    if not ignore_conditions:
        conflict = binding.get("scope_conflict_above_A")
        if conflict is not None and current > conflict:
            return result("INSUFFICIENT", "source_scope_conflict", c["curve_id"])

    return result(
        "SUPPORTED", "within_document_curve", c["curve_id"], [lo / current - 1, hi / current - 1]
    )
