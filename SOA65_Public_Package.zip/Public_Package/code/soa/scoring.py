"""Score every planned task against explicit frozen analysis inputs."""

from pathlib import Path
from collections import defaultdict
import math, copy
from .storage import load, save
from .verifier import verify, temperature_symbol
from .statistics import metric_counts, aggregate, paired_results
from .rules.consistency import check, POLICIES
from .rules.projection import project


def iou(a, b):
    intersection = max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(
        0, min(a[3], b[3]) - max(a[1], b[1])
    )
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - intersection
    return intersection / union if union else 0


def same_condition(a, b):
    x, y = a.get("duration_s"), b.get("duration_s")
    return (
        isinstance(x, (int, float))
        and isinstance(y, (int, float))
        and math.isclose(x, y, rel_tol=1e-8)
        and a.get("pulse_mode") == b.get("pulse_mode")
        and temperature_symbol(a.get("temperature_symbol"))
        == temperature_symbol(b.get("temperature_symbol"))
        and a.get("temperature_C") == b.get("temperature_C")
    )


def relation_count(geo, refgeo, binding, reference, automatic, ready=True):
    if not ready:
        return 0, len(reference["bindings"])
    found = 0
    byid = {c["curve_id"]: c for c in geo["curves"]}
    truth = {c["curve_id"]: c for c in refgeo["curves"]}
    for b in reference["bindings"]:
        matches = [
            x
            for x in binding["bindings"]
            if same_condition(x, b)
            and x.get("curve_id") in byid
            and (automatic or x["curve_id"] == b["curve_id"])
        ]
        if len(matches) != 1:
            continue
        if automatic:
            c = truth[b["curve_id"]]
            candidate = byid[matches[0]["curve_id"]]
            ov = (
                iou(
                    candidate.get("source_panel_bbox", geo.get("plot_bbox", [0, 0, 0, 0])),
                    c.get("source_panel_bbox", refgeo["plot_bbox"]),
                )
                if candidate.get("source_page", geo.get("page"))
                == c.get("source_page", refgeo["page"])
                else 0
            )
            if ov < 0.5 or not c["current_low_A"] <= candidate["current_A"] <= c["current_high_A"]:
                continue
        found += 1
    return found, len(reference["bindings"])


def _panel_curve_ids(panel_pack, front):
    # A local caption may only rewrite bindings whose neutral geometry belongs to that panel.
    target = panel_pack.get("geometry", {})
    byid = {c["curve_id"]: c for c in front.get("curves", [])}
    eligible = {c.get("curve_id") for c in target.get("curves", []) if c.get("curve_id")}
    if eligible:
        return eligible
    panel_id = panel_pack.get("panel_id")
    for cid, c in byid.items():
        if panel_id is not None and c.get("source_panel_id") == panel_id:
            eligible.add(cid)
            continue
        pn = c.get("source_page", front.get("page"))
        bbox = c.get("source_panel_bbox", front.get("plot_bbox"))
        if (
            panel_id is None
            and pn == target.get("page")
            and bbox
            and target.get("plot_bbox")
            and iou(bbox, target["plot_bbox"]) >= 0.5
        ):
            eligible.add(cid)
    return eligible


def _project_panel(binding, panel_pack, front):
    eligible = _panel_curve_ids(panel_pack, front)
    selected = copy.deepcopy(binding)
    selected["bindings"] = [b for b in binding.get("bindings", []) if b.get("curve_id") in eligible]
    projected, audit = project(selected, panel_pack, check_evidence=False)
    # Keep original order; project() preserves each selected relation's order.
    it = iter(projected["bindings"])
    projected["bindings"] = [
        next(it) if b.get("curve_id") in eligible else copy.deepcopy(b)
        for b in binding.get("bindings", [])
    ]
    audit["unprojected_outside_source_panel"] = [
        b.get("curve_id") for b in binding.get("bindings", []) if b.get("curve_id") not in eligible
    ]
    return projected, audit


def scoped_projection(binding, pack, front):
    panel_packs = pack.get("panel_packs")
    if not panel_packs:
        return _project_panel(binding, pack, front)
    # Each local pack carries global Cxx IDs. Project conditions separately and
    # splice only that panel's relations back into the document-order response.
    by_curve = {}
    replacements = {}
    audits = []
    for index, panel_pack in enumerate(panel_packs):
        panel_id = panel_pack.get("panel_id", index)
        eligible = _panel_curve_ids(panel_pack, front)
        for cid in eligible:
            by_curve[cid] = panel_id
        local, audit = _project_panel(binding, panel_pack, front)
        replacements[panel_id] = iter(
            [b for b in local["bindings"] if b.get("curve_id") in eligible]
        )
        audit["panel_id"] = panel_id
        audits.append(audit)
    result = copy.deepcopy(binding)
    merged = []
    for item in binding.get("bindings", []):
        panel_id = by_curve.get(item.get("curve_id"))
        merged.append(next(replacements[panel_id]) if panel_id is not None else copy.deepcopy(item))
    result["bindings"] = merged
    return result, {
        "panels": audits,
        "unprojected_outside_source_panel": [
            b.get("curve_id")
            for b in binding.get("bindings", [])
            if b.get("curve_id") not in by_curve
        ],
    }


def _usable_bindings(binding, front):
    known = {c.get("curve_id") for c in front.get("curves", []) if c.get("curve_id")}
    return bool(
        known and any(item.get("curve_id") in known for item in binding.get("bindings", []))
    )


def score_analysis(
    cases, truth, reference, front, binding, structured, pack, ready, meta, automatic
):
    decisions = []
    records = []
    audits = []
    ready = bool(ready and binding.get("bindings"))
    for policy in POLICIES:
        current, audit = (
            check(front, binding, structured, pack, policy)
            if ready
            else (binding, {"reasons": [], "not_executed": "no usable extraction"})
        )
        audit["evaluated"] = bool(ready)
        ds = []
        for case in cases:
            gold = verify(case, truth, reference)["label"]
            pred = (
                verify(case, front, current)
                if ready
                else {"label": "NO_OUTPUT", "reason": meta.get("failed_stage", "no_usable_binding")}
            )
            ds.append(
                meta
                | {
                    "policy": policy,
                    "evaluation_set": case.get("evaluation_set", "primary"),
                    "case_split": case.get("split"),
                    "case_id": case["id"],
                    "gold": gold,
                    "prediction": pred["label"],
                    "reason": pred["reason"],
                }
            )
        matched, total = relation_count(front, truth, current, reference, automatic, ready)
        records.append(
            meta
            | {
                "policy": policy,
                "binding_fraction": [matched, total],
                "binding_agreement": matched / total if total else None,
                **metric_counts(ds),
            }
        )
        decisions.extend(ds)
        audits.append(meta | {"policy": policy, "audit": audit})
    return decisions, records, audits


def _base_metadata(task, analysis, ready, parsed, result):
    automatic = task["arm"] == "automatic"
    failed = (
        None
        if ready
        else result.get(
            "failed_stage",
            parsed["status"] if parsed["status"] != "parsed" else "no_usable_bindings",
        )
    )
    return {
        "arm": task["arm"],
        "cohort": task.get("cohort", task["arm"]),
        "analysis_id": task["analysis_id"],
        "doc_id": task.get("doc_id", task["analysis_id"]),
        "profile": task["profile"],
        "mode": task["mode"],
        "repeat_id": task["repeat_id"],
        "call_id": task["call_id"],
        **analysis["metadata"],
        "failed_stage": failed,
        "pipeline": "model + local-condition projection"
        if automatic
        else "model controlled binding",
    }


def evaluate_model(task, analysis, result, output):
    """Score one raw result; projection and the raw ablation retain separate readiness."""
    automatic = task["arm"] == "automatic"
    front, pack = analysis["frontend"], analysis["source_pack"]
    truth, reference, cases = (
        analysis["reference_geometry"],
        analysis["reference_binding"],
        analysis["cases"],
    )
    parsed = result["single_attempt"]
    # Invalid payloads stay in result.json, but cannot enter structural scoring.
    binding = (
        parsed.get("structured", {"bindings": parsed.get("bindings", [])})
        if parsed["status"] in {"parsed", "valid_empty"}
        else {"bindings": []}
    )
    raw, structured = copy.deepcopy(binding), copy.deepcopy(binding)
    for item in structured.get("bindings", []):
        item.setdefault("curve_kind", "pulsed")
    known = {curve["curve_id"] for curve in front.get("curves", [])}
    if automatic:
        binding = copy.deepcopy(binding)
        binding["bindings"] = [
            item
            for item in structured["bindings"]
            if item.get("curve_kind") == "pulsed" and item.get("curve_id") in known
        ]
        binding, projection = scoped_projection(binding, pack, front)
        save(output / "projection_audit.json", projection)
    ready = parsed["status"] == "parsed" and _usable_bindings(binding, front)
    meta = _base_metadata(task, analysis, ready, parsed, result)
    decisions, records, audits = score_analysis(
        cases, truth, reference, front, binding, structured, pack, ready, meta, automatic
    )
    if automatic:
        raw_pulsed = copy.deepcopy(raw)
        raw_pulsed["bindings"] = [
            item
            for item in raw_pulsed.get("bindings", [])
            if item.get("curve_kind", "pulsed") == "pulsed" and item.get("curve_id") in known
        ]
        raw_ready = parsed["status"] == "parsed" and _usable_bindings(raw_pulsed, front)
        raw_meta = _base_metadata(task, analysis, raw_ready, parsed, result)
        raw_meta["pipeline"] = "raw model; no projection"
        raw_decisions, raw_records, _ = score_analysis(
            cases, truth, reference, front, raw_pulsed, structured, pack, raw_ready, raw_meta, True
        )
        decisions.extend(row for row in raw_decisions if row["policy"] == "baseline")
        records.extend(row for row in raw_records if row["policy"] == "baseline")
    return decisions, records, audits, meta


def evaluate_rules(task, analysis, meta):
    automatic = task["arm"] == "automatic"
    rules, front = analysis["rules"], analysis["frontend"]
    binding, structured = rules["binding"], copy.deepcopy(rules["structured"])
    for item in structured["bindings"]:
        item.setdefault("curve_kind", "pulsed")
    ready = _usable_bindings(binding, front)
    if automatic:
        ready = ready and rules["status"]["status"] == "bindings_emitted"
    profile = task.get("rules_profile") or (
        "RulesV2" if automatic or task["arm"] == "controlled" else "LayoutRules-current"
    )
    rules_meta = meta | {
        "profile": profile,
        "mode": "rules",
        "repeat_id": 0,
        "call_id": "",
        "pipeline": "rules",
        "failed_stage": None if ready else "no_usable_bindings",
    }
    return score_analysis(
        analysis["cases"],
        analysis["reference_geometry"],
        analysis["reference_binding"],
        front,
        binding,
        structured,
        analysis["source_pack"],
        ready,
        rules_meta,
        automatic,
    )


def summarize(records, output, pair):
    summary = aggregate(records, output)
    paired_results(summary, output, pair)


def score_run(project, run):
    run = Path(run)
    tasks = load(run / "manifest.json")
    missing = [
        task["call_id"]
        for task in tasks
        if not (run / "outputs" / f"{task['sequence']:04}" / "result.json").exists()
    ]
    if missing:
        raise ValueError(f"{len(missing)} planned outcomes missing; no complete score emitted")
    decisions, records, audits = [], [], []
    analyses, rules_done = {}, set()
    for task in tasks:
        key = task["analysis_file"]
        if key not in analyses:
            analyses[key] = load(project.resolve(key))
        analysis = analyses[key]
        output = run / "outputs" / f"{task['sequence']:04}"
        result = load(output / "result.json")
        ds, rs, au, meta = evaluate_model(task, analysis, result, output)
        decisions.extend(ds)
        records.extend(rs)
        audits.extend(au)
        if key not in rules_done:
            rules_done.add(key)
            ds, rs, au = evaluate_rules(task, analysis, meta)
            decisions.extend(ds)
            records.extend(rs)
            audits.extend(au)
    output = run / "results"
    save(output / "decisions.json", decisions)
    save(output / "per_analysis.json", records)
    save(output / "check_audits.json", audits)
    saved_run = load(run / "run.json") if (run / "run.json").exists() else {}
    model_pair = tuple(saved_run.get("model_pair", project.model_pair))
    summarize(records, output, model_pair)
    primary = [
        row
        for row in records
        if row["arm"] == "controlled" and row.get("family_relation") == "new-product-family"
    ]
    if primary:
        summarize(primary, output / "controlled_primary31", model_pair)
    splits = defaultdict(list)
    for row in decisions:
        if row["arm"] == "original":
            key = (
                row["profile"],
                row["mode"],
                row["policy"],
                row["pipeline"],
                row["evaluation_set"],
                row.get("case_split"),
            )
            splits[key].append(row)
    save(
        output / "original_core_diagnostic_splits.json",
        [{"configuration": key, **metric_counts(ds)} for key, ds in splits.items()],
    )
    save(
        run / "completed.json",
        {
            "status": "scored",
            "planned_tasks": len(tasks),
            "analyses": len(analyses),
        },
    )
    return {
        "planned_tasks": len(tasks),
        "analysis_count": len(analyses),
        "decision_rows": len(decisions),
    }
