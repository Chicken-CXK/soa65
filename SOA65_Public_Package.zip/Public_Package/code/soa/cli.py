"""Single command-line entrypoint; all stages share one explicit configuration."""

import argparse
import json
from .config import Project
from .storage import load


def main():
    parser = argparse.ArgumentParser(prog="python -m soa")
    parser.add_argument("--config", default="config/experiment.json")
    commands = parser.add_subparsers(dest="action", required=True)
    prepare = commands.add_parser("prepare", help="prepare a fresh manifest; never call a model")
    prepare.add_argument("--run")
    prepare.add_argument("--rebuild-frontends", action="store_true")
    prepare.add_argument("--workers", type=int, default=4)
    prepare.add_argument("--documents", nargs="+")
    execute = commands.add_parser("run", help="run undispatched tasks using the saved backend")
    execute.add_argument("--run")
    execute.add_argument("--workers", type=int, default=4)
    execute.add_argument("--limit", type=int)
    execute.add_argument("--timeout", type=float, default=600)
    api_plan = commands.add_parser(
        "api-plan", help="prepare request accounting without sending API calls"
    )
    api_plan.add_argument("--run")
    for action in ["collect", "score"]:
        command = commands.add_parser(action)
        command.add_argument("--run")
    report = commands.add_parser(
        "report", help="export completed scores as paper tables and plot data"
    )
    report.add_argument("--run")
    report.add_argument("--plots", action="store_true", help="also render vector PDF/SVG figures")
    terminal = commands.add_parser("terminal", help="record an observed no-output terminal state")
    terminal.add_argument("--run", required=True)
    terminal.add_argument("sequence", type=int)
    terminal.add_argument("state", choices=["completed_without_binding", "interrupted", "failed"])
    terminal.add_argument("--detail")
    front = commands.add_parser("frontend", help="run PDF/OCR geometry extraction only")
    front.add_argument("--pdf", required=True, help="PDF filename in the sealed dataset")
    front.add_argument("--target", required=True)
    front.add_argument("--voltage", type=float, required=True)
    front.add_argument("--output", required=True)
    commands.add_parser("verify", help="replay final selection and verify archived scores without API calls")
    args = parser.parse_args()
    project = Project.from_file(args.config)
    run = project.resolve(args.run) if getattr(args, "run", None) else project.default_run
    if args.action == "prepare":
        from .preparation import prepare_run

        result = prepare_run(project, run, args.rebuild_frontends, args.workers, args.documents)
    elif args.action == "run":
        if load(run / "run.json").get("api"):
            from .api_execution import run_api_tasks as run_tasks
        else:
            from .execution import run_tasks

        result = run_tasks(project, run, args.workers, args.limit, args.timeout)
    elif args.action == "api-plan":
        from .api_execution import plan_api_run

        result = plan_api_run(project, run)
    elif args.action == "collect":
        from .execution import collect

        result = collect(project, run)
    elif args.action == "score":
        from .scoring import score_run

        result = score_run(project, run)
    elif args.action == "report":
        from .reporting import export_run

        result = export_run(project, run, plots=args.plots)
    elif args.action == "terminal":
        from .execution import record_terminal

        task = next(
            task for task in load(run / "manifest.json") if task["sequence"] == args.sequence
        )
        record_terminal(run, task, args.state, args.detail)
        result = {"sequence": args.sequence, "terminal_state": args.state}
    elif args.action == "frontend":
        from .vision.frontend import build_all

        front = build_all(
            project.dataset / "sources/pdf" / args.pdf,
            args.target,
            args.voltage,
            project.resolve(args.output),
            ocr_command=project.ocr_command,
        )
        result = {
            "status": front["status"],
            "panels": len(front["source_panels"]),
            "candidates": len(front["curves"]),
        }
    else:
        from .validation import verify_release

        result = verify_release(project)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
