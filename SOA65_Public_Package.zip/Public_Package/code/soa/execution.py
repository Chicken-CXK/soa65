"""Shared input access, terminal records and collection of API model outputs."""

from datetime import datetime
from pathlib import Path

from .contracts import parse_binding
from .storage import load, save

TERMINAL_STATES = {"completed_without_binding", "interrupted", "failed"}
MODEL_INSTRUCTION = (
    "You are the tested extraction model in an independent experiment. "
    "All permitted task material is in this prompt and the attached images. "
    "Do not use any tools, read other files, browse, delegate, or consult previous answers. "
    "Inspect every attached image in supplied order. Return only the task binding JSON; "
    "preserve uncertainty as null.\n\n"
)


def output_dir(run, task):
    return Path(run) / "outputs" / f"{task['sequence']:04}"


def input_packet(project, task):
    return load(project.resolve(task["input_file"]))


def record_terminal(run, task, state, detail=None):
    if state not in TERMINAL_STATES:
        raise ValueError(f"Unsupported terminal state: {state}")
    output = output_dir(run, task)
    if not (output / "dispatch.json").exists():
        raise ValueError("Cannot terminal-record an undispatched task")
    if any((output / name).exists() for name in ["binding.json", "result.json", "terminal.json"]):
        raise ValueError("An output or terminal record already exists; preserve it")
    save(
        output / "terminal.json",
        {
            "call_id": task["call_id"],
            "agent_id": load(output / "dispatch.json").get("agent_id"),
            "terminal_state": state,
            "recorded_at": datetime.now().astimezone().isoformat(),
            "detail": detail,
        },
    )


def collect(project, run):
    """Preserve raw model files; derive parsed outcomes and metadata in one place."""
    tasks = load(Path(run) / "manifest.json")
    rows = []
    for task in tasks:
        output = output_dir(run, task)
        if not (output / "dispatch.json").exists():
            continue
        dispatch = load(output / "dispatch.json")
        if (output / "binding.json").exists():
            packet = input_packet(project, task)
            parsed = parse_binding(
                (output / "binding.json").read_text(), packet.get("candidate_ids")
            )
        elif (output / "terminal.json").exists():
            terminal = load(output / "terminal.json")
            parsed = {
                "status": "no_output",
                "bindings": [],
                "terminal_state": terminal["terminal_state"],
                "terminal_detail": terminal.get("detail"),
            }
        else:
            rows.append({"call_id": task["call_id"], "status": "awaiting_submission"})
            continue
        execution = load(output / "execution.json") if (output / "execution.json").exists() else {}
        result = {
            "call_id": task["call_id"],
            "agent_id": dispatch.get("agent_id"),
            "requested_model": task["requested_model"],
            "single_attempt": parsed,
            "agent_attempts": execution.get("subprocess_attempts", 0),
            "HTTP_attempts": execution.get("HTTP_attempts"),
            "token_usage": execution.get("usage"),
            "backend": dispatch["backend"],
        }
        if parsed["status"] == "no_output":
            result["failed_stage"] = (
                execution.get("failed_stage") or "api_" + parsed["terminal_state"]
            )
        save(output / "result.json", result)
        rows.append({"call_id": task["call_id"], "status": parsed["status"]})
    save(Path(run) / "collection.json", rows)
    return {
        "planned": len(tasks),
        "dispatched": len(rows),
        "submitted": sum(row["status"] != "awaiting_submission" for row in rows),
    }
