"""Native Codex execution with explicit project/run context and a single collection path."""

from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
import json
import shutil
import subprocess
import tempfile
import time

from .contracts import parse_binding
from .storage import load, save

TERMINAL_STATES = {"completed_without_binding", "interrupted", "failed"}
MODEL_INSTRUCTION = (
    "You are the tested extraction model in an independent experiment. "
    "All permitted task material is in this prompt and the attached images. "
    "Do not use any tools, read other files, browse, delegate, or consult previous answers. "
    "Inspect every attached image in supplied order. Return only the task binding JSON; "
    "preserve uncertainty as null.\n\n"
)


def output_dir(run, task):
    return Path(run) / "outputs" / f"{task['sequence']:04}"


def input_packet(project, task):
    return load(project.resolve(task["input_file"]))


def record_terminal(run, task, state, detail=None):
    if state not in TERMINAL_STATES:
        raise ValueError(f"Unsupported terminal state: {state}")
    output = output_dir(run, task)
    if not (output / "dispatch.json").exists():
        raise ValueError("Cannot terminal-record an undispatched task")
    if any((output / name).exists() for name in ["binding.json", "result.json", "terminal.json"]):
        raise ValueError("An output or terminal record already exists; preserve it")
    save(
        output / "terminal.json",
        {
            "call_id": task["call_id"],
            "agent_id": load(output / "dispatch.json").get("agent_id"),
            "terminal_state": state,
            "recorded_at": datetime.now().astimezone().isoformat(),
            "detail": detail,
        },
    )


def collect(project, run):
    """Preserve raw model files; derive parsed outcomes and metadata in one place."""
    tasks = load(Path(run) / "manifest.json")
    rows = []
    for task in tasks:
        output = output_dir(run, task)
        if not (output / "dispatch.json").exists():
            continue
        dispatch = load(output / "dispatch.json")
        if (output / "binding.json").exists():
            packet = input_packet(project, task)
            parsed = parse_binding(
                (output / "binding.json").read_text(), packet.get("candidate_ids")
            )
        elif (output / "terminal.json").exists():
            terminal = load(output / "terminal.json")
            parsed = {
                "status": "no_output",
                "bindings": [],
                "terminal_state": terminal["terminal_state"],
                "terminal_detail": terminal.get("detail"),
            }
        else:
            rows.append({"call_id": task["call_id"], "status": "awaiting_submission"})
            continue
        execution = load(output / "execution.json") if (output / "execution.json").exists() else {}
        result = {
            "call_id": task["call_id"],
            "agent_id": dispatch.get("agent_id"),
            "requested_model": task["requested_model"],
            "single_attempt": parsed,
            "agent_attempts": execution.get("subprocess_attempts", 1),
            "HTTP_attempts": execution.get("HTTP_attempts"),
            "token_usage": execution.get("usage"),
            "backend": dispatch.get("backend", "Codex native CLI"),
        }
        if parsed["status"] == "no_output":
            result["failed_stage"] = (
                execution.get("failed_stage") or "native_" + parsed["terminal_state"]
            )
        save(output / "result.json", result)
        rows.append({"call_id": task["call_id"], "status": parsed["status"]})
    save(Path(run) / "collection.json", rows)
    return {
        "planned": len(tasks),
        "dispatched": len(rows),
        "submitted": sum(row["status"] != "awaiting_submission" for row in rows),
    }


def read_events(path):
    events = []
    for line in Path(path).read_text().splitlines():
        try:
            events.append(json.loads(line))
        except ValueError:
            continue
    return events


def execute_task(project, run, task, timeout):
    output = output_dir(run, task)
    output.mkdir(parents=True, exist_ok=True)
    if (output / "dispatch.json").exists():
        return {"sequence": task["sequence"], "status": "already_dispatched_no_retry"}
    packet = input_packet(project, task)
    prompt = MODEL_INSTRUCTION + project.resolve(packet["prompt_file"]).read_text()
    images = (
        [project.resolve(image["path"]) for image in packet["images"]]
        if task["mode"] == "vision"
        else []
    )
    command = [
        shutil.which(project.codex_command) or project.codex_command,
        "--ask-for-approval",
        "never",
        "exec",
        "--ephemeral",
        "--skip-git-repo-check",
        "--json",
        "--model",
        task["requested_model"],
        "-c",
        f'model_reasoning_effort="{task["reasoning_effort"]}"',
        "--sandbox",
        "read-only",
        "--output-last-message",
        str(output / "binding.json"),
    ]
    for image in images:
        command.extend(["--image", str(image)])
    command.append("-")
    (output / "submitted_prompt.txt").write_text(prompt)
    dispatch = task | {
        "agent_id": None,
        "backend": "Codex native CLI",
        "fresh_context": "--ephemeral",
        "command": command,
        "images": [str(image) for image in images],
        "dispatched_at": datetime.now().astimezone().isoformat(),
        "external_API_calls": 0,
        "subprocess_attempts": 1,
        "internal_HTTP_attempts": None,
    }
    save(output / "dispatch.json", dispatch)
    started = time.monotonic()
    exit_code, failure = None, None
    with tempfile.TemporaryDirectory(prefix="soa-native-") as cwd:
        with (
            (output / "events.jsonl").open("w") as stdout,
            (output / "stderr.log").open("w") as stderr,
        ):
            process = None
            try:
                process = subprocess.Popen(
                    command, cwd=cwd, stdin=subprocess.PIPE, stdout=stdout, stderr=stderr, text=True
                )
                process.communicate(prompt, timeout=timeout)
                exit_code = process.returncode
            except subprocess.TimeoutExpired:
                process.kill()
                process.communicate()
                exit_code = process.returncode
                failure = "CLI request timeout"
            except OSError as error:
                if process is not None:
                    process.kill()
                    process.wait()
                    exit_code = process.returncode
                failure = f"CLI launch/communication failed: {error}"
    events = read_events(output / "events.jsonl")
    dispatch["agent_id"] = next(
        (event.get("thread_id") for event in events if event.get("type") == "thread.started"), None
    )
    usage = next(
        (event.get("usage") for event in reversed(events) if event.get("type") == "turn.completed"),
        None,
    )
    tool_events = [
        event.get("item", {}).get("type")
        for event in events
        if event.get("type") == "item.completed"
        and event.get("item", {}).get("type") not in ["agent_message", "reasoning"]
    ]
    execution = {
        "exit_code": exit_code,
        "elapsed_s": time.monotonic() - started,
        "usage": usage,
        "tool_events": tool_events,
        "error": failure,
        "subprocess_attempts": 1,
        "internal_HTTP_attempts": None,
    }
    save(output / "dispatch.json", dispatch)
    save(output / "execution.json", execution)
    if not (output / "binding.json").exists() or not (output / "binding.json").read_text().strip():
        if (output / "binding.json").exists():
            (output / "binding.json").rename(output / "empty_last_message.txt")
        state = "failed" if failure or exit_code else "completed_without_binding"
        record_terminal(run, task, state, failure or f"CLI exit {exit_code}; no final binding")
    return {
        "sequence": task["sequence"],
        "status": "submitted" if (output / "binding.json").exists() else "terminal",
        "exit_code": exit_code,
        "elapsed_s": execution["elapsed_s"],
    }


def run_tasks(project, run, workers=4, limit=None, timeout=600):
    tasks = load(Path(run) / "manifest.json")
    pending = [task for task in tasks if not (output_dir(run, task) / "dispatch.json").exists()]
    if limit is not None:
        if limit < 1:
            raise ValueError("limit must be positive")
        pending = pending[:limit]
    progress = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(execute_task, project, run, task, timeout) for task in pending]
        for future in as_completed(futures):
            result = future.result()
            progress.append(result)
            save(Path(run) / "progress.json", progress)
            print(json.dumps(result), flush=True)
    return collect(project, run)
