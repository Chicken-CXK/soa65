"""Native model output schema and parser; no provider transport code."""

import json, math

FIELDS = {"curve_id", "duration_s", "pulse_mode", "temperature_symbol", "temperature_C"}
SCHEMA = {
    "type": "object",
    "required": ["bindings"],
    "properties": {
        "bindings": {
            "type": "array",
            "items": {
                "type": "object",
                "required": sorted(FIELDS),
                "properties": {
                    "curve_id": {"type": "string"},
                    "curve_kind": {
                        "type": "string",
                        "enum": ["pulsed", "dc", "non_boundary", "unresolved"],
                    },
                    "duration_s": {"type": ["number", "null"]},
                    "pulse_mode": {"type": ["string", "null"]},
                    "temperature_symbol": {"type": ["string", "null"]},
                    "temperature_C": {"type": ["number", "null"]},
                },
            },
        },
        "hard_current_cap_A": {"type": ["number", "null"]},
        "scope_conflict_above_A": {"type": ["number", "null"]},
    },
}


def validate(data):
    if not isinstance(data, dict) or not isinstance(data.get("bindings"), list):
        raise ValueError("bindings must be an array")
    for b in data["bindings"]:
        if not isinstance(b, dict) or not FIELDS <= b.keys():
            raise ValueError("missing binding fields")
        if not isinstance(b["curve_id"], str) or not b["curve_id"]:
            raise ValueError("curve_id")
        if "curve_kind" in b and b["curve_kind"] not in [
            "pulsed",
            "dc",
            "non_boundary",
            "unresolved",
        ]:
            raise ValueError("curve_kind")
        for k in ["duration_s", "temperature_C"]:
            x = b[k]
            if x is not None and (
                isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x)
            ):
                raise ValueError(k + " must be finite number or null")
        for k in ["pulse_mode", "temperature_symbol"]:
            if b[k] is not None and not isinstance(b[k], str):
                raise ValueError(k + " must be string or null")
    for k in ["hard_current_cap_A", "scope_conflict_above_A"]:
        x = data.get(k)
        if x is not None and (
            isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x)
        ):
            raise ValueError(k)
    return data


def _reject_constant(token):
    raise ValueError(token)


def _parse_text(text, candidate_ids=None):
    if not isinstance(text, str) or not text.strip():
        return {"status": "empty_final_content", "bindings": []}
    text = text.strip()
    if text.startswith("```") and text.endswith("```"):
        if "\n" not in text:
            return {"status": "json_error", "bindings": []}
        text = text.split("\n", 1)[1].rsplit("```", 1)[0].strip()
    try:
        # One syntactically valid object only. No comma insertion or model-assisted repair.
        decoder = json.JSONDecoder(parse_constant=_reject_constant)
        start = text.index("{")
        data, end = decoder.raw_decode(text, start)
        if "{" in text[end:]:
            raise ValueError("multiple JSON objects")
    except (ValueError, TypeError):
        return {"status": "json_error", "bindings": []}
    try:
        validate(data)
    except ValueError as e:
        return {"status": "schema_error", "bindings": [], "error": str(e), "structured": data}
    anomalies = []
    seen = set()
    for b in data["bindings"]:
        if candidate_ids is not None and b["curve_id"] not in candidate_ids:
            anomalies.append("unknown_curve_id:" + b["curve_id"])
        key = tuple(b.get(k) for k in sorted(FIELDS))
        if key in seen:
            anomalies.append("duplicate_relation")
        seen.add(key)
    return {
        "status": "valid_empty" if not data["bindings"] else "parsed",
        "bindings": data["bindings"],
        "structured": data,
        "semantic_anomalies": anomalies,
    }


def conflicting_curve_conditions(bindings):
    """Flag only conflicts that cannot represent distinct shared-stroke durations."""
    condition_classes = {}
    for binding in bindings:
        condition = tuple(
            binding.get(name)
            for name in ("curve_id", "duration_s", "temperature_symbol", "temperature_C")
        )
        condition_classes.setdefault(condition, set()).add(
            (binding.get("pulse_mode"), binding.get("curve_kind"))
        )
    return [
        "conflicting_curve_condition:" + str(condition[0])
        for condition, classes in condition_classes.items()
        if len(classes) > 1
    ]


def parse_binding(raw_text, candidates):
    """Parse the exact submitted text; preserve schema errors and semantic anomalies."""
    parsed = _parse_text(raw_text, candidates)
    if parsed["status"] in {"json_error", "schema_error"}:
        # Keep the legacy collection status while exposing the parsing reason.
        parsed["parse_status"] = parsed["status"]
        parsed["status"] = "schema_or_json_error"
        try:
            parsed["submitted_json"] = json.loads(raw_text)
        except json.JSONDecodeError:
            parsed["submitted_text"] = raw_text
        return parsed
    if parsed["status"] in {"parsed", "valid_empty"}:
        anomalies = list(parsed.get("semantic_anomalies", []))
        anomalies.extend(conflicting_curve_conditions(parsed["bindings"]))
        if anomalies:
            parsed["semantic_anomalies"] = anomalies
    return parsed
