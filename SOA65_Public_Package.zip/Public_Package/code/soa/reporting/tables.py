"""Flat publication tables derived from the saved scoring records."""

from collections import defaultdict
from statistics import mean, stdev

CONFIG = ("arm", "cohort", "profile", "mode", "policy", "pipeline")
METRICS = (
    "label_accuracy",
    "binding_agreement",
    "correct_decision_coverage",
    "false_release_fraction",
    "false_release_over_non_supported",
)
FRACTIONS = {
    "label_accuracy": ("correct", "n"),
    "binding_agreement": ("binding_matched", "binding_total"),
    "correct_decision_coverage": ("correct_decisive", "eligible_decisions"),
    "false_release_fraction": ("false_releases", "actual_releases"),
    "false_release_over_non_supported": ("false_releases", "non_supported_cases"),
    "no_output_rate": ("no_output", "n"),
    "abstention_rate": ("abstentions", "n"),
}


def ratio(numerator, denominator):
    return numerator / denominator if denominator else None


def configuration(row):
    return dict(zip(CONFIG, row["configuration"]))


def key(row):
    return tuple(row[k] for k in CONFIG)


def scalar_record(row):
    result = {k: v for k, v in row.items() if not isinstance(v, (dict, list))}
    for field, value in row.items():
        if field.endswith("_fraction") and isinstance(value, list):
            result[field + "_numerator"], result[field + "_denominator"] = value
    return result


def summary_tables(summaries, records):
    grouped = defaultdict(list)
    for record in records:
        grouped[key(record)].append(record)
    main, documents, families, confusion, classes = [], [], [], [], []
    for summary in summaries:
        cfg = configuration(summary)
        rs = grouped[key(cfg)]
        counts = summary["counts_over_all_prespecified_repeats"] | {
            "binding_matched": sum(r["binding_fraction"][0] for r in rs),
            "binding_total": sum(r["binding_fraction"][1] for r in rs),
            "correct_decisive": sum(r["CDC_fraction"][0] for r in rs),
            "abstentions": sum(r["abstentions"] for r in rs),
        }
        main.append(
            cfg
            | {
                "documents": summary["documents"],
                "families": len(summary["family_results"]),
                "analysis_units": len({r["analysis_id"] for r in rs}),
                "analysis_repeat_records": len(rs),
                "repeat_ids": sorted({r["repeat_id"] for r in rs}),
            }
            | counts
            | {"micro_" + m: ratio(counts[a], counts[b]) for m, (a, b) in FRACTIONS.items()}
            | {"family_macro_" + m: v for m, v in summary["family_macro"].items()}
        )
        documents.extend(cfg | d for d in summary["document_results"])
        families.extend(
            cfg
            | {"family": f, "documents": sum(d["family"] == f for d in summary["document_results"])}
            | v
            for f, v in summary["family_results"].items()
        )
        matrix = {
            g: {
                p: sum(r["confusion"][g][p] for r in rs)
                for p in ["SUPPORTED", "SCREEN_FAIL", "INSUFFICIENT", "NO_OUTPUT"]
            }
            for g in ["SUPPORTED", "SCREEN_FAIL", "INSUFFICIENT"]
        }
        for gold, predictions in matrix.items():
            support = sum(predictions.values())
            for prediction, count in predictions.items():
                confusion.append(
                    cfg
                    | {
                        "gold": gold,
                        "prediction": prediction,
                        "count": count,
                        "gold_total": support,
                        "row_fraction": ratio(count, support),
                    }
                )
            tp = predictions[gold]
            predicted = sum(m[gold] for m in matrix.values())
            classes.append(
                cfg
                | {
                    "label": gold,
                    "support": support,
                    "predicted": predicted,
                    "true_positive": tp,
                    "precision": ratio(tp, predicted),
                    "recall": ratio(tp, support),
                    "f1": ratio(2 * tp, support + predicted),
                }
            )
    return {
        "summary": main,
        "documents": documents,
        "families": families,
        "confusion": confusion,
        "per_class": classes,
    }


def repeat_stability(records):
    groups = defaultdict(list)
    for r in records:
        groups[key(r) + (r["doc_id"], r["analysis_id"])].append(r)
    rows = []
    for rs in groups.values():
        for metric in METRICS:
            values = [r[metric] for r in rs if r[metric] is not None]
            rows.append(
                {k: rs[0][k] for k in CONFIG + ("doc_id", "analysis_id", "family")}
                | {
                    "metric": metric,
                    "repeats": len(rs),
                    "defined_repeats": len(values),
                    "mean": mean(values) if values else None,
                    "sample_sd": stdev(values) if len(values) > 1 else None,
                    "minimum": min(values) if values else None,
                    "maximum": max(values) if values else None,
                }
            )
    return rows


def ablations(summaries):
    indexed = {tuple(s["configuration"]): s for s in summaries}
    rows = []
    for s in summaries:
        cfg = configuration(s)
        base_cfg = cfg | {"policy": "baseline"}
        base = indexed.get(key(base_cfg))
        if cfg["policy"] == "baseline" or base is None:
            continue
        for metric in METRICS:
            current, reference = s["family_macro"][metric], base["family_macro"][metric]
            delta = current - reference if current is not None and reference is not None else None
            direction = -1 if metric.startswith("false_release") else 1
            rows.append(
                cfg
                | {
                    "metric": metric,
                    "aggregation": "family_macro",
                    "baseline": reference,
                    "value": current,
                    "delta": delta,
                    "delta_pp": delta * 100 if delta is not None else None,
                    "relative_improvement": direction * delta / abs(reference)
                    if delta is not None and reference
                    else None,
                    "higher_is_better": direction == 1,
                }
            )
    return rows


def paired_tables(rows, unit):
    flat = []
    for row in rows:
        name = next(k for k in row if "_minus_" in k)
        right, left = name.split("_minus_", 1)
        identity = {k: v for k, v in row.items() if k not in ("configuration", name)}
        flat.extend(
            configuration(row)
            | identity
            | {
                "unit": unit,
                "left_model": left,
                "right_model": right,
                "metric": metric,
                "delta_right_minus_left": value,
                "delta_pp": value * 100 if value is not None else None,
            }
            for metric, value in row[name].items()
        )
    return flat


def sensitivity_table(rows, pairs):
    models = {key(p): {k: p[k] for k in ("left_model", "right_model")} for p in pairs}
    flat = []
    for row in rows:
        for metric, stats in row["statistics"].items():
            bounds = stats["source_composition_range_95"] or [None, None]
            flat.append(
                configuration(row)
                | models[tuple(row["configuration"])]
                | {
                    "metric": metric,
                    "mean_delta": stats["mean"],
                    "source_composition_low": bounds[0],
                    "source_composition_high": bounds[1],
                    "families": stats["families"],
                    "seed": row["seed"],
                    "bootstrap_replicates": row["replicates"],
                }
            )
    return flat


def efficiency(calls):
    """One observation per model call; never multiply usage by scoring policies."""
    import numpy as np

    groups = defaultdict(list)
    fields = ("arm", "cohort", "profile", "requested_model", "reasoning_effort", "mode")
    for call in calls:
        groups[tuple(call[k] for k in fields)].append(call)
    rows = []
    for cfg, xs in groups.items():
        times = [x["elapsed_s"] for x in xs if x["elapsed_s"] is not None]
        row = dict(zip(fields, cfg)) | {
            "calls": len(xs),
            "documents": len({x["doc_id"] for x in xs}),
            "timing_known_calls": len(times),
            "elapsed_mean_s": mean(times) if times else None,
            "elapsed_median_s": float(np.median(times)) if times else None,
            "elapsed_p95_s": float(np.percentile(times, 95)) if times else None,
            "elapsed_min_s": min(times) if times else None,
            "elapsed_max_s": max(times) if times else None,
            "exit_code_unknown": sum(x["exit_code"] is None for x in xs),
            "nonzero_exit_calls": sum(
                x["exit_code"] is not None and x["exit_code"] != 0 for x in xs
            ),
        }
        for token in (
            "input_tokens",
            "cached_input_tokens",
            "output_tokens",
            "reasoning_output_tokens",
        ):
            values = [x[token] for x in xs if x[token] is not None]
            row[token + "_known_calls"] = len(values)
            row[token + "_observed_sum"] = sum(values) if values else None
        rows.append(row)
    return rows
