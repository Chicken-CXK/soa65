"""Reproducible vector figures using exported tables as their only numeric inputs."""

import csv
from collections import Counter
from pathlib import Path
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

COLORS = ("#0072B2", "#D55E00")
POLICIES = ("baseline", "candidate", "order", "evidence", "candidate_order", "combined")
LABELS = ("Base", "C", "O", "E", "C+O", "All")


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def number(row, field):
    return float(row[field]) if row[field] else np.nan


def model_info(paper):
    calls = rows(paper / "calls.csv")
    profiles = list(dict.fromkeys(row["profile"] for row in calls))
    labels = {
        row["profile"]: row.get("model_display_name") or row["requested_model"] for row in calls
    }
    return profiles, labels


def policy_metrics(paper):
    pair, display = model_info(paper)
    source = paper / "controlled_primary31/summary.csv"
    if not source.exists():
        return None
    data = [r for r in rows(source) if r["profile"] in pair and r["mode"] == "vision"]
    if not data:
        return None
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.3), layout="constrained")
    for ax, metric, label in zip(
        axes,
        ("label_accuracy", "correct_decision_coverage"),
        ("Label agreement (%)", "Correct decision coverage (%)"),
    ):
        for i, model in enumerate(pair):
            values = [
                100
                * number(
                    next(r for r in data if r["profile"] == model and r["policy"] == p),
                    "family_macro_" + metric,
                )
                for p in POLICIES
            ]
            ax.bar(
                np.arange(6) + (i - 0.5) * 0.36,
                values,
                width=0.36,
                color=COLORS[i],
                hatch="" if i == 0 else "//",
                label=display[model],
            )
        ax.set_xticks(range(6), LABELS)
        ax.set_ylim(0, 105)
        ax.set_ylabel(label)
        ax.set_xlabel("Consistency policy")
    fig.legend(
        *axes[0].get_legend_handles_labels(), loc="outside upper center", ncol=2, frameon=False
    )
    return fig, (
        "Controlled primary cohort: "
        + data[0]["documents"]
        + " documents, "
        + data[0]["families"]
        + " product families, vision inputs and three prespecified calls per analysis/model. "
        "Bars are family macro averages. Base: baseline; C: candidate; O: order; E: evidence; "
        "C+O: candidate/order; All: combined. Repeats are not independent documents."
    )


def automatic_binding(paper):
    pair, display = model_info(paper)
    data = [
        r
        for r in rows(paper / "summary.csv")
        if r["arm"] == "automatic"
        and r["profile"] in pair
        and r["policy"] in ("baseline", "combined")
        and r["pipeline"] == "model + local-condition projection"
    ]
    if not data:
        return None
    cohorts = list(dict.fromkeys(r["cohort"] for r in data))
    fig, ax = plt.subplots(figsize=(7.2, 3.6), layout="constrained")
    for i, (model, policy) in enumerate((m, p) for m in pair for p in ("baseline", "combined")):
        selected = [
            next(
                r
                for r in data
                if r["cohort"] == c and r["profile"] == model and r["policy"] == policy
            )
            for c in cohorts
        ]
        ax.bar(
            np.arange(len(cohorts)) + (i - 1.5) * 0.2,
            [100 * number(r, "family_macro_binding_agreement") for r in selected],
            width=0.2,
            color=COLORS[i // 2],
            hatch="" if policy == "baseline" else "//",
            label=display[model] + " / " + policy,
        )
    labels = [
        c + "\n(n=" + next(r["documents"] for r in data if r["cohort"] == c) + " docs)"
        for c in cohorts
    ]
    ax.set_xticks(range(len(cohorts)), labels)
    ax.set_ylim(0, 105)
    ax.set_ylabel("Relation agreement (%)")
    ax.set_xlabel("Automatic cohort")
    fig.legend(*ax.get_legend_handles_labels(), loc="outside upper center", ncol=2, frameon=False)
    return fig, (
        "Automatic vision cohorts, shown separately with document counts. Family macro relation "
        "agreement after fixed frontend extraction and local-condition projection; three prespecified "
        "calls per analysis/model. Baseline already includes the projection. Hatched bars add combined "
        "consistency checks. Repeats and voltage probes are not independent source documents."
    )


def paired_sensitivity(paper):
    pair, display = model_info(paper)
    data = [
        r
        for r in rows(paper / "source_sensitivity.csv")
        if r["arm"] == "automatic"
        and r["mode"] == "vision"
        and r["policy"] in ("baseline", "combined")
        and r["pipeline"] == "model + local-condition projection"
        and r["metric"] == "label_accuracy"
    ]
    if not data:
        return None
    paired = rows(paper / "paired_families.csv")
    matching = next(r for r in paired if r["arm"] == "automatic")
    fig, ax = plt.subplots(figsize=(7.2, 3.6), layout="constrained")
    for i, r in enumerate(data):
        low, high = [
            100 * number(r, k) for k in ("source_composition_low", "source_composition_high")
        ]
        value = 100 * number(r, "mean_delta")
        ax.hlines(i, low, high, color=COLORS[0], linewidth=1.5)
        ax.plot(value, i, "o", color=COLORS[0], markersize=4)
    ax.axvline(0, color=".5", linewidth=0.8, linestyle="--")
    ax.set_yticks(
        range(len(data)),
        [r["cohort"] + " / " + r["policy"] + " (F=" + r["families"] + ")" for r in data],
    )
    ax.invert_yaxis()
    ax.set_xlabel(
        display[matching["right_model"]]
        + " minus "
        + display[matching["left_model"]]
        + " label agreement (pp)"
    )
    return fig, (
        "Paired automatic-cohort label-agreement differences, in percentage points. "
        "Points are mean product-family differences; bars are the existing 95% source-composition "
        "sensitivity ranges ("
        + data[0]["bootstrap_replicates"]
        + " family resamples, seed "
        + data[0]["seed"]
        + "). "
        "F denotes product families. These ranges are not external-generalization confidence intervals "
        "or significance tests. Baseline includes local-condition projection."
    )


def latency(paper):
    pair, display = model_info(paper)
    data = rows(paper / "calls.csv")
    arms = list(dict.fromkeys(r["arm"] for r in data))
    fig, axes = plt.subplots(
        1, len(arms), figsize=(3.1 * len(arms), 3.3), squeeze=False, layout="constrained"
    )
    for ax, arm in zip(axes[0], arms):
        xs = [
            [
                number(r, "elapsed_s")
                for r in data
                if r["arm"] == arm and r["profile"] == m and r["elapsed_s"]
            ]
            for m in pair
        ]
        ax.boxplot(
            xs,
            tick_labels=[
                m + "\n(n=" + str(len(x)) + ")" for m, x in zip([display[m] for m in pair], xs)
            ],
            widths=0.5,
            medianprops={"color": COLORS[1]},
        )
        ax.set_xlabel(arm + " arm")
        ax.set_ylabel("Request wall time (s)")
    composition = []
    for arm in arms:
        parts = []
        for model in pair:
            counts = Counter(r["mode"] for r in data if r["arm"] == arm and r["profile"] == model)
            parts.append(
                display[model] + " " + ", ".join(f"{mode}={n}" for mode, n in counts.items())
            )
        composition.append(arm + ": " + "; ".join(parts))
    return fig, (
        "Observed wall time of the recorded execution step (CLI lifetime or HTTP request), including provider waiting, "
        "split by experiment arm. n is calls, not independent documents. Boxes show quartiles and "
        "median; whiskers extend to data within 1.5 IQR and points show remaining observations. "
        "These timings describe this concurrent run, not isolated model inference speed."
        + " Input composition (calls): "
        + ". ".join(composition)
        + ". "
        "Arms differ in source documents and input conditions; model comparisons are within each panel."
    )


PLOTS = {
    "policy_metrics": policy_metrics,
    "automatic_binding": automatic_binding,
    "paired_sensitivity": paired_sensitivity,
    "latency": latency,
}


def render_one(paper, name):
    paper = Path(paper)
    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.size": 9,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "pdf.fonttype": 42,
            "svg.fonttype": "none",
            "savefig.dpi": 180,
        }
    )
    result = PLOTS[name](paper)
    if result is None:
        return None
    fig, caption = result
    out = paper / "figures"
    out.mkdir(exist_ok=True)
    for extension in ("pdf", "svg", "png"):
        fig.savefig(out / (name + "." + extension), bbox_inches="tight")
    plt.close(fig)
    (out / ("gen_" + name + ".py")).write_text(
        "from pathlib import Path\nfrom soa.reporting.figures import render_one\n"
        f"render_one(Path(__file__).resolve().parent.parent, {name!r})\n"
    )
    return caption


def render_figures(paper):
    captions = {name: caption for name in PLOTS if (caption := render_one(paper, name)) is not None}
    out = paper / "figures"
    out.mkdir(exist_ok=True)
    text = []
    from .export import latex_escape

    for name, caption in captions.items():
        text.extend(
            [
                r"\begin{figure}[t]",
                r"\centering",
                r"\includegraphics[width=\linewidth]{figures/" + name + r".pdf}",
                r"\caption{" + latex_escape(caption) + "}",
                r"\label{fig:soa-" + name.replace("_", "-") + "}",
                r"\end{figure}",
                "",
            ]
        )
    (out / "latex_includes.tex").write_text("\n".join(text))
    (out / "CAPTIONS.md").write_text(
        "\n\n".join("## " + n + "\n\n" + c for n, c in captions.items()) + "\n"
    )
    return captions
