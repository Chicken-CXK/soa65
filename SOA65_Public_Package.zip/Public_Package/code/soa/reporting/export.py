"""Export completed runs for paper writing without changing their scores."""

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

from ..storage import load, save
from .tables import (
    CONFIG,
    METRICS,
    ablations,
    efficiency,
    key,
    paired_tables,
    repeat_stability,
    scalar_record,
    sensitivity_table,
    summary_tables,
)

QUERY_FIELDS = (
    "category",
    "voltage_V",
    "current_A",
    "duration_s",
    "pulse_mode",
    "temperature_symbol",
    "temperature_C",
    "initial_state",
    "source_curve_id",
)


def write_csv(path, rows, fields=None):
    rows = list(rows)
    columns = fields or list(dict.fromkeys(k for r in rows for k in r))
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    k: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v
                    for k, v in row.items()
                }
            )
    return {
        "rows": len(rows),
        "columns": columns,
        "nullable_columns": [k for k in columns if any(r.get(k) is None for r in rows)],
    }


def call_and_source_tables(project, run, tasks):
    calls, sources, analyses = [], [], {}
    for task in tasks:
        file = task["analysis_file"]
        if file not in analyses:
            a = load(project.resolve(file))
            analyses[file] = a
            sources.append(
                {
                    "analysis_file": file,
                    "arm": task["arm"],
                    "cohort": task["cohort"],
                    "analysis_id": task["analysis_id"],
                    "doc_id": task["doc_id"],
                    **a["metadata"],
                    **a["source"],
                    "query_count": len(a["cases"]),
                    "reference_relations": len(a["reference_binding"]["bindings"]),
                    "candidate_curves": len(a["frontend"].get("curves", [])),
                    "source_pages": sorted(
                        {
                            c.get("source_page", a["frontend"].get("page"))
                            for c in a["frontend"].get("curves", [])
                            if c.get("source_page", a["frontend"].get("page")) is not None
                        }
                    ),
                }
            )
        a = analyses[file]
        d = run / "outputs" / f"{task['sequence']:04}"
        result = load(d / "result.json")
        dispatch = load(d / "dispatch.json")
        execution = load(d / "execution.json") if (d / "execution.json").exists() else {}
        usage = execution.get("usage") or result.get("token_usage") or {}
        calls.append(
            task
            | {
                "family": a["metadata"]["family"],
                "pdf_name": a["source"]["pdf_name"],
                "backend": result.get("backend"),
                "model_display_name": task.get("model_settings", {}).get(
                    "display_name", task["profile"].title()
                ),
                "agent_id": result.get("agent_id"),
                "dispatched_at": dispatch.get("dispatched_at"),
                "elapsed_s": execution.get("elapsed_s"),
                "exit_code": execution.get("exit_code"),
                "parse_status": result["single_attempt"]["status"],
                "failed_stage": result.get("failed_stage"),
                "execution_error": execution.get("error"),
                "tool_events": execution.get("tool_events"),
                "semantic_anomalies": result["single_attempt"].get("semantic_anomalies", []),
                "subprocess_attempts": execution.get("subprocess_attempts"),
                "HTTP_attempts": execution.get("HTTP_attempts"),
                "http_status": execution.get("http_status"),
                "request_id": execution.get("request_id"),
                "returned_model": execution.get("returned_model"),
                "finish_reason": execution.get("finish_reason"),
                "cost_estimate_cny": execution.get("cost_estimate_cny"),
                "user_price_estimate_cny": execution.get("user_price_estimate_cny"),
                "raw_response_file": str(d / "response.raw")
                if (d / "response.raw").exists()
                else None,
                "input_tokens": usage.get("input_tokens"),
                "cached_input_tokens": usage.get("cached_input_tokens"),
                "output_tokens": usage.get("output_tokens"),
                "reasoning_output_tokens": usage.get("reasoning_output_tokens"),
                "raw_binding_file": str(d / "binding.json")
                if (d / "binding.json").exists()
                else None,
                "parsed_result_file": str(d / "result.json"),
                "execution_file": str(d / "execution.json")
                if (d / "execution.json").exists()
                else None,
            }
        )
    return calls, sources, analyses


def enrich_decisions(decisions, tasks, analyses):
    files = {(t["arm"], t["cohort"], t["analysis_id"]): t["analysis_file"] for t in tasks}
    cases = {f: {c["id"]: c for c in a["cases"]} for f, a in analyses.items()}
    refs = {
        f: {c["curve_id"]: c for c in a["reference_geometry"]["curves"]}
        for f, a in analyses.items()
    }
    for row in decisions:
        file = files[(row["arm"], row["cohort"], row["analysis_id"])]
        case = cases[file][row["case_id"]]
        a = analyses[file]
        curve = refs[file].get(case.get("source_curve_id"), {})
        yield row | {
            "analysis_file": file,
            "pdf_name": a["source"]["pdf_name"],
            "target_part": a["source"]["target_part"],
            "source_page": curve.get("source_page", a["reference_geometry"].get("page")),
            "source_panel_bbox": curve.get(
                "source_panel_bbox", a["reference_geometry"].get("plot_bbox")
            ),
            **{name: case.get(name) for name in QUERY_FIELDS},
            "is_correct": row["gold"] == row["prediction"],
            "is_false_release": row["prediction"] == "SUPPORTED" and row["gold"] != "SUPPORTED",
        }


def error_groups(decisions):
    groups = defaultdict(list)
    for row in decisions:
        groups[key(row) + (row.get("category"),)].append(row)
    out = []
    for rows in groups.values():
        errors = Counter(
            (r["gold"], r["prediction"], r["reason"]) for r in rows if not r["is_correct"]
        )
        for (gold, prediction, reason), n in errors.items():
            out.append(
                {k: rows[0][k] for k in CONFIG}
                | {
                    "category": rows[0].get("category"),
                    "gold": gold,
                    "prediction": prediction,
                    "reason": reason,
                    "errors": n,
                    "category_decisions": len(rows),
                    "fraction_of_category": n / len(rows),
                }
            )
    return out


def latex_escape(value):
    replacements = {
        "\\": r"\textbackslash{}",
        "_": r"\_",
        "%": r"\%",
        "&": r"\&",
        "#": r"\#",
        "{": r"\{",
        "}": r"\}",
        "$": r"\$",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(c, c) for c in str(value))


def write_tables(out, main):
    """Keep every policy and baseline, grouped into separate comparable tables."""
    groups = defaultdict(list)
    for row in main:
        groups[(row["arm"], row["cohort"], row["mode"], row["pipeline"])].append(row)
    tex, md = (
        [],
        [
            "# Results across all configurations",
            "",
            "All rates are percentages. LA, BA and CDC are product-family macro averages; FR and NO pool the prescribed repeats. Tables separate experimental configurations.",
            "",
        ],
    )
    fmt = lambda v: "--" if v is None else f"{v * 100:.2f}"
    for group, rows in groups.items():
        title = " / ".join(group)
        tex += [
            r"\begin{table}[t]",
            r"\centering",
            r"\caption{"
            + latex_escape(title)
            + r". LA, BA and CDC are family macro averages (percent). FR and NO are counts over prespecified repeats; repeats are not independent documents.}",
            r"\begin{tabular}{llrrrrrr}",
            r"\hline",
            r"Model & Policy & Docs & LA & BA & CDC & FR & NO \\",
            r"\hline",
        ]
        md += [
            "## " + title,
            "",
            "|Model|Policy|Documents|LA (%)|BA (%)|CDC (%)|FR|NO|",
            "|---|---|---:|---:|---:|---:|---:|---:|",
        ]
        for row in rows:
            values = [
                row["profile"],
                row["policy"],
                str(row["documents"]),
                *[fmt(row["family_macro_" + m]) for m in METRICS[:3]],
                str(row["false_releases"]),
                str(row["no_output"]),
            ]
            tex.append(" & ".join(latex_escape(v) for v in values) + r" \\")
            md.append("|" + "|".join(values) + "|")
        tex += [r"\hline", r"\end{tabular}", r"\end{table}", ""]
        md.append("")
    (out / "tables.tex").write_text("\n".join(tex) + "\n")
    (out / "TABLES.md").write_text("\n".join(md) + "\n")


def export_slice(result_dir, out, records, decisions, audits):
    summaries = load(result_dir / "summary.json")
    tables = summary_tables(summaries, records)
    tables["per_analysis"] = [scalar_record(r) for r in records]
    tables["decisions"] = decisions
    tables["errors"] = [r for r in decisions if not r["is_correct"]]
    tables["error_groups"] = error_groups(decisions)
    tables["repeat_stability"] = repeat_stability(records)
    tables["ablations"] = ablations(summaries)
    tables["paired_documents"] = paired_tables(
        load(result_dir / "paired_documents.json"), "document"
    )
    tables["paired_families"] = paired_tables(load(result_dir / "paired_families.json"), "family")
    tables["source_sensitivity"] = sensitivity_table(
        load(result_dir / "source_sensitivity.json"), tables["paired_families"]
    )
    tables["checks"] = [
        {k: v for k, v in a.items() if k != "audit"}
        | {
            "evaluated": a["audit"].get("evaluated"),
            "accepted_relations": a["audit"].get("accepted_relations"),
            "reason_count": len(a["audit"].get("reasons", [])),
            "reasons": a["audit"].get("reasons", []),
            "audit": a["audit"],
        }
        for a in audits
    ]
    headers = {
        "errors": list(decisions[0]) if decisions else [],
        "error_groups": list(CONFIG)
        + [
            "category",
            "gold",
            "prediction",
            "reason",
            "errors",
            "category_decisions",
            "fraction_of_category",
        ],
    }
    schema = {
        name + ".csv": write_csv(
            out / (name + ".csv"),
            rows,
            headers.get(name),
        )
        for name, rows in tables.items()
    }
    write_tables(out, tables["summary"])
    return schema


def export_run(project, run, plots=False):
    run = Path(run)
    if not (run / "completed.json").exists():
        raise ValueError("Score the complete run before exporting paper tables")
    tasks = load(run / "manifest.json")
    records = load(run / "results/per_analysis.json")
    decisions = load(run / "results/decisions.json")
    if {r["call_id"] for r in records if r["call_id"]} != {t["call_id"] for t in tasks}:
        raise ValueError("Scored call IDs do not cover the manifest; rescore before exporting")
    calls, sources, analyses = call_and_source_tables(project, run, tasks)
    enriched = list(enrich_decisions(decisions, tasks, analyses))
    audits = load(run / "results/check_audits.json")
    out = run / "paper"
    schema = export_slice(run / "results", out, records, enriched, audits)
    schema["calls.csv"] = write_csv(out / "calls.csv", calls)
    schema["efficiency.csv"] = write_csv(out / "efficiency.csv", efficiency(calls))
    schema["sources.csv"] = write_csv(out / "sources.csv", sources)
    splits = load(run / "results/original_core_diagnostic_splits.json")
    split_fields = ("profile", "mode", "policy", "pipeline", "evaluation_set", "case_split")
    schema["original_splits.csv"] = write_csv(
        out / "original_splits.csv",
        [dict(zip(split_fields, r["configuration"])) | scalar_record(r) for r in splits],
    )
    primary = (
        lambda r: r["arm"] == "controlled" and r.get("family_relation") == "new-product-family"
    )
    if (run / "results/controlled_primary31/summary.json").exists():
        nested = export_slice(
            run / "results/controlled_primary31",
            out / "controlled_primary31",
            [r for r in records if primary(r)],
            [r for r in enriched if primary(r)],
            [r for r in audits if primary(r)],
        )
        schema.update({"controlled_primary31/" + k: v for k, v in nested.items()})
    meta = {
        "created_at": datetime.now().astimezone().isoformat(),
        "source_run": str(run),
        "dataset": str(project.dataset),
        "source_scores": str(run / "results"),
        "planned_tasks": len(tasks),
        "documents": len({t["doc_id"] for t in tasks}),
        "analyses": len(analyses),
        "decision_rows": len(decisions),
        "models": sorted({(t["requested_model"], t["reasoning_effort"]) for t in tasks}),
        "no_new_model_calls": True,
        "missing_values": "Empty CSV cell; never imputed as zero",
        "csv_encoding": "UTF-8 with BOM",
        "schema": schema,
    }
    save(out / "export_manifest.json", meta)
    from .guide import write_guide

    write_guide(out)
    if plots:
        from .figures import render_figures

        render_figures(out)
    return {
        "paper_directory": str(out),
        "tables": len(schema),
        "calls": len(calls),
        "decision_rows": len(decisions),
        "new_model_calls": 0,
    }
