# Implementation

Start with the [reader-package README](../README.md).

`soa/vision` contains PDF/text/OCR/candidate extraction; `soa/rules` contains baselines, local-condition projection and consistency checks. `soa/contracts.py` parses model answers. `soa/verifier.py`, `scoring.py` and `statistics.py` implement decisions and measurement. `soa/reporting` exports result tables.

`soa/api_execution.py` and `api_budget.py` support new model calls with an explicitly supplied account and budget. See [data and inputs](../docs/DATA_AND_INPUTS.md) for source-image requirements.

The package uses a single API execution path and qwen/kimi profile names. The numerical verifier, checks, projection, scoring and aggregation calculations are unchanged.

With the full dependencies installed, run `python -m unittest discover -s tests -v` from this directory. Two source-decoding tests require AOT240L.pdf, available through data/sources.csv, and are skipped while it is absent; the other 35 tests use packaged records or small fixtures.
