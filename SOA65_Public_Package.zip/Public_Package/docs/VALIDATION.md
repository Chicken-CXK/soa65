# Reader-package validation

Validated on 2026-09-09 with Python 3.12.14, NumPy 2.3.5 and Matplotlib 3.10.9 on macOS.

## Offline replay

- 65 distinct source documents and 116 analysis snapshots.
- All 884 final answer texts reparse to the saved structured results.
- All 155,190 generated query-policy decisions are reproduced.
- All 33 packaged CSV exports match the generated exports, including both compressed query tables.
- CSV comparison uses column names and field values. Only the order of `audit.rejected_groups` is ignored because the implementation emits that list from a set; entries and multiplicities remain compared.
- Zero new model requests.

The complete replay also passed from a separate relocated directory using Python isolated mode. NumPy is required by result-export statistics and is listed in `requirements-replay.txt`. Dependency versions were available locally; a fresh internet installation and native Windows execution were not part of this check.

## Tables, figures and tests

- The five rebuilt LaTeX result tables are byte-for-byte equal to the manuscript's tables.
- The plotted CSV data for all three rebuilt quantitative figures are byte-for-byte equal to the manuscript's plotted data.
- All 40 existing unit tests passed with the AOT240L source PDF supplied locally. In the link-only package, the two source-decoding tests are skipped until that PDF is downloaded; the remaining 38 tests use packaged records or fixtures.
- All relative Markdown links resolve in the package.

## Distribution changes

The numerical verifier, consistency checks, projection, scoring and aggregation source files are unchanged. The offline validation entry point was adapted to the compact archive; paths, documentation and the tests for image/PDF assets were adjusted. Exported Markdown headings and the export guide were translated into English. JSON whitespace was compacted, author-machine path metadata shortened, and final-output lookup paths made local to this package. No reference annotation values or model predictions were replaced.

The public package contains final output evidence and reader-facing material. Download links replace the 65 manufacturer PDFs. Manufacturer PDFs, rendered input images, historical working directories, full paper drafts and local test outputs are excluded.
