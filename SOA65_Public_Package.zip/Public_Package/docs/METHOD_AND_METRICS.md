# Method and metric guide

## Source-to-decision method

A candidate describes a curve's current interval at a query voltage, along with its page, panel and neutral identifier. A binding adds pulse duration, pulse mode, temperature object and temperature value. The verifier associates an operating query with a unique applicable boundary and returns `SUPPORTED`, `SCREEN_FAIL` or `INSUFFICIENT`. Missing usable geometry or bindings are scored as `NO_OUTPUT`.

For interval `[I_low, I_high]`, a current below `I_low` is supported, a current above `I_high` is screen-fail, and a current inside the reading interval is insufficient. Applicable hard caps restrict the interval before comparison; a source-scope conflict threshold can turn an otherwise supported verdict into insufficient.

Local-condition projection uses uniquely identifiable source conditions to complete or correct temperature and pulse fields while preserving candidate geometry and curve–duration associations.

## Checking policies

- `baseline` / Base: evaluate the binding without group filtering.
- `candidate` / C: check candidate classifications and printed pulse inventory.
- `order` / O: check duration–current ordering within a condition group.
- `evidence` / E: check typed conditions against the source text.
- `candidate_order` / C+O: apply candidate and order checks.
- `combined` / All: apply all three checks.

Conflicting groups are removed before query evaluation. A removed applicable boundary can change either a correct or an incorrect decisive verdict to insufficient.

## Measurement units

The collection contains 65 distinct PDFs and 81 document–voltage tasks. The three experimental branches contain 116 analysis units in total, with overlap in source documents. Each evaluated model contributes 442 positions, giving 884 positions overall. Controlled and automatic analyses have three prescribed calls; the single-call comparison has one.

The 31-document controlled primary subset spans nine families. Each model/input configuration contributes 1,995 query outcomes, including 798 reference-decisive outcomes and 1,596 reference non-supported outcomes. These two subsets overlap through reference `SCREEN_FAIL` cases.

## Metrics

- **LA**: fraction of all query predictions equal to their reference labels.
- **BA**: fraction of reference relations matched by a unique predicted condition tuple. Controlled matching requires the candidate identifier. Automatic matching additionally requires the same source page, panel IoU at least 0.5 and a candidate current inside the reference reading interval.
- **CDC**: fraction of reference-decisive queries correctly classified. Reference-decisive means the gold label is not `INSUFFICIENT`.
- **FR**: predictions of `SUPPORTED` whose reference label is not `SUPPORTED`.
- **FR_R**: FR divided by all predicted releases (`SUPPORTED` predictions).
- **FR_N**: FR divided by all reference non-supported queries.

LA, BA and CDC in the manuscript are family-macro averages: calls within an analysis, voltage analyses within a document, documents within a family, then equal weighting of families. FR, query counts and release counts pool the prescribed outcomes. Zero-denominator fractions are left undefined.

## Finding a result

The final manifest maps each evaluation position to its model, input mode, analysis snapshot and output directory. `last_message.txt` holds the model's final answer; `result.json` holds the parsed output. Numeric directory identifiers are stable join keys for code and tables.

`summary.csv` contains complete aggregate configurations; `controlled_primary31/summary.csv` contains the primary comparison. `families.csv` and `documents.csv` provide finer aggregation. `decisions.csv.gz` contains the query-level gold labels, predictions and reasons. `checks.csv` provides the corresponding group checks. These files allow readers to move from a table entry to the relevant query, binding and source-text evidence.
