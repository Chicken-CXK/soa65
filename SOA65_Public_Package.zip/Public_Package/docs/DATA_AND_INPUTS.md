# Data, inputs and source reconstruction

## Document and annotation map

`data/sources.csv` contains one row per retained document, with its recorded download address, acquisition time, PDF filename, family, evaluation branches, primary-subset membership and annotation path. URLs are taken from successful acquisition records, rather than inferred from filenames. They have not been re-downloaded during package preparation.

`data/annotations/` holds the original per-document annotation values, including page/panel locations, calibrated readpoints, reading intervals and typed conditions. `data/dataset.json` indexes the 65 documents; `data/exclusions.json` preserves the recorded excluded-document reasons. Author-machine absolute paths in distribution metadata are shortened to historical basenames. Numerical annotations and semantic fields are unchanged. Reader-facing instructions and table headings are English; recorded prompts, source excerpts, model answers and annotation evidence retain their original language. Exclusion-reason descriptions have been translated into English.

The 31-document primary subset selects controlled records whose `family_relation` is `new-product-family`. The other four controlled documents have `same-family-new-part` status: PSMN1R0-30YLE, PSMN1R0-80CSE, PSMN1R1-30YLE and PSMNR67-30YLE. They remain in the complete controlled evaluation.

## Input and analysis files

Paths inside plans, manifests and input packets resolve relative to `code/`. For example, `../data/analyses/0001.json` refers to a packaged analysis snapshot.

Each analysis snapshot contains reference geometry and bindings, query cases, frontend candidates, source-text evidence and rule bindings. These are sufficient to replay the saved predictions and all six policies. The reference fields are evaluation material; they are not sent as answers to the model.

Each input directory contains the actual prompt text and `input.json`. The `images` entries describe the expected image filenames, source pages and crop regions. Those image binaries are deliberately omitted from this compact distribution. An image path in a packet describes the original model input; it is not a bundled-file promise.

Source-text excerpts are retained where needed to understand prompts and reproduce source-evidence checks. Manufacturer PDFs and rasterized pages/crops are not bundled; download addresses for all 65 PDFs are provided in `data/sources.csv`.

## New visual inference

1. Download the required PDFs using `data/sources.csv` and save them under `data/sources/pdf/` using the recorded PDF filenames.
2. For the single-call and controlled branches, prepare page images matching each packet's page metadata and restore them at the relative `images[].path` locations. These branches use full-page renderings, historically at 150 dpi.
3. For the automatic branch, the supplied frontend can regenerate source text, candidates and marked crops from PDFs. The historical frontend rendered at 300 dpi. Rebuilding produces a new frontend realization; the packaged fixed analysis snapshots remain the reference for reported scores.

To install the full implementation, from the package root:

```sh
python3.12 -m pip install -e './code[plots]'
```

Automatic frontend reconstruction uses macOS Apple Vision OCR. From `code/`, after downloading the required PDFs:

```sh
sh bin/build_ocr.sh
python -m soa prepare --run runs/rebuilt_frontend --rebuild-frontends --workers 4
```

This command prepares inputs without sending model requests. Single-call/controlled image files still need to be restored separately. Offline scoring works without OCR. The API budget module uses `fcntl`; use Linux/WSL or macOS for that execution path.

For new API inference, set your own `api.budget_cap_cny` and a fresh budget-file path in `code/config/experiment_api_final.json`, and provide the credential via `DASHSCOPE_API_KEY`. Recorded prices and model identifiers describe the original experiment, not current service availability or billing.

From `code/`, once all required image inputs are available:

```sh
python -m soa --config config/experiment_api_final.json prepare --run runs/new_api
python -m soa --config config/experiment_api_final.json api-plan --run runs/new_api
python -m soa --config config/experiment_api_final.json run --run runs/new_api --workers 4
python -m soa --config config/experiment_api_final.json score --run runs/new_api
python -m soa --config config/experiment_api_final.json report --run runs/new_api
```

Only `run` sends model requests. New inference can produce different answers; the offline replay tests whether the saved final answers reproduce the reported measurements.
