# Data license scope

Original reference annotations in `annotations/` and their corresponding reference values in `analyses/` are licensed under [CC BY 4.0](../LICENSES/CC-BY-4.0.txt), attributed to SOA65 contributors. Indicate changes when redistributing modified annotations.

Manufacturer excerpts and other third-party content retain their original rights; see [third-party notices](../THIRD_PARTY_NOTICES.md).
