# SOA65: condition-aware SOA verification

Reader package for a study of curve–condition binding and deterministic query verification in MOSFET safe operating area (SOA) datasheets.

[Data and inputs](docs/DATA_AND_INPUTS.md) · [Method and metrics](docs/METHOD_AND_METRICS.md) · [Validation](docs/VALIDATION.md)

## Start here

- Read the [main controlled results](outputs/final/paper/controlled_primary31/TABLES.md) and [complete results](outputs/final/paper/TABLES.md).
- Inspect [document sources](data/sources.csv), [reference annotations](data/annotations/) and [model prompts](data/inputs/).
- View the three quantitative figures: [family comparison](paper/figure_redraw/pdf/A1_controlled_modality_BA.pdf), [controlled policies](paper/figure_redraw/pdf/A2_controlled_tradeoff_compact.pdf), and [automatic policies](paper/figure_redraw/pdf/A5_automatic_overview.pdf).

## Reproduce the reported scores

Python 3.12 is the recorded runtime. From this directory:

```sh
python3.12 -m pip install -r requirements-replay.txt
python3.12 reproduce.py
```

The replay requires NumPy for result-export statistics. It parses all 884 saved final answers, evaluates them against 116 fixed analysis snapshots, applies the checking policies and reproduces the rule-baseline evaluation. It then compares the generated CSV exports with the frozen exports, including the per-query decisions. After dependency installation, it runs offline: no API key, model request, PDF, OCR engine or image file is needed.

Generated files go to a new `code/runs/reproduce_*` directory. The outcome is printed and saved to `code/validation/release_reproduction.json`. The reference data and saved outputs are kept separate from generated results.

The archive stores the large query tables as `decisions.csv.gz`; ordinary gzip tools or Python's `gzip` module can read them. The replay produces uncompressed CSV files for analysis.

## Regenerate manuscript tables and figures

```sh
python3.12 -m pip install -r requirements-figures.txt
python3.12 paper/rebuild.py
```

This regenerates five data-driven manuscript tables and the three quantitative main figures from the frozen exports, retaining the manuscript's plotting code, scales and palette. Figure PDFs, SVGs, PNGs and plotted CSV values are provided. The conceptual overview, two inline descriptive tables and full manuscript are outside this reader package.

## Package contents

| Path | Contents |
|---|---|
| `code/soa/` | Binding parser, verifier, consistency checks, projection, baselines, scoring, frontend and model-request implementation |
| `code/config/` | Recorded model settings and experiment plan |
| `data/annotations/` | Per-document reference annotations |
| `data/analyses/` | Reference queries, fixed candidate geometry, source-text evidence and saved rule bindings |
| `data/inputs/` | Actual prompt text, candidate identifiers, image-page/crop metadata; image binaries excluded |
| `data/sources.csv` | Download addresses from acquisition records and the 31-document subset membership |
| `outputs/final/outputs/` | 884 saved final model answers and their parsed bindings |
| `outputs/final/paper/` | Frozen result tables and query-level exports |
| `paper/` | Manuscript table and quantitative-figure code/assets |

## Study scope

The collection contains 65 documents, 81 document–voltage tasks and 363 annotated pulse readpoints. The single-call comparison, controlled branch and automatic branch cover 11, 35 and 54 documents with overlap. The controlled primary comparison comprises 31 documents from nine newly introduced product families; four additional ASFET-family models remain in the full controlled results.

Qwen3.8-27B and Kimi-K3 each contribute 442 evaluated positions. A position combines a model, input mode, analysis and prescribed repeat. The frozen experiment uses supplied geometry in the single-call and controlled branches and prepared frontend candidates in the automatic branch. The [method guide](docs/METHOD_AND_METRICS.md) explains aggregation and the distinction between label agreement, relationship agreement and correct-decision coverage.

## New inference and source documents

The model-request and PDF-frontend code is included for reuse. The package provides download links for the 65 manufacturer datasheets and metadata for their input images. Repeating visual inference requires obtaining the PDFs and preparing/restoring the rendered input images; see [data and inputs](docs/DATA_AND_INPUTS.md). The frozen provider/model names and token settings are retained as experimental records. New model calls use the reader's own API account and a budget they set explicitly.

Reader-facing documentation and result-table headings are in English. Original prompts, model answers, source excerpts and annotation evidence retain their recorded language so that the experimental inputs and evidence remain unchanged.

## License and attribution

Original software and documentation: [MIT](LICENSE). Original reference annotations: [CC BY 4.0](LICENSES/CC-BY-4.0.txt). Extracted source excerpts and other third-party material retain their original rights; see [third-party notices](THIRD_PARTY_NOTICES.md).

Attribute the software and original annotations to **SOA65 contributors**, and include the repository or release URL from which this package was obtained. Publication metadata can be added when available.
